"""Data models used by the energetics calculation."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal


AtomKey = tuple[str, int, str, str]
ResidueKey = tuple[str, int, str]
SCHEMA_VERSION = "amyloid-energetics-1.3"


@dataclass(frozen=True, slots=True)
class Atom:
    serial: int
    name: str
    residue_name: str
    chain_id: str
    residue_id: int
    insertion_code: str
    x: float
    y: float
    z: float
    element: str
    record: str = "ATOM"

    @property
    def key(self) -> AtomKey:
        return (self.chain_id, self.residue_id, self.insertion_code, self.name)

    @property
    def residue_key(self) -> ResidueKey:
        return (self.chain_id, self.residue_id, self.insertion_code)


@dataclass(slots=True)
class EnergyConfig:
    mode: Literal["sawaya_compat", "freesasa_interchain"] = "sawaya_compat"
    ph: float = 7.0
    probe_radius: float = 1.4
    sphere_points: int = 1000
    terminal_policy: Literal["explicit_only", "chain_ends"] = "explicit_only"
    n_termini: tuple[ResidueKey, ...] = ()
    c_termini: tuple[ResidueKey, ...] = ()
    unsupported_policy: Literal["error", "skip"] = "error"
    freesasa_algorithm: Literal["shrake_rupley", "lee_richards"] = "shrake_rupley"
    threads: int = 1
    calculate_central_layer_convergence: bool = True
    convergence_relative_tolerance: float | None = None


@dataclass(slots=True)
class SASAStateSet:
    exposed_local: list[float]
    isolated_folded: list[float]
    assembly: list[float]
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class InteractionSet:
    hbond_counts: list[int]
    hbonds: list[dict[str, Any]]
    ion_pair_ids: list[list[str]]
    ion_pair_asp: list[float | None]
    paired_atoms: set[int]
    charge_flags: list[bool]
    charge_states: list[str]
    ion_pairs: list[dict[str, Any]]


@dataclass(slots=True)
class ASPResult:
    values: list[float]
    charge_states: list[str]


@dataclass(slots=True)
class EntropyResult:
    total_by_residue: dict[ResidueKey, float]
    interchain_by_residue: dict[ResidueKey, float]
    fraction_total: dict[ResidueKey, float]
    fraction_interchain: dict[ResidueKey, float]


@dataclass(slots=True)
class EnergyResult:
    metadata: dict[str, Any]
    atoms: list[dict[str, Any]]
    residues: list[dict[str, Any]]
    chains: list[dict[str, Any]]
    interactions: dict[str, list[dict[str, Any]]]
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
