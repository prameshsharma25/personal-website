"""Structure and result I/O without a mandatory structural-biology dependency."""

from __future__ import annotations

import csv
import json
import shlex
from pathlib import Path
from typing import Any, Iterable

from .model import Atom, EnergyResult
from .parameters import STANDARD_RESIDUES, VDW_RADII


class StructureError(ValueError):
    """Raised when a structure cannot be scored unambiguously."""


def _element(atom_name: str, explicit: str = "") -> str:
    value = explicit.strip().upper()
    if value == "H":
        return value
    if value in VDW_RADII:
        return value
    letters = "".join(c for c in atom_name.upper() if c.isalpha())
    if letters.startswith("BR"):
        return "BR"
    if letters.startswith("H"):
        return "H"
    if letters and letters[0] in VDW_RADII:
        return letters[0]
    raise StructureError(f"Unsupported or missing element for atom {atom_name!r}")


def validate_energy_atoms(
    atoms: list[Atom], unsupported_policy: str = "error"
) -> tuple[list[Atom], dict[str, Any]]:
    """Validate adapted atoms and audit unsupported polymer residue filtering."""
    all_residues = {
        (atom.chain_id, atom.residue_id, atom.insertion_code, atom.residue_name)
        for atom in atoms
    }
    unsupported_residues = sorted(
        residue for residue in all_residues if residue[3] not in STANDARD_RESIDUES
    )
    excluded_atom_count = sum(
        atom.residue_name not in STANDARD_RESIDUES for atom in atoms
    )
    identities = [
        f"{chain}:{name}:{number}{insertion}"
        for chain, number, insertion, name in unsupported_residues
    ]
    warnings: list[str] = []
    if unsupported_residues:
        message = "Unsupported polymer residues (standard amino acids only): " + ", ".join(identities)
        if unsupported_policy == "error":
            raise StructureError(message)
        warnings.append(message + "; their atoms were skipped")
        atoms = [a for a in atoms if a.residue_name in STANDARD_RESIDUES]
    if not atoms:
        raise StructureError("No supported heavy atoms were found")
    seen: set[tuple[str, int, str, str]] = set()
    duplicates = []
    for atom in atoms:
        if atom.key in seen:
            duplicates.append(": ".join(map(str, atom.key)))
        seen.add(atom.key)
    if duplicates:
        raise StructureError("Duplicate atom keys after alternate-location filtering: " + ", ".join(duplicates[:5]))
    parameterized = len(all_residues) - len(unsupported_residues)
    return atoms, {
        "unsupported_policy": unsupported_policy,
        "all_polymer_residue_count": len(all_residues),
        "parameterized_residue_count": parameterized,
        "parameterized_fraction_of_all_polymer_residues": (
            parameterized / len(all_residues) if all_residues else 0.0
        ),
        "excluded_residues": identities,
        "excluded_atom_count": excluded_atom_count,
        "warnings": warnings,
    }


def _validate_atoms(atoms: list[Atom], unsupported_policy: str) -> tuple[list[Atom], list[str]]:
    validated, audit = validate_energy_atoms(atoms, unsupported_policy)
    return validated, list(audit["warnings"])


def read_structure(
    path: str | Path,
    unsupported_policy: str = "error",
    model_index: int = 0,
    chain_id_source: str = "auto",
) -> tuple[list[Atom], list[str]]:
    """Read through the canonical common parser and adapt its normalized atoms."""
    try:
        from amyloid_cross_check.common import load_assembly
        from amyloid_cross_check.common.adapters import to_energy_atoms
    except ImportError as error:  # pragma: no cover - common is a declared dependency
        raise StructureError(
            "amyloid-cross-check-common is required for canonical structure parsing"
        ) from error
    assembly = load_assembly(
        path, model_index=model_index, chain_id_source=chain_id_source
    )
    atoms, warnings = _validate_atoms(to_energy_atoms(assembly), unsupported_policy)
    return atoms, [*assembly.warnings, *warnings]


def _read_pdb(path: Path) -> list[Atom]:
    atoms: list[Atom] = []
    model = 1
    with path.open(encoding="utf-8", errors="replace") as handle:
        for line in handle:
            record = line[0:6].strip().upper()
            if record == "MODEL":
                try:
                    model = int(line[10:14])
                except ValueError:
                    model += 1
                continue
            if record == "ENDMDL" and model == 1:
                break
            if record not in {"ATOM", "HETATM"} or model != 1:
                continue
            altloc = line[16:17]
            if altloc not in {" ", "", "A", "."}:
                continue
            name = line[12:16].strip().upper()
            element = _element(name, line[76:78] if len(line) >= 78 else "")
            if element == "H":
                continue
            try:
                atoms.append(Atom(
                    serial=int(line[6:11]), name=name,
                    residue_name=line[17:20].strip().upper(),
                    chain_id=line[21:22].strip() or "_",
                    residue_id=int(line[22:26]), insertion_code=line[26:27].strip(),
                    x=float(line[30:38]), y=float(line[38:46]), z=float(line[46:54]),
                    element=element, record=record,
                ))
            except ValueError as exc:
                raise StructureError(f"Invalid PDB atom line: {line.rstrip()}") from exc
    return atoms


def _cif_tokens(path: Path) -> list[str]:
    # Atom-site values are normally simple tokens. shlex also handles quoted atom names.
    tokens: list[str] = []
    with path.open(encoding="utf-8", errors="replace") as handle:
        for line in handle:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            if stripped.startswith(";"):
                raise StructureError("Semicolon-delimited mmCIF fields are not supported in atom_site loops")
            tokens.extend(shlex.split(line, comments=False, posix=True))
    return tokens


def _read_mmcif(path: Path) -> list[Atom]:
    tokens = _cif_tokens(path)
    atoms: list[Atom] = []
    i = 0
    while i < len(tokens):
        if tokens[i].lower() != "loop_":
            i += 1
            continue
        i += 1
        tags: list[str] = []
        while i < len(tokens) and tokens[i].startswith("_"):
            tags.append(tokens[i])
            i += 1
        if not tags or not any(t.startswith("_atom_site.") for t in tags):
            while i < len(tokens) and tokens[i].lower() not in {"loop_", "stop_"} and not tokens[i].startswith("_"):
                i += 1
            continue
        rows: list[list[str]] = []
        while i < len(tokens) and tokens[i].lower() not in {"loop_", "stop_"} and not tokens[i].startswith("_"):
            if i + len(tags) > len(tokens):
                raise StructureError("Incomplete atom_site row in mmCIF")
            rows.append(tokens[i:i + len(tags)])
            i += len(tags)
        index = {tag: n for n, tag in enumerate(tags)}

        def value(row: list[str], *names: str, default: str = "") -> str:
            for name in names:
                if name in index and row[index[name]] not in {".", "?"}:
                    return row[index[name]]
            return default

        for row in rows:
            group = value(row, "_atom_site.group_PDB", default="ATOM").upper()
            if group not in {"ATOM", "HETATM"}:
                continue
            model = value(row, "_atom_site.pdbx_PDB_model_num", default="1")
            if model != "1":
                continue
            altloc = value(row, "_atom_site.label_alt_id", "_atom_site.auth_alt_id", default=".")
            if altloc not in {".", "?", "A", ""}:
                continue
            name = value(row, "_atom_site.auth_atom_id", "_atom_site.label_atom_id").upper()
            element = _element(name, value(row, "_atom_site.type_symbol"))
            if element == "H":
                continue
            seq = value(row, "_atom_site.auth_seq_id", "_atom_site.label_seq_id")
            try:
                atoms.append(Atom(
                    serial=int(value(row, "_atom_site.id", default=str(len(atoms) + 1))),
                    name=name,
                    residue_name=value(row, "_atom_site.auth_comp_id", "_atom_site.label_comp_id").upper(),
                    chain_id=value(row, "_atom_site.auth_asym_id", "_atom_site.label_asym_id", default="_"),
                    residue_id=int(seq),
                    insertion_code=value(row, "_atom_site.pdbx_PDB_ins_code"),
                    x=float(value(row, "_atom_site.Cartn_x")),
                    y=float(value(row, "_atom_site.Cartn_y")),
                    z=float(value(row, "_atom_site.Cartn_z")),
                    element=element, record=group,
                ))
            except ValueError as exc:
                raise StructureError(f"Invalid atom_site row for atom {name!r}") from exc
        break
    return atoms


def read_layer_assignments(path: str | Path | None) -> dict[str, dict[str, Any]]:
    if path is None:
        return {}
    with Path(path).open(encoding="utf-8") as handle:
        data = json.load(handle)
    result: dict[str, dict[str, Any]] = {}
    raw = data.get("chains", data)
    if isinstance(raw, list):
        for item in raw:
            chain = str(item.get("chain_id", item.get("chain", "")))
            if chain:
                result[chain] = dict(item)
    elif isinstance(raw, dict):
        for chain, item in raw.items():
            result[str(chain)] = dict(item) if isinstance(item, dict) else {"layer": item}
    return result


def write_results(result: EnergyResult, output: str | Path) -> list[Path]:
    target = Path(output)
    if target.suffix.lower() == ".json":
        prefix = target.with_suffix("")
        if prefix.name.endswith(".energy"):
            prefix = prefix.with_name(prefix.name[:-7])
        json_path = target
    else:
        prefix = target
        json_path = Path(str(prefix) + ".energy.json")
    json_path.parent.mkdir(parents=True, exist_ok=True)
    with json_path.open("w", encoding="utf-8") as handle:
        json.dump(result.to_dict(), handle, indent=2, sort_keys=False)
        handle.write("\n")
    paths = [json_path]
    for suffix, rows in (
        (".atom_energy.csv", result.atoms),
        (".residue_energy.csv", result.residues),
        (".chain_energy.csv", result.chains),
    ):
        path = Path(str(prefix) + suffix)
        _write_csv(path, rows)
        paths.append(path)
    return paths


def _write_csv(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    materialized = list(rows)
    if not materialized:
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(materialized[0]))
        writer.writeheader()
        writer.writerows(materialized)
