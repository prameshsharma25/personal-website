"""Command-line entry point for Sawaya-style energetics."""

from __future__ import annotations

import argparse
import os
import sys

from .io import StructureError, read_layer_assignments, read_structure, write_results
from .model import EnergyConfig
from .scoring import score_sawaya


def _residue_selector(value: str) -> tuple[str, int, str]:
    try:
        chain, residue = value.split(":", 1)
        start = 1 if residue.startswith("-") else 0
        split = len(residue)
        for index, char in enumerate(residue[start:], start=start):
            if not char.isdigit():
                split = index
                break
        return chain, int(residue[:split]), residue[split:]
    except (ValueError, IndexError) as exc:
        raise argparse.ArgumentTypeError(
            "terminus must be CHAIN:RESID, for example A:1 or B:42A"
        ) from exc


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Calculate Sawaya-compatible total and interchain assembly energetics."
    )
    parser.add_argument("--structure", required=True, help="Input PDB or mmCIF structure")
    parser.add_argument("--layers", help="Optional geometry-derived chain/layer assignment JSON")
    parser.add_argument("--model-index", type=int, default=0)
    parser.add_argument(
        "--chain-id-source", choices=("auto", "author", "label"), default="auto"
    )
    parser.add_argument("--mode", choices=("sawaya_compat", "freesasa_interchain"),
                        default="sawaya_compat")
    parser.add_argument("--ph", type=float, default=7.0)
    parser.add_argument("--output", required=True,
                        help="Output prefix or .json path; atom/residue/chain CSV files are also written")
    parser.add_argument("--terminal-policy", choices=("explicit_only", "chain_ends"),
                        default="explicit_only",
                        help=(
                            "Charge only termini selected with --n-terminus/"
                            "--c-terminus, or infer both termini from chain ends"
                        ))
    parser.add_argument("--n-terminus", action="append", type=_residue_selector, default=[],
                        metavar="CHAIN:RESID", help="Explicitly identify a charged N-terminal residue")
    parser.add_argument("--c-terminus", action="append", type=_residue_selector, default=[],
                        metavar="CHAIN:RESID", help="Explicitly identify a charged C-terminal residue")
    parser.add_argument("--unsupported-policy", choices=("error", "skip"), default="error")
    parser.add_argument("--sphere-points", type=int, default=1000,
                        help="1000 is required for sawaya_compat validation")
    parser.add_argument("--probe-radius", type=float, default=1.4)
    parser.add_argument("--freesasa-algorithm", choices=("shrake_rupley", "lee_richards"),
                        default="shrake_rupley")
    parser.add_argument("--threads", type=int,
                        default=int(os.environ.get("SLURM_CPUS_PER_TASK", "1")),
                        help="FreeSASA thread count (default: SLURM_CPUS_PER_TASK or 1)")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.mode == "sawaya_compat" and args.sphere_points != 1000:
        print("error: sawaya_compat requires exactly 1000 sphere points", file=sys.stderr)
        return 2
    if args.threads < 1:
        print("error: --threads must be positive", file=sys.stderr)
        return 2
    config = EnergyConfig(
        mode=args.mode, ph=args.ph, probe_radius=args.probe_radius,
        sphere_points=args.sphere_points, terminal_policy=args.terminal_policy,
        n_termini=tuple(args.n_terminus), c_termini=tuple(args.c_terminus),
        unsupported_policy=args.unsupported_policy,
        freesasa_algorithm=args.freesasa_algorithm,
        threads=args.threads,
    )
    try:
        from amyloid_cross_check.common import (
            atom_identity_sha256,
            load_assembly,
            normalized_assembly_sha256,
            sha256_file,
        )
        from amyloid_cross_check.common.adapters import to_energy_atoms

        normalized = load_assembly(
            args.structure,
            model_index=args.model_index,
            chain_id_source=args.chain_id_source,
        )
        atoms = to_energy_atoms(normalized)
        input_warnings = list(normalized.warnings)
        layers = read_layer_assignments(args.layers)
        result = score_sawaya(
            atoms,
            layers,
            config,
            input_identity={
                "path": normalized.source,
                "source_file_sha256": sha256_file(normalized.source),
                "normalized_assembly_sha256": normalized_assembly_sha256(normalized),
                "atom_identity_sha256": atom_identity_sha256(normalized),
                "model_index": normalized.model_index,
                "chain_id_source": normalized.parse_report.chain_id_source,
            },
        )
        result.warnings[:0] = input_warnings
        paths = write_results(result, args.output)
    except (OSError, ValueError, RuntimeError, StructureError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    print(f"Scored {len(atoms)} atoms in {len(result.chains)} chains ({config.mode}).")
    for path in paths:
        print(path)
    if result.warnings:
        print(f"Warnings: {len(result.warnings)} (see JSON metadata).", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
