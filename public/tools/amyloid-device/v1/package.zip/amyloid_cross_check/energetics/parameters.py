"""Versioned Sawaya 7.2u parameters for standard amino acids."""

SOURCE_VERSION = "accessiblesurfacearea_v07.2u.f (2025-04-11)"
SOURCE_LICENSE = "CC BY 4.0"
SOURCE_SHA256 = "a5ab2e87355ee148b08f6e21681becdbb2fb6a50811e06398e3292925959eced"

STANDARD_RESIDUES = frozenset(
    {"ALA", "ARG", "ASN", "ASP", "CYS", "GLN", "GLU", "GLY", "HIS", "ILE",
     "LEU", "LYS", "MET", "PHE", "PRO", "SER", "THR", "TRP", "TYR", "VAL"}
)

VDW_RADII = {
    "C": 1.75,
    "N": 1.60,
    "O": 1.55,
    "F": 1.47,
    "S": 1.80,
    "P": 1.80,
    "BR": 1.85,
    "I": 1.98,
}

BASE_ASP = {"C": 18.0, "N": -9.0, "O": -9.0, "S": -5.0,
            "P": -5.0, "F": 5.0, "BR": 5.0, "I": 5.0}

# Positive magnitudes in kcal/mol.  The Fortran table stores their negatives and
# negates the final result for presentation.
SIDECHAIN_ENTROPY_KCAL = {
    "ALA": 0.00, "CYS": 0.63, "ASP": 0.65, "GLU": 1.31,
    "PHE": 0.65, "GLY": 0.00, "HIS": 0.92, "ILE": 0.94,
    "LYS": 1.63, "LEU": 0.94, "MET": 1.24, "ASN": 0.75,
    "PRO": 0.30, "GLN": 1.29, "ARG": 1.21, "SER": 0.43,
    "THR": 0.57, "VAL": 0.62, "TRP": 1.14, "TYR": 1.07,
}

BACKBONE_NAMES = frozenset({"N", "CA", "C", "O"})

POSITIVE_GROUPS = {
    "HIS": frozenset({"ND1", "NE2"}),
    "LYS": frozenset({"NZ"}),
    "ARG": frozenset({"NE", "NH1", "NH2"}),
}
NEGATIVE_GROUPS = {
    "ASP": frozenset({"OD1", "OD2"}),
    "GLU": frozenset({"OE1", "OE2"}),
    "TYR": frozenset({"OH"}),
}

EXPECTED_HEAVY_ATOMS = {
    "ALA": {"N", "CA", "C", "O", "CB"},
    "ARG": {"N", "CA", "C", "O", "CB", "CG", "CD", "NE", "CZ", "NH1", "NH2"},
    "ASN": {"N", "CA", "C", "O", "CB", "CG", "OD1", "ND2"},
    "ASP": {"N", "CA", "C", "O", "CB", "CG", "OD1", "OD2"},
    "CYS": {"N", "CA", "C", "O", "CB", "SG"},
    "GLN": {"N", "CA", "C", "O", "CB", "CG", "CD", "OE1", "NE2"},
    "GLU": {"N", "CA", "C", "O", "CB", "CG", "CD", "OE1", "OE2"},
    "GLY": {"N", "CA", "C", "O"},
    "HIS": {"N", "CA", "C", "O", "CB", "CG", "ND1", "CD2", "CE1", "NE2"},
    "ILE": {"N", "CA", "C", "O", "CB", "CG1", "CG2", "CD1"},
    "LEU": {"N", "CA", "C", "O", "CB", "CG", "CD1", "CD2"},
    "LYS": {"N", "CA", "C", "O", "CB", "CG", "CD", "CE", "NZ"},
    "MET": {"N", "CA", "C", "O", "CB", "CG", "SD", "CE"},
    "PHE": {"N", "CA", "C", "O", "CB", "CG", "CD1", "CD2", "CE1", "CE2", "CZ"},
    "PRO": {"N", "CA", "C", "O", "CB", "CG", "CD"},
    "SER": {"N", "CA", "C", "O", "CB", "OG"},
    "THR": {"N", "CA", "C", "O", "CB", "OG1", "CG2"},
    "TRP": {"N", "CA", "C", "O", "CB", "CG", "CD1", "CD2", "NE1", "CE2", "CE3", "CZ2", "CZ3", "CH2"},
    "TYR": {"N", "CA", "C", "O", "CB", "CG", "CD1", "CD2", "CE1", "CE2", "CZ", "OH"},
    "VAL": {"N", "CA", "C", "O", "CB", "CG1", "CG2"},
}
