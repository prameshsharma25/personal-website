"""Atom-level solvent-accessible surface calculations."""

from __future__ import annotations

import math
from collections import defaultdict
from importlib.metadata import PackageNotFoundError, version as package_version
from typing import Iterable

from .model import Atom, EnergyConfig, SASAStateSet
from .parameters import BACKBONE_NAMES, SOURCE_VERSION, VDW_RADII


def golden_spiral_points(count: int) -> tuple[tuple[float, float, float], ...]:
    """Return the deterministic sphere points used by Sawaya 7.2u."""
    if count < 1:
        raise ValueError("sphere_points must be positive")
    # Keep the literal used by the single-precision Fortran oracle.
    increment = 3.14159 * (3.0 - math.sqrt(5.0))
    offset = 2.0 / count
    points = []
    for k in range(count):
        yy = k * offset - 1.0 + offset / 2.0
        radial = math.sqrt(1.0 - yy * yy)
        phi = k * increment
        points.append((radial * math.cos(phi), radial * math.sin(phi), yy))
    return tuple(points)


def _expanded_radii(atoms: Iterable[Atom], probe: float) -> list[float]:
    return [VDW_RADII[a.element] + probe for a in atoms]


def _grid(atoms: list[Atom], cell_size: float) -> dict[tuple[int, int, int], list[int]]:
    cells: dict[tuple[int, int, int], list[int]] = defaultdict(list)
    for i, atom in enumerate(atoms):
        cells[(math.floor(atom.x / cell_size), math.floor(atom.y / cell_size),
               math.floor(atom.z / cell_size))].append(i)
    return cells


def _nearby_indices(atom: Atom, cells: dict[tuple[int, int, int], list[int]],
                    cell_size: float) -> Iterable[int]:
    cx, cy, cz = (math.floor(atom.x / cell_size), math.floor(atom.y / cell_size),
                  math.floor(atom.z / cell_size))
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            for dz in (-1, 0, 1):
                yield from cells.get((cx + dx, cy + dy, cz + dz), ())


def is_local_reference_neighbor(victim: Atom, culprit: Atom) -> bool:
    """Exact local shielding predicate from the 7.2u Fortran scoring loop.

    Like the source, sequence adjacency uses numeric residue IDs. Insertion-code
    peptides should be renumbered before strict compatibility comparisons.
    """
    if victim.chain_id != culprit.chain_id:
        return False
    difference = victim.residue_id - culprit.residue_id
    # The oracle reads residue number but not the PDB insertion-code column.
    if difference == 0:
        return True
    if difference == 1 and culprit.name == "N":
        return True
    if difference == -1 and culprit.name == "C":
        return True
    return abs(difference) == 1 and victim.name in BACKBONE_NAMES and culprit.name in BACKBONE_NAMES


def calculate_sawaya_surface(
    assembly: list[Atom],
    reference_state: str | None = None,
    config: EnergyConfig | None = None,
) -> SASAStateSet:
    """Calculate local-reference, isolated-chain, and assembly SASA in one pass."""
    del reference_state  # retained for the public API proposed in the README
    config = config or EnergyConfig()
    points = golden_spiral_points(config.sphere_points)
    radii = _expanded_radii(assembly, config.probe_radius)
    max_radius = max(radii)
    cell_size = 2.0 * max_radius
    cells = _grid(assembly, cell_size)
    local = [0.0] * len(assembly)
    isolated = [0.0] * len(assembly)
    full = [0.0] * len(assembly)

    for i, atom in enumerate(assembly):
        candidates = []
        for j in _nearby_indices(atom, cells, cell_size):
            if i == j:
                continue
            other = assembly[j]
            cutoff = radii[i] + radii[j]
            dx, dy, dz = atom.x - other.x, atom.y - other.y, atom.z - other.z
            if dx * dx + dy * dy + dz * dz < cutoff * cutoff:
                candidates.append(j)
        accessible_local = accessible_chain = accessible_full = 0
        for ux, uy, uz in points:
            px = atom.x + ux * radii[i]
            py = atom.y + uy * radii[i]
            pz = atom.z + uz * radii[i]
            blocked_full = blocked_chain = blocked_local = False
            for j in candidates:
                other = assembly[j]
                dx, dy, dz = px - other.x, py - other.y, pz - other.z
                if dx * dx + dy * dy + dz * dz >= radii[j] * radii[j]:
                    continue
                blocked_full = True
                if atom.chain_id == other.chain_id:
                    blocked_chain = True
                if is_local_reference_neighbor(atom, other):
                    blocked_local = True
                if blocked_chain and blocked_local:
                    # Full is necessarily blocked as well.
                    break
            accessible_full += not blocked_full
            accessible_chain += not blocked_chain
            accessible_local += not blocked_local
        point_area = 4.0 * 3.1415 * radii[i] * radii[i] / config.sphere_points
        full[i] = accessible_full * point_area
        isolated[i] = accessible_chain * point_area
        local[i] = accessible_local * point_area
    return SASAStateSet(
        exposed_local=local,
        isolated_folded=isolated,
        assembly=full,
        metadata={
            "engine": "internal_golden_spiral",
            "source": SOURCE_VERSION,
            "points_per_atom": config.sphere_points,
            "probe_radius_A": config.probe_radius,
            "radii": "Sawaya/areaimol element radii",
        },
    )


def _effective_freesasa_threads(config: EnergyConfig) -> int:
    """Return the portable thread count for the pinned FreeSASA backend.

    FreeSASA thread support is selected at compile time. The pinned Biowulf
    Python build rejects more than one thread for both available algorithms,
    so parallelize across structures rather than inside this native call.
    """
    if config.threads < 1:
        raise ValueError("FreeSASA thread count must be positive")
    return 1


def _freesasa_atom_areas(atoms: list[Atom], indices: list[int], config: EnergyConfig) -> tuple[list[float], dict]:
    try:
        import freesasa  # type: ignore[import-not-found]
    except ImportError as exc:
        raise RuntimeError(
            "freesasa_interchain requires the optional 'freesasa' Python package; "
            "install this project with the [freesasa] extra in a compute environment"
        ) from exc
    from amyloid_cross_check.common import pdb_atom_name

    structure = freesasa.Structure()
    for i in indices:
        atom = atoms[i]
        structure.addAtom(pdb_atom_name(atom.name, atom.element), atom.residue_name,
                          str(atom.residue_id), atom.chain_id[0],
                          atom.x, atom.y, atom.z)
    algorithm = freesasa.ShrakeRupley if config.freesasa_algorithm == "shrake_rupley" else freesasa.LeeRichards
    effective_threads = _effective_freesasa_threads(config)
    options = {"algorithm": algorithm, "probe-radius": config.probe_radius,
               "n-threads": effective_threads}
    if config.freesasa_algorithm == "shrake_rupley":
        options["n-points"] = config.sphere_points
    parameters = freesasa.Parameters(options)
    calculation = freesasa.calc(structure, parameters)
    areas = [calculation.atomArea(i) for i in range(len(indices))]
    try:
        installed_version = package_version("freesasa")
    except PackageNotFoundError:
        installed_version = str(getattr(freesasa, "__version__", "unknown"))
    return areas, {
        "engine": "FreeSASA",
        "version": installed_version,
        "algorithm": config.freesasa_algorithm,
        "probe_radius_A": config.probe_radius,
        "classifier": "FreeSASA default classifier/radii",
        "atom_name_policy": "pdb_element_aware_4_column",
        "points_per_atom": config.sphere_points if config.freesasa_algorithm == "shrake_rupley" else None,
        "threads": effective_threads,
        "requested_threads": config.threads,
        "thread_policy": "forced_single_thread_for_build_portability",
    }


def calculate_freesasa_states(assembly: list[Atom], config: EnergyConfig | None = None) -> SASAStateSet:
    """Calculate full and isolated-chain states with FreeSASA.

    FreeSASA has no selective local-neighbor state, so that state is calculated
    with the explicitly documented Sawaya golden-spiral engine. It is retained
    for reporting, while production interpretation should use interchain values.
    """
    config = config or EnergyConfig(mode="freesasa_interchain")
    local = calculate_sawaya_surface(assembly, config=config).exposed_local
    all_indices = list(range(len(assembly)))
    full, metadata = _freesasa_atom_areas(assembly, all_indices, config)
    isolated = [0.0] * len(assembly)
    by_chain: dict[str, list[int]] = defaultdict(list)
    for i, atom in enumerate(assembly):
        by_chain[atom.chain_id].append(i)
    for indices in by_chain.values():
        areas, _ = _freesasa_atom_areas(assembly, indices, config)
        for local_i, global_i in enumerate(indices):
            isolated[global_i] = areas[local_i]
    metadata["local_reference_engine"] = "internal_golden_spiral/Sawaya radii"
    metadata["compatibility_note"] = "FreeSASA values are not atom-for-atom Sawaya-compatible"
    return SASAStateSet(local, isolated, full, metadata)
