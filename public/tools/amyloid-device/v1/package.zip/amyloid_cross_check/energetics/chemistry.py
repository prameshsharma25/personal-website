"""Hydrogen-bond, ion-pair, ASP, and side-chain entropy rules."""

from __future__ import annotations

import math
from collections import defaultdict

from .model import ASPResult, Atom, EnergyConfig, EntropyResult, InteractionSet, ResidueKey, SASAStateSet
from .parameters import (
    BACKBONE_NAMES,
    BASE_ASP,
    NEGATIVE_GROUPS,
    POSITIVE_GROUPS,
    SIDECHAIN_ENTROPY_KCAL,
    EXPECTED_HEAVY_ATOMS,
)


def _distance(a: Atom, b: Atom) -> float:
    return math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2 + (a.z - b.z) ** 2)


def _spatial_neighbors(atoms: list[Atom], cutoff: float):
    cells: dict[tuple[int, int, int], list[int]] = defaultdict(list)
    for i, atom in enumerate(atoms):
        key = (math.floor(atom.x / cutoff), math.floor(atom.y / cutoff), math.floor(atom.z / cutoff))
        cells[key].append(i)
    for i, atom in enumerate(atoms):
        cx, cy, cz = (math.floor(atom.x / cutoff), math.floor(atom.y / cutoff),
                      math.floor(atom.z / cutoff))
        found: list[int] = []
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    found.extend(cells.get((cx + dx, cy + dy, cz + dz), ()))
        yield i, found


def _is_positive(atom: Atom, terminal_roles: dict[int, str]) -> bool:
    return atom.name in POSITIVE_GROUPS.get(atom.residue_name, ()) or terminal_roles.get(id(atom)) == "n_term"


def _is_negative(atom: Atom, terminal_roles: dict[int, str]) -> bool:
    return atom.name in NEGATIVE_GROUPS.get(atom.residue_name, ()) or terminal_roles.get(id(atom)) == "c_term"


def _terminal_roles(atoms: list[Atom], config: EnergyConfig) -> dict[int, str]:
    roles: dict[int, str] = {}
    residues: dict[str, list[ResidueKey]] = defaultdict(list)
    for atom in atoms:
        if atom.residue_key not in residues[atom.chain_id]:
            residues[atom.chain_id].append(atom.residue_key)
    for atom in atoms:
        if atom.residue_key in config.n_termini and atom.name == "N":
            roles[id(atom)] = "n_term"
        if atom.residue_key in config.c_termini and atom.name in {"O", "OXT"}:
            roles[id(atom)] = "c_term"
        if config.terminal_policy == "chain_ends":
            chain_residues = residues[atom.chain_id]
            if atom.residue_key == chain_residues[0] and atom.name == "N":
                roles[id(atom)] = "n_term"
            if atom.residue_key == chain_residues[-1] and atom.name in {"O", "OXT"}:
                roles[id(atom)] = "c_term"
    return roles


def _backbone_hbond_angle(acceptor: Atom, donor: Atom, atoms_by_residue: dict[ResidueKey, dict[str, Atom]]) -> float | None:
    carbon = atoms_by_residue.get(acceptor.residue_key, {}).get("C")
    if carbon is None:
        return None
    v1 = (carbon.x - acceptor.x, carbon.y - acceptor.y, carbon.z - acceptor.z)
    v2 = (donor.x - acceptor.x, donor.y - acceptor.y, donor.z - acceptor.z)
    mag1 = math.sqrt(sum(v * v for v in v1))
    mag2 = math.sqrt(sum(v * v for v in v2))
    if not mag1 or not mag2:
        return None
    cosine = max(-1.0, min(1.0, sum(a * b for a, b in zip(v1, v2)) / (mag1 * mag2)))
    # 3.1416 is the pi literal initialized by the Fortran source.
    return math.acos(cosine) * 360.0 / (2.0 * 3.1416)


def detect_energy_interactions(
    assembly: list[Atom], sasa: SASAStateSet, config: EnergyConfig | None = None
) -> InteractionSet:
    config = config or EnergyConfig()
    terminal_roles = _terminal_roles(assembly, config)
    hbond_counts = [0] * len(assembly)
    hbonds: list[dict] = []
    by_residue: dict[ResidueKey, dict[str, Atom]] = defaultdict(dict)
    for atom in assembly:
        by_residue[atom.residue_key][atom.name] = atom

    donor_oxygen_names = {"OG", "OG1", "OH"}
    for i, candidates in _spatial_neighbors(assembly, 3.3):
        acceptor = assembly[i]
        if acceptor.element != "O":
            continue
        for j in candidates:
            donor = assembly[j]
            if donor.element != "N" and donor.name not in donor_oxygen_names:
                continue
            if acceptor.residue_key == donor.residue_key:
                continue
            distance = _distance(acceptor, donor)
            if not (2.3 <= distance < 3.3):
                continue
            angle = None
            kind = "side_side"
            if acceptor.name == "O" and donor.name == "N":
                kind = "backbone_backbone"
                angle = _backbone_hbond_angle(acceptor, donor, by_residue)
                if angle is None or angle < 110.0:
                    continue
            elif acceptor.name == "O" or donor.name == "N":
                kind = "main_side"
            hbond_counts[i] += 1
            hbond_counts[j] += 1
            hbonds.append({
                "acceptor": _atom_key_string(acceptor), "donor": _atom_key_string(donor),
                "distance_A": distance, "acceptor_angle_deg": angle, "kind": kind,
            })

    ion_pair_ids: list[list[str]] = [[] for _ in assembly]
    ion_pair_asp: list[float | None] = [None] * len(assembly)
    paired_atoms: set[int] = set()
    ion_pairs: list[dict] = []
    positives = {i for i, atom in enumerate(assembly) if _is_positive(atom, terminal_roles)}
    negatives = {i for i, atom in enumerate(assembly) if _is_negative(atom, terminal_roles)}
    for i, candidates in _spatial_neighbors(assembly, 4.5):
        if i not in positives:
            continue
        for j in candidates:
            if j not in negatives:
                continue
            distance = _distance(assembly[i], assembly[j])
            if distance > 4.5 or sasa.assembly[i] >= 50.0 or sasa.assembly[j] >= 50.0:
                continue
            pair_id = f"IP{len(ion_pairs) + 1}"
            pair_asp = -9.0 * ((max(distance, 2.8) - 2.8) / 2.8) ** 2
            paired_atoms.update({i, j})
            ion_pair_ids[i].append(pair_id)
            ion_pair_ids[j].append(pair_id)
            ion_pair_asp[i] = pair_asp if ion_pair_asp[i] is None else max(ion_pair_asp[i], pair_asp)
            ion_pair_asp[j] = pair_asp if ion_pair_asp[j] is None else max(ion_pair_asp[j], pair_asp)
            ion_pairs.append({
                "id": pair_id, "positive": _atom_key_string(assembly[i]),
                "negative": _atom_key_string(assembly[j]), "distance_A": distance,
                "paired_asp": pair_asp,
            })

    # Sawaya distributes one formal charge across equivalent nuclei. When any
    # nucleus pairs, the complete group is marked neutralized; otherwise the
    # least-buried nucleus carries the formal charge.
    charge_flags = [False] * len(assembly)
    groups: dict[tuple[ResidueKey, str], list[int]] = defaultdict(list)
    for i, atom in enumerate(assembly):
        polarity = "positive" if i in positives else "negative" if i in negatives else ""
        if polarity:
            role = terminal_roles.get(id(atom))
            group_name = role or f"{atom.residue_name}_{polarity}"
            groups[(atom.residue_key, group_name)].append(i)
    for indices in groups.values():
        if any(i in paired_atoms for i in indices):
            continue
        least_buried = min(indices, key=lambda i: sasa.exposed_local[i] - sasa.assembly[i])
        charge_flags[least_buried] = True

    charge_states = ["not_ionizable"] * len(assembly)
    for i in positives | negatives:
        if i in paired_atoms:
            charge_states[i] = "ion_paired"
        elif charge_flags[i]:
            charge_states[i] = "formal_positive" if i in positives else "formal_negative"
        else:
            charge_states[i] = "charge_delocalized_neutral_atom"
    return InteractionSet(hbond_counts, hbonds, ion_pair_ids, ion_pair_asp,
                          paired_atoms, charge_flags, charge_states, ion_pairs)


def _atom_key_string(atom: Atom) -> str:
    insertion = atom.insertion_code or ""
    return f"{atom.chain_id}:{atom.residue_name}:{atom.residue_id}{insertion}:{atom.name}"


def assign_atomic_solvation_parameters(
    assembly: list[Atom], sasa: SASAStateSet, interactions: InteractionSet,
    ph: float = 7.0, config: EnergyConfig | None = None,
) -> ASPResult:
    config = config or EnergyConfig(ph=ph)
    terminal_roles = _terminal_roles(assembly, config)
    values = [BASE_ASP[a.element] for a in assembly]
    states = list(interactions.charge_states)

    # Pair ASP is assigned only to the atom actually within the ion-pair cutoff.
    for i, pair_asp in enumerate(interactions.ion_pair_asp):
        if pair_asp is not None:
            values[i] = pair_asp

    positive_pka = {"HIS": 6.08, "LYS": 10.0, "ARG": 10.5}
    negative_pka = {"ASP": 3.9, "GLU": 4.3, "TYR": 10.1}
    for i, atom in enumerate(assembly):
        role = terminal_roles.get(id(atom))
        if atom.element == "N" and atom.name == "N" and interactions.hbond_counts[i] > 0:
            values[i] = 0.0
        if atom.element == "O" and atom.name == "O" and interactions.hbond_counts[i] > 0:
            values[i] = 0.0

        if atom.name in POSITIVE_GROUPS.get(atom.residue_name, ()):
            protonated = ph <= positive_pka[atom.residue_name]
            if not protonated:
                values[i], states[i] = -9.0, "neutral_by_pH"
            elif interactions.charge_flags[i]:
                values[i] = -38.0
        elif role == "n_term":
            if ph > 8.0:
                values[i], states[i] = -9.0, "neutral_by_pH"
            elif interactions.charge_flags[i]:
                values[i] = -38.0

        if atom.name in NEGATIVE_GROUPS.get(atom.residue_name, ()):
            deprotonated = ph >= negative_pka[atom.residue_name]
            if not deprotonated:
                values[i], states[i] = -9.0, "neutral_by_pH"
            elif interactions.charge_flags[i]:
                values[i] = -37.0
        elif role == "c_term":
            if ph < 3.0:
                values[i], states[i] = -9.0, "neutral_by_pH"
            elif interactions.charge_flags[i]:
                values[i] = -37.0

    # Buried Asn/Gln polar ladders: both complementary side-chain atoms must
    # be hydrogen bonded and have assembled SASA below 5 A^2.
    pairs = {"ASN": ("OD1", "ND2"), "GLN": ("OE1", "NE2")}
    residue_indices: dict[ResidueKey, dict[str, int]] = defaultdict(dict)
    for i, atom in enumerate(assembly):
        residue_indices[atom.residue_key][atom.name] = i
    for residue_atoms in residue_indices.values():
        if not residue_atoms:
            continue
        residue_name = assembly[next(iter(residue_atoms.values()))].residue_name
        if residue_name not in pairs:
            continue
        names = pairs[residue_name]
        if all(name in residue_atoms for name in names):
            indices = [residue_atoms[name] for name in names]
            if all(interactions.hbond_counts[i] > 0 and sasa.assembly[i] < 5.0 for i in indices):
                for i in indices:
                    values[i] = 0.0
    return ASPResult(values, states)


def calculate_sidechain_entropy(
    assembly: list[Atom], sasa: SASAStateSet, config: EnergyConfig | None = None
) -> EntropyResult:
    config = config or EnergyConfig()
    sidechain_indices: dict[ResidueKey, list[int]] = defaultdict(list)
    residue_atom_indices: dict[ResidueKey, list[int]] = defaultdict(list)
    residue_names: dict[ResidueKey, str] = {}
    for i, atom in enumerate(assembly):
        residue_names[atom.residue_key] = atom.residue_name
        residue_atom_indices[atom.residue_key].append(i)
        if atom.residue_name == "GLY":
            if atom.name == "CA":
                sidechain_indices[atom.residue_key].append(i)
        elif atom.name not in BACKBONE_NAMES and (
            atom.name != "OXT" or config.mode == "sawaya_compat"
        ):
            sidechain_indices[atom.residue_key].append(i)

    total: dict[ResidueKey, float] = {}
    interchain: dict[ResidueKey, float] = {}
    fraction_total: dict[ResidueKey, float] = {}
    fraction_interchain: dict[ResidueKey, float] = {}
    for key, indices in sidechain_indices.items():
        exposed = sum(sasa.exposed_local[i] for i in indices)
        isolated = sum(sasa.isolated_folded[i] for i in indices)
        assembled = sum(sasa.assembly[i] for i in indices)
        f_total = max(0.0, min(1.0, (exposed - assembled) / exposed)) if exposed else 0.0
        f_inter = max(0.0, min(1.0, (isolated - assembled) / isolated)) if isolated else 0.0
        base = SIDECHAIN_ENTROPY_KCAL[residue_names[key]]
        # Sawaya 7.2u assigns base*fraction/canonical-heavy-atom-count to
        # every observed atom, then sums those atomic values. Consequently an
        # OXT contributes both to the side-chain SASA fraction above and as an
        # extra atom in the final entropy sum. Preserve that historical
        # behavior only in strict compatibility mode; it is not a biochemical
        # assertion that OXT is a side-chain atom.
        atom_count_scale = 1.0
        if config.mode == "sawaya_compat":
            canonical_count = len(EXPECTED_HEAVY_ATOMS[residue_names[key]])
            atom_count_scale = len(residue_atom_indices[key]) / canonical_count
        fraction_total[key], fraction_interchain[key] = f_total, f_inter
        total[key] = base * f_total * atom_count_scale
        interchain[key] = base * f_inter * atom_count_scale
    # ALA has no non-backbone proxy in the original entropy table, but its term
    # is zero. Ensure all residues still appear in aggregation.
    for atom in assembly:
        total.setdefault(atom.residue_key, 0.0)
        interchain.setdefault(atom.residue_key, 0.0)
        fraction_total.setdefault(atom.residue_key, 0.0)
        fraction_interchain.setdefault(atom.residue_key, 0.0)
    return EntropyResult(total, interchain, fraction_total, fraction_interchain)
