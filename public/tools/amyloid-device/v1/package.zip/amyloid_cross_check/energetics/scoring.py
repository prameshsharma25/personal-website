"""Top-level scoring and aggregation."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import asdict, replace
from statistics import median
from datetime import datetime, timezone
from typing import Any

from .chemistry import (
    assign_atomic_solvation_parameters,
    calculate_sidechain_entropy,
    detect_energy_interactions,
)
from .model import Atom, EnergyConfig, EnergyResult, ResidueKey, SASAStateSet, SCHEMA_VERSION
from .parameters import EXPECTED_HEAVY_ATOMS, SOURCE_LICENSE, SOURCE_SHA256, SOURCE_VERSION
from .surface import calculate_freesasa_states, calculate_sawaya_surface


def calculate_atom_energies(
    atoms: list[Atom], sasa: SASAStateSet, asp_values: list[float],
) -> list[dict[str, float]]:
    energies = []
    for i, _atom in enumerate(atoms):
        delta_total = sasa.exposed_local[i] - sasa.assembly[i]
        delta_interchain = sasa.isolated_folded[i] - sasa.assembly[i]
        energies.append({
            "delta_area_total": delta_total,
            "delta_area_interchain": delta_interchain,
            "dG_solv_total": -0.001 * asp_values[i] * delta_total,
            "dG_solv_interchain": -0.001 * asp_values[i] * delta_interchain,
        })
    return energies


def _atom_key(atom: Atom) -> str:
    return f"{atom.chain_id}:{atom.residue_name}:{atom.residue_id}{atom.insertion_code}:{atom.name}"


def _residue_coverage(atoms: list[Atom]) -> tuple[dict[ResidueKey, float], list[str]]:
    found: dict[ResidueKey, set[str]] = defaultdict(set)
    names: dict[ResidueKey, str] = {}
    for atom in atoms:
        found[atom.residue_key].add(atom.name)
        names[atom.residue_key] = atom.residue_name
    coverage = {}
    warnings = []
    for key, atom_names in found.items():
        expected = EXPECTED_HEAVY_ATOMS[names[key]]
        # OXT is optional and does not change completeness.
        coverage[key] = len(atom_names & expected) / len(expected)
        missing = sorted(expected - atom_names)
        if missing:
            warnings.append(
                f"Incomplete residue {key[0]}:{names[key]}:{key[1]}{key[2]} missing " + ",".join(missing)
            )
    return coverage, warnings


def _layer_fields(chain: str, layer_assignments: dict[str, dict[str, Any]]) -> dict[str, Any]:
    assignment = layer_assignments.get(chain, {})
    classification = assignment.get("end_or_central", assignment.get("classification", "unassigned"))
    provenance = assignment.get("observed_or_virtual", assignment.get("provenance", "observed"))
    return {
        "layer": assignment.get("layer", assignment.get("layer_id")),
        "end_or_central": classification,
        "observed_or_virtual": provenance,
    }


def aggregate_energy(
    atoms: list[Atom], sasa: SASAStateSet, interactions, asp_result, entropy,
    layer_assignments: dict[str, dict[str, Any]] | None = None,
) -> tuple[list[dict], list[dict], list[dict], list[str]]:
    layer_assignments = layer_assignments or {}
    atom_energies = calculate_atom_energies(atoms, sasa, asp_result.values)
    atom_rows: list[dict] = []
    for i, atom in enumerate(atoms):
        values = atom_energies[i]
        atom_rows.append({
            "atom_key": _atom_key(atom), "chain_id": atom.chain_id,
            "residue_name": atom.residue_name, "residue_id": atom.residue_id,
            "insertion_code": atom.insertion_code, "atom_name": atom.name,
            "element": atom.element,
            "sasa_exposed_local": sasa.exposed_local[i],
            "sasa_isolated_folded": sasa.isolated_folded[i],
            "sasa_assembly": sasa.assembly[i],
            "delta_area_total": values["delta_area_total"],
            "delta_area_interchain": values["delta_area_interchain"],
            "asp": asp_result.values[i], "charge_state": asp_result.charge_states[i],
            "hbond_count": interactions.hbond_counts[i],
            "ion_pair_id": ";".join(interactions.ion_pair_ids[i]),
            "dG_solv_total": values["dG_solv_total"],
            "dG_solv_interchain": values["dG_solv_interchain"],
        })

    coverage, warnings = _residue_coverage(atoms)
    residue_atom_indices: dict[ResidueKey, list[int]] = defaultdict(list)
    for i, atom in enumerate(atoms):
        residue_atom_indices[atom.residue_key].append(i)
    residue_rows: list[dict] = []
    for key, indices in residue_atom_indices.items():
        first = atoms[indices[0]]
        solv_total = sum(atom_energies[i]["dG_solv_total"] for i in indices)
        solv_inter = sum(atom_energies[i]["dG_solv_interchain"] for i in indices)
        polar = [i for i in indices if atoms[i].element in {"N", "O"} and sasa.assembly[i] <= 10.0]
        unsatisfied = [i for i in polar if interactions.hbond_counts[i] == 0]
        entropy_total = entropy.total_by_residue[key]
        entropy_inter = entropy.interchain_by_residue[key]
        residue_rows.append({
            "chain_id": key[0], "residue_name": first.residue_name,
            "residue_id": key[1], "insertion_code": key[2],
            "dG_solv_total": solv_total, "dG_solv_interchain": solv_inter,
            "TdeltaS_sidechain": entropy_total,
            "TdeltaS_sidechain_interchain": entropy_inter,
            "dG_total": solv_total + entropy_total,
            "dG_interchain": solv_inter + entropy_inter,
            "buried_polar_count": len(polar),
            "buried_unsatisfied_polar_count": len(unsatisfied),
            "fraction_sidechain_buried": entropy.fraction_total[key],
            "fraction_sidechain_buried_interchain": entropy.fraction_interchain[key],
            "coverage_fraction": coverage[key],
        })

    chain_residues: dict[str, list[dict]] = defaultdict(list)
    for row in residue_rows:
        chain_residues[row["chain_id"]].append(row)
    chain_rows: list[dict] = []
    for chain, rows in chain_residues.items():
        total = sum(row["dG_total"] for row in rows)
        inter = sum(row["dG_interchain"] for row in rows)
        buried_inter = sum(
            atom_energies[i]["delta_area_interchain"]
            for i, atom in enumerate(atoms) if atom.chain_id == chain
        )
        count = len(rows)
        chain_rows.append({
            "chain_id": chain, "dG_total": total,
            "dG_total_per_residue": total / count,
            "dG_interchain": inter,
            "dG_interchain_per_residue": inter / count,
            "dG_interchain_per_buried_A2": inter / buried_inter if buried_inter > 0 else None,
            **_layer_fields(chain, layer_assignments),
            "coverage_fraction": sum(row["coverage_fraction"] for row in rows) / count,
        })
    return atom_rows, residue_rows, chain_rows, warnings


def score_sawaya(
    assembly: list[Atom], layer_assignments: dict[str, dict[str, Any]] | None = None,
    config: EnergyConfig | None = None,
    input_identity: dict[str, Any] | None = None,
) -> EnergyResult:
    config = config or EnergyConfig()
    from .io import validate_energy_atoms

    assembly, validation = validate_energy_atoms(assembly, config.unsupported_policy)
    if config.mode == "sawaya_compat":
        if config.sphere_points != 1000 or not abs(config.probe_radius - 1.4) < 1e-12:
            raise ValueError("sawaya_compat requires 1000 sphere points and a 1.4 A probe")
        sasa = calculate_sawaya_surface(assembly, config=config)
    elif config.mode == "freesasa_interchain":
        sasa = calculate_freesasa_states(assembly, config=config)
    else:
        raise ValueError(f"Unknown scoring mode: {config.mode}")
    interactions = detect_energy_interactions(assembly, sasa, config)
    asp = assign_atomic_solvation_parameters(assembly, sasa, interactions, config.ph, config)
    entropy = calculate_sidechain_entropy(assembly, sasa, config)
    atom_rows, residue_rows, chain_rows, warnings = aggregate_energy(
        assembly, sasa, interactions, asp, entropy, layer_assignments
    )
    layer_summary: dict[str, dict[str, list[float]]] = {}
    for row in chain_rows:
        classification = str(row["end_or_central"])
        bucket = layer_summary.setdefault(classification, {"dG_total": [], "dG_interchain": []})
        bucket["dG_total"].append(row["dG_total"])
        bucket["dG_interchain"].append(row["dG_interchain"])
    convergence = _central_layer_convergence(
        assembly, layer_assignments or {}, config
    )
    within_parameterized = (
        sum(row["coverage_fraction"] for row in residue_rows) / len(residue_rows)
        if residue_rows else 0.0
    )
    effective_coverage = (
        validation["parameterized_fraction_of_all_polymer_residues"]
        * within_parameterized
    )
    parameter_document = asdict(config)
    # Resource allocation is provenance, not a change to the scientific model.
    parameter_document.pop("threads", None)
    metadata = {
        "schema_version": SCHEMA_VERSION,
        "prediction_id": (input_identity or {}).get("prediction_id"),
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "mode": config.mode,
        "ph": config.ph,
        "terminal_state_policy": config.terminal_policy,
        "explicit_n_termini": [list(key) for key in config.n_termini],
        "explicit_c_termini": [list(key) for key in config.c_termini],
        "source_oracle": SOURCE_VERSION,
        "source_oracle_sha256": SOURCE_SHA256,
        "source_license": SOURCE_LICENSE,
        "surface": sasa.metadata,
        "sign_convention": "negative dG is favorable; dG=-0.001*ASP*buried_area+TdeltaS",
        "entropy_profile": "Koehl-Delarue 1994 values as encoded by Sawaya 7.2u",
        "atom_count": len(assembly),
        "buried_polar_sasa_threshold_A2": 10.0,
        "layer_distributions": layer_summary,
        "input": dict(input_identity or {}),
        "parameter_hash": __import__("hashlib").sha256(
            repr(sorted(parameter_document.items())).encode("utf-8")
        ).hexdigest(),
        "parameters": parameter_document,
        "resources": {"threads": config.threads},
        "central_layer_convergence": convergence,
        "coverage": {
            **{key: value for key, value in validation.items() if key != "warnings"},
            "completeness_within_parameterized_residues": within_parameterized,
            "effective_energy_coverage_fraction": effective_coverage,
        },
    }
    return EnergyResult(metadata, atom_rows, residue_rows, chain_rows,
                        {"hydrogen_bonds": interactions.hbonds, "ion_pairs": interactions.ion_pairs},
                        [*validation["warnings"], *warnings])


def _central_layer_convergence(
    atoms: list[Atom],
    layer_assignments: dict[str, dict[str, Any]],
    config: EnergyConfig,
) -> dict[str, Any]:
    """Rescore centered 3/5/7-layer windows and compare central-chain energy."""
    if not config.calculate_central_layer_convergence:
        return {"available": False, "score": None, "reason": "disabled_for_nested_rescoring"}
    by_protofilament: dict[str, list[tuple[int, str]]] = defaultdict(list)
    for chain, assignment in layer_assignments.items():
        if assignment.get("observed_or_virtual", "observed") != "observed":
            continue
        layer = assignment.get("layer", assignment.get("layer_index"))
        protofilament = str(assignment.get("protofilament", assignment.get("protofilament_id", "PF1")))
        if layer is not None:
            by_protofilament[protofilament].append((int(layer), chain))
    eligible = {
        protofilament: sorted(items)
        for protofilament, items in by_protofilament.items()
        if len(items) >= 7
    }
    if not eligible:
        return {
            "available": False,
            "score": None,
            "reason": "fewer_than_seven_assigned_observed_layers",
        }
    depth_values: dict[str, float] = {}
    depth_chains: dict[str, list[str]] = {}
    for depth in (3, 5, 7):
        selected: set[str] = set()
        central: set[str] = set()
        for ordered in eligible.values():
            center = len(ordered) // 2
            half = depth // 2
            window = ordered[center - half:center + half + 1]
            selected.update(chain for _layer, chain in window)
            central.add(ordered[center][1])
        subset = [atom for atom in atoms if atom.chain_id in selected]
        if not subset or not central:
            return {"available": False, "score": None, "reason": f"no_centered_{depth}_layer_window"}
        nested_assignments = {
            chain: assignment for chain, assignment in layer_assignments.items()
            if chain in selected
        }
        nested = score_sawaya(
            subset,
            nested_assignments,
            replace(config, calculate_central_layer_convergence=False),
        )
        values = [
            row["dG_interchain_per_residue"] for row in nested.chains
            if row["chain_id"] in central
        ]
        if not values:
            return {"available": False, "score": None, "reason": f"central_energy_unavailable_at_depth_{depth}"}
        depth_values[str(depth)] = float(median(values))
        depth_chains[str(depth)] = sorted(central)
    changes = {}
    for first, second in ((3, 5), (5, 7)):
        delta = depth_values[str(second)] - depth_values[str(first)]
        changes[f"{first}_to_{second}"] = {
            "absolute": delta,
            "relative": abs(delta) / max(abs(depth_values[str(second)]), 1e-12),
        }
    largest_relative = max(item["relative"] for item in changes.values())
    tolerance = config.convergence_relative_tolerance
    return {
        "available": True,
        "score": (1.0 if largest_relative <= tolerance else 0.0) if tolerance is not None else None,
        "reason": None if tolerance is not None else "relative_tolerance_not_calibrated",
        "relative_tolerance": tolerance,
        "central_dG_interchain_per_residue_by_depth": depth_values,
        "central_chains_by_depth": depth_chains,
        "eligible_protofilaments": sorted(eligible),
        "excluded_protofilaments": sorted(set(by_protofilament) - set(eligible)),
        "changes": changes,
        "largest_relative_change": largest_relative,
    }
