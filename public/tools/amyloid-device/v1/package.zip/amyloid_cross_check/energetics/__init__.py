"""Sawaya-style solvent-accessible surface energetics.

The compatibility implementation is derived from Eric Sawaya's
``accessiblesurfacearea_v07.2u.f`` (Amyloid Illustrator, CC BY 4.0).
"""

from .model import Atom, EnergyConfig, EnergyResult
from .scoring import score_sawaya

__all__ = ["Atom", "EnergyConfig", "EnergyResult", "score_sawaya"]

