"""Pre-classification quality gates shared by rule and calibrated outputs."""

from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any, Mapping

from .model import AssemblyConfig, QualityGateResult


ASSESSABLE_LAYER_STATES = {
    "direct_five_or_more_layers",
    "direct_three_or_four_layers",
}
LIMITED_LAYER_STATES = {"two_layer_extrapolation_only"}


def _mapping(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if is_dataclass(value):
        return asdict(value)
    if isinstance(value, Mapping):
        return dict(value)
    return {}


def apply_quality_gates(
    common: Any,
    geometry: Any,
    energy_features: Mapping[str, Any],
    config: AssemblyConfig | None = None,
) -> QualityGateResult:
    config = config or AssemblyConfig()
    common_doc, geometry_doc = _mapping(common), _mapping(geometry)
    qc = _mapping(common_doc.get("quality_control"))
    geometry_quality = _mapping(geometry_doc.get("quality"))
    failures: list[str] = []
    warnings: list[str] = []

    common_assessability = str(common_doc.get("assessability") or "unknown")
    geometry_assessability = str(geometry_doc.get("assessability") or "unknown")
    # amyloid-common-1.2 used ``severe_clashes`` as an assessability state and
    # therefore hid the independently calculated geometry/layer state.  Keep
    # old bundles usable by recovering the geometry state here; physical
    # plausibility is evaluated separately below.
    assessability = (
        geometry_assessability
        if common_assessability == "severe_clashes"
        and geometry_assessability != "unknown"
        else common_assessability
        if common_assessability != "unknown"
        else geometry_assessability
    )
    validity = _mapping(common_doc.get("component_validity"))
    coordinate_coverage = validity.get(
        "geometry_coverage", qc.get("geometry_coverage_fraction")
    )
    if coordinate_coverage is None:
        missing = float(geometry_quality.get("missing_backbone_residue_count", 0) or 0)
        residues = float(geometry_doc.get("input", {}).get("residue_count", 0) or 0)
        coordinate_coverage = 1.0 - missing / max(1.0, residues)
    coordinate_coverage = float(coordinate_coverage)

    severe_clashes = qc.get("severe_clashes")
    if isinstance(severe_clashes, list):
        severe_clash_count = len(severe_clashes)
        catastrophic_clash_count = sum(
            1
            for clash in severe_clashes
            if clash.get("distance_A") is None
            or float(clash["distance_A"]) < config.catastrophic_clash_distance
        )
        intrachain_severe_clash_count = sum(
            clash.get("scope") == "intrachain" for clash in severe_clashes
        )
        interchain_severe_clash_count = sum(
            clash.get("scope") == "interchain" for clash in severe_clashes
        )
        minimum_severe_clash_distance = min(
            (
                float(clash["distance_A"])
                for clash in severe_clashes
                if clash.get("distance_A") is not None
            ),
            default=None,
        )
    else:
        severe_clash_count = int(
            severe_clashes
            or geometry_quality.get("observed_severe_interchain_clash_count", 0)
            or 0
        )
        catastrophic_clash_count = severe_clash_count
        intrachain_severe_clash_count = None
        interchain_severe_clash_count = None
        minimum_severe_clash_distance = None
    energy_coverage = energy_features.get("energy_coverage_fraction")
    packing_coverage = validity.get(
        "packing_coverage", qc.get("packing_coverage_fraction")
    )

    parse_counts = qc.get("counts", {})
    chain_count = parse_counts.get("chains", geometry_doc.get("input", {}).get("chain_count"))
    atom_count = parse_counts.get("atoms")
    component_failures: dict[str, list[str]] = {
        "geometry": [],
        "packing": [],
        "energy": [],
    }
    if config.require_common and not common_doc:
        failures.append("canonical_common_result_required")
    if chain_count is None or int(chain_count) < 1:
        failures.append("input_not_successfully_parsed")
    if coordinate_coverage < config.minimum_coordinate_coverage:
        component_failures["geometry"].append("insufficient_coordinate_coverage")
    if assessability not in ASSESSABLE_LAYER_STATES:
        component_failures["geometry"].append(
            "direct_chain_equivalence_or_layer_assignment_unavailable"
        )
    if energy_coverage is None:
        component_failures["energy"].append("energy_parameter_coverage_unavailable")
    elif float(energy_coverage) < config.minimum_energy_coverage:
        component_failures["energy"].append("insufficient_energy_parameter_coverage")
    if packing_coverage is None:
        component_failures["packing"].append("packing_coordinate_coverage_unavailable")
    elif float(packing_coverage) < config.minimum_packing_coverage:
        component_failures["packing"].append("insufficient_packing_coordinate_coverage")
    topology_status = geometry_doc.get("topology", {}).get("status")
    if topology_status not in (None, "matched"):
        component_failures["geometry"].append("layer_topology_disagreement")
    if assessability == "two_layer_extrapolation_only":
        warnings.append("Only two observed layers; ordinary calibrated probability is disabled")
    if energy_coverage is not None and float(energy_coverage) < 1.0:
        warnings.append("Energetic result has partial parameter coverage")

    if config.require_layer_assignment:
        failures.extend(component_failures["geometry"])
    if config.require_energy_coverage:
        failures.extend(component_failures["energy"])
    if config.require_packing_coverage:
        failures.extend(component_failures["packing"])

    implausible = catastrophic_clash_count > config.maximum_catastrophic_clashes
    if implausible:
        failures.append("catastrophic_atom_overlaps")
        qc_status = "physically_implausible"
    elif failures:
        qc_status = "not_assessable"
    else:
        qc_status = "pass"
    if severe_clash_count:
        warnings.append(
            f"{severe_clash_count} nonlocal heavy-atom overlaps below 2.0 A; "
            f"{catastrophic_clash_count} below {config.catastrophic_clash_distance:.2f} A"
        )
    technical_pass = qc_status == "pass"
    component_eligibility = {
        "geometry_direct": technical_pass and not component_failures["geometry"],
        "geometry_limited": (
            technical_pass
            and assessability in LIMITED_LAYER_STATES
            and "insufficient_coordinate_coverage" not in component_failures["geometry"]
            and "layer_topology_disagreement" not in component_failures["geometry"]
        ),
        "packing": technical_pass and not component_failures["packing"],
        "energy": technical_pass and not component_failures["energy"],
    }
    severe_clash_density = (
        1000.0 * severe_clash_count / float(atom_count)
        if atom_count not in (None, 0)
        else None
    )
    measurements = {
        "coordinate_coverage": coordinate_coverage,
        "minimum_coordinate_coverage": config.minimum_coordinate_coverage,
        "severe_clash_count": severe_clash_count,
        "intrachain_severe_clash_count": intrachain_severe_clash_count,
        "interchain_severe_clash_count": interchain_severe_clash_count,
        "minimum_severe_clash_distance_A": minimum_severe_clash_distance,
        "severe_clash_density_per_1000_atoms": severe_clash_density,
        "catastrophic_clash_count": catastrophic_clash_count,
        "catastrophic_clash_distance_A": config.catastrophic_clash_distance,
        "maximum_catastrophic_clashes": config.maximum_catastrophic_clashes,
        "energy_coverage": energy_coverage,
        "minimum_energy_coverage": config.minimum_energy_coverage,
        "packing_coverage": packing_coverage,
        "minimum_packing_coverage": config.minimum_packing_coverage,
        "layer_assessability": assessability,
        "common_assessability": common_assessability,
        "geometry_assessability": geometry_assessability,
        "topology_status": topology_status,
    }
    return QualityGateResult(
        assessability,
        qc_status,
        qc_status == "pass",
        failures,
        warnings,
        measurements,
        component_eligibility,
        component_failures,
    )
