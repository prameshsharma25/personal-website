"""Frozen positive-reference gate interpretation for candidate assessment."""
