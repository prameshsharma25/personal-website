"""Interpret one structural-pipeline result using frozen Atlas positive-reference bands.

This command uses no experimental target structure or benchmark outcome label.
The bands describe similarity to known amyloids, not a calibrated probability
of amyloid formation or an amyloid-versus-soluble classifier.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
import json
import math
from pathlib import Path
from statistics import median
import sys
import tempfile
from typing import Any

from .features import assemble_feature_groups
from .qc import apply_quality_gates
from .reference_gates import evaluate_positive_reference_gates, soluble_intrachain_core


def _read_object(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected a JSON object in {path}")
    return value


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _resolve(value: str, base: Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else base / path


def assess_manifest(manifest_path: Path) -> dict[str, Any]:
    """Read one completed structural manifest and interpret its components."""
    manifest_path = manifest_path.resolve()
    manifest = _read_object(manifest_path)
    rows = manifest.get("rows")
    if not isinstance(rows, list) or len(rows) != 1 or not isinstance(rows[0], dict):
        raise ValueError("Expected a structural manifest with exactly one result row")
    row = rows[0]
    names = ("common", "geometry", "packing", "energy")
    paths: dict[str, Path] = {}
    documents: dict[str, dict[str, Any]] = {}
    for name in names:
        value = row.get(name)
        if not isinstance(value, str) or not value:
            raise ValueError(f"Manifest row is missing {name} JSON path")
        path = _resolve(value, manifest_path.parent)
        paths[name] = path
        documents[name] = _read_object(path)

    groups, _ = assemble_feature_groups(
        documents["geometry"], documents["packing"], documents["energy"]
    )
    qc = apply_quality_gates(
        documents["common"], documents["geometry"], groups["energy"]
    )
    soluble_core = soluble_intrachain_core(groups["soluble"])
    repeats = [
        float(item["R_pack"])
        for item in documents["packing"].get("repetition", [])
        if item.get("R_pack") is not None
        and math.isfinite(float(item["R_pack"]))
    ]
    repeat_score = median(repeats) if repeats else None
    reference = evaluate_positive_reference_gates(
        qc_status=qc.qc_status,
        geometry_score=groups["geometry"]["G_geometry"],
        packing_score=groups["packing"]["D_sasa"],
        interchain_energy_per_residue=groups["energy"]["dG_interchain_per_residue"],
        soluble_core_score=soluble_core["N_soluble_core"],
        packing_repeat_score=repeat_score,
        geometry_eligible=qc.component_eligibility["geometry_direct"],
        geometry_limited=qc.component_eligibility["geometry_limited"],
        packing_eligible=qc.component_eligibility["packing"],
        energy_eligible=qc.component_eligibility["energy"],
    )
    return {
        "schema_version": "amyloid-candidate-gate-report-1.0",
        "prediction_id": row.get("prediction_id"),
        "interpretation_scope": "known_amyloid_positive_reference_only",
        "source_manifest": {
            "path": str(manifest_path),
            "sha256": _sha256(manifest_path),
            "request_fingerprint_sha256": manifest.get("request_fingerprint_sha256"),
        },
        "component_inputs": {
            name: {"path": str(path), "sha256": _sha256(path)}
            for name, path in paths.items()
        },
        "quality_gate": asdict(qc),
        "component_features": groups,
        "soluble_intrachain_core": soluble_core,
        "packing_repeat_score": repeat_score,
        "positive_reference_gates": reference,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True,
                        help="One completed amyloid-structural-pipeline manifest")
    parser.add_argument("--output", type=Path, required=True,
                        help="Output gate-report JSON path")
    args = parser.parse_args(argv)
    try:
        report = assess_manifest(args.manifest)
        protected = {args.manifest.resolve()} | {
            Path(item["path"]).resolve()
            for item in report["component_inputs"].values()
        }
        if args.output.resolve() in protected:
            raise ValueError("--output must not overwrite a component or manifest input")
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=args.output.parent,
            prefix=f".{args.output.name}.", suffix=".tmp", delete=False,
        ) as handle:
            json.dump(report, handle, indent=2, sort_keys=True, allow_nan=False)
            handle.write("\n")
            temp_path = Path(handle.name)
        temp_path.replace(args.output)
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
