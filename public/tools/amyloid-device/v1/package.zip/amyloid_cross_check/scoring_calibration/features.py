"""Feature extraction from the versioned sibling-pipeline result schemas."""

from __future__ import annotations

import math
from dataclasses import asdict, is_dataclass
from statistics import median
from typing import Any, Iterable, Mapping

import numpy as np


SOLUBLE_FEATURE_SCHEMA = "amyloid-soluble-features-1.0"


def _mapping(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if is_dataclass(value):
        return asdict(value)
    if isinstance(value, Mapping):
        return dict(value)
    if hasattr(value, "to_dict"):
        return dict(value.to_dict())
    raise TypeError(f"Expected a mapping or dataclass, received {type(value).__name__}")


def _finite(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _values(values: Iterable[Any]) -> list[float]:
    return [number for value in values if (number := _finite(value)) is not None]


def _median(values: Iterable[Any]) -> float | None:
    numbers = _values(values)
    return float(median(numbers)) if numbers else None


def _mean(values: Iterable[Any]) -> float | None:
    numbers = _values(values)
    return float(np.mean(numbers)) if numbers else None


def _relative_mad(values: Iterable[Any]) -> float | None:
    numbers = _values(values)
    if len(numbers) < 2:
        return None
    center = median(numbers)
    return float(median(abs(value - center) for value in numbers) / max(abs(center), 1e-12))


def _primary_protofilament(geometry: dict[str, Any]) -> dict[str, Any]:
    protofilaments = [dict(item) for item in geometry.get("protofilaments", [])]
    if not protofilaments:
        return {}
    return max(
        protofilaments,
        key=lambda item: (_finite(item.get("G_geometry")) is not None, _finite(item.get("G_geometry")) or -math.inf),
    )


def geometry_features(document: Any) -> dict[str, Any]:
    geometry = _mapping(document)
    primary = _primary_protofilament(geometry)
    cross = dict(primary.get("cross_beta", {}))
    repeat = dict(primary.get("repeat", {}))
    extension = dict(primary.get("extension", {}))
    finite_topology = dict(geometry.get("finite_topology", {}))
    quality = dict(geometry.get("quality", {}))
    aggregation = dict(geometry.get("geometry_aggregation", {}))
    topology = dict(geometry.get("topology", {}))
    rise_mad = _finite(repeat.get("rise_mad"))
    twist_mad = _finite(repeat.get("twist_mad"))
    transform_dispersion = _mean(
        value for value in (
            rise_mad,
            twist_mad,
            repeat.get("transform_composition_rmsd"),
        ) if value is not None
    )
    extension_is_independent = primary.get("extension_evidence") != "extrapolative_only"
    return {
        "assembly_induced_beta_fraction": _finite(cross.get("assembly_induced_beta_fraction")),
        "interchain_backbone_hbond_fraction": _finite(cross.get("interchain_hbond_fraction")),
        "longest_ladder_length": _finite(cross.get("longest_hbond_ladder")),
        "median_ladder_length": _finite(cross.get("median_ladder_length")),
        "ladder_coverage": _finite(cross.get("ladder_coverage")),
        "axial_rise_A": _finite(repeat.get("rise_median")),
        "twist_degrees": _finite(repeat.get("twist_median")),
        "rise_mad_A": rise_mad,
        "twist_mad_degrees": twist_mad,
        "transform_composition_rmsd_A": _finite(repeat.get("transform_composition_rmsd")),
        "transform_dispersion": transform_dispersion,
        "contact_map_repeat_similarity": _finite(repeat.get("contact_consistency")),
        "hbond_repeat_similarity": _finite(repeat.get("hbond_consistency")),
        "virtual_extension_contact_similarity": _finite(extension.get("extension_contact_similarity")),
        "virtual_extension_hbond_similarity": _finite(extension.get("extension_hbond_similarity")),
        "virtual_extension_clashes": _finite(extension.get("extension_clash_count")),
        "virtual_extension_nonlocal_clashes": _finite(extension.get("extension_nonlocal_clash_count")),
        "extension_evidence": primary.get("extension_evidence"),
        "closed_topology_indicator": bool(finite_topology.get("chain_graph_closes_ring", False)),
        "compact_finite_cycle": bool(finite_topology.get("compact_finite_cycle", False)),
        "intrachain_contact_count": _finite(finite_topology.get("intrachain_residue_contact_count")),
        "interchain_contact_count": _finite(finite_topology.get("repeated_interchain_residue_contact_count")),
        "intrachain_contact_fraction": _finite(finite_topology.get("intrachain_contact_fraction")),
        "central_contact_concentration": _finite(finite_topology.get("central_contact_concentration")),
        "global_ca_anisotropy": _finite(finite_topology.get("global_ca_anisotropy")),
        "C_beta": _finite(cross.get("c_beta_score")),
        "R_repeat": _finite(repeat.get("r_repeat_score")),
        "E_extend": _finite(extension.get("e_extend_score")) if extension_is_independent else None,
        "G_geometry": _finite(geometry.get("geometry_score", primary.get("G_geometry"))),
        "G_geometry_support_weighted": _finite(aggregation.get("support_weighted_score")),
        "selected_path_chain_fraction": _finite(aggregation.get("selected_path_chain_fraction")),
        "geometry_interpretation_gap": _finite(aggregation.get("best_minus_next_score")),
        "geometry_interpretation_ambiguous": bool(aggregation.get("ambiguous_best_interpretation", False)),
        "geometry_assessability": geometry.get("assessability"),
        "topology_source": topology.get("source"),
        "topology_status": topology.get("status"),
        "observed_geometry_clashes": _finite(quality.get("observed_severe_interchain_clash_count")),
        "geometry_coordinate_coverage": (
            1.0 - (_finite(quality.get("missing_backbone_residue_count")) or 0.0)
            / max(1.0, _finite(geometry.get("input", {}).get("residue_count")) or 0.0)
        ),
    }


def _packing_subset(interfaces: list[dict[str, Any]], interface_type: str) -> dict[str, Any]:
    selected = [
        item for item in interfaces
        if item.get("definition", {}).get("interface_type") == interface_type
        and item.get("definition", {}).get("observed_or_virtual", "observed") == "observed"
    ]
    return {
        "interface_count": len(selected),
        "delta_sasa_total_A2": _median(item.get("sasa", {}).get("delta_sasa_total") for item in selected),
        "bsa_half_A2": _median(item.get("sasa", {}).get("bsa_half") for item in selected),
        "fraction_partner_sasa_buried": _median(item.get("sasa", {}).get("fraction_sasa_buried") for item in selected),
        "bsa_per_interface_residue_A2": _median(item.get("sasa", {}).get("bsa_per_interface_residue") for item in selected),
        "delta_sasa_total_per_interface_residue_A2": _median(
            item.get("features", {}).get("delta_sasa_total_per_interface_residue_A2")
            for item in selected
        ),
        "bsa_half_per_mean_partner_interface_residue_A2": _median(
            item.get("features", {}).get("bsa_half_per_mean_partner_interface_residue_A2")
            for item in selected
        ),
        "polar_buried_area_A2": _median(item.get("features", {}).get("delta_sasa_polar_A2") for item in selected),
        "nonpolar_buried_area_A2": _median(item.get("features", {}).get("delta_sasa_nonpolar_A2") for item in selected),
        "polar_satisfaction_fraction": _median(
            item.get("polar", {}).get(
                "deep_polar_satisfaction_fraction",
                item.get("polar", {}).get("polar_satisfaction_fraction"),
            )
            for item in selected
        ),
        "buried_unsatisfied_polar_per_residue": _median(item.get("polar", {}).get("buried_unsatisfied_polar_per_residue") for item in selected),
        "deeply_buried_unsatisfied_polar_fraction": _median(
            item.get("features", {}).get("deeply_buried_unsatisfied_polar_fraction")
            for item in selected
        ),
        "clash_density": _median(item.get("clashes", {}).get("severe_clashes_per_interface_residue") for item in selected),
        "shape_complementarity": _median(item.get("shape_complementarity", {}).get("value") for item in selected),
        "gap_ratio": _median(item.get("gap_penalty", {}).get("value") for item in selected),
        "R_pack": _median(item.get("features", {}).get("R_pack") for item in selected),
        "interface_repeat_consistency": _median(
            item.get("features", {}).get("interface_repeat_consistency")
            for item in selected
        ),
        "D_sasa": _median(item.get("d_sasa_score", item.get("features", {}).get("D_sasa")) for item in selected),
        "D_zipper": _median(item.get("d_zipper_score", item.get("features", {}).get("D_zipper")) for item in selected),
        "D_packing": _median(item.get("dry_packing_score") for item in selected),
    }


def packing_features(document: Any) -> dict[str, Any]:
    packing = _mapping(document)
    interfaces = [dict(item) for item in packing.get("interfaces", [])]
    observed = [
        item for item in interfaces
        if item.get("definition", {}).get("observed_or_virtual", "observed") == "observed"
    ]
    repetitions = [dict(item) for item in packing.get("repetition", [])]
    dry_scores = _values(item.get("dry_packing_score") for item in observed)
    sasa_scores = _values(
        item.get("d_sasa_score", item.get("features", {}).get("D_sasa"))
        for item in observed
    )
    zipper_scores = _values(
        item.get("d_zipper_score", item.get("features", {}).get("D_zipper"))
        for item in observed
    )
    return {
        "bsa_convention": "delta_sasa_total=SASA_A+SASA_B-SASA_AB; bsa_half=delta_sasa_total/2",
        "axial": _packing_subset(interfaces, "axial"),
        "lateral": _packing_subset(interfaces, "lateral"),
        "all_observed": _packing_subset(
            [{**item, "definition": {**item.get("definition", {}), "interface_type": "all"}} for item in observed],
            "all",
        ),
        "interface_to_interface_bsa_relative_mad": _median(
            item.get("bsa_relative_mad") for item in repetitions
        ),
        "interface_to_interface_polar_relative_mad": _median(
            item.get("polar_satisfaction_relative_mad") for item in repetitions
        ),
        "interface_to_interface_clash_relative_mad": _median(
            item.get("clash_rate_relative_mad") for item in repetitions
        ),
        "D_packing": float(median(dry_scores)) if dry_scores else None,
        "D_sasa": float(median(sasa_scores)) if sasa_scores else None,
        "D_zipper": float(median(zipper_scores)) if zipper_scores else None,
        "C_clash": _median(item.get("features", {}).get("C_clash") for item in observed),
        "optional_feature_status": {
            "shape_complementarity_available": any(item.get("shape_complementarity", {}).get("available") for item in observed),
            "gap_ratio_available": any(item.get("gap_penalty", {}).get("available") for item in observed),
        },
    }


def _chain_class(row: dict[str, Any]) -> str:
    return str(row.get("end_or_central", "unassigned"))


def _atom_chain(atom_key: Any) -> str:
    return str(atom_key or "").split(":", 1)[0]


def energy_features(document: Any) -> dict[str, Any]:
    energy = _mapping(document)
    chains = [dict(item) for item in energy.get("chains", [])]
    atoms = [dict(item) for item in energy.get("atoms", [])]
    central = [item for item in chains if _chain_class(item) == "central"] or chains
    ends = [item for item in chains if _chain_class(item) == "end"]
    total_per_residue = _median(item.get("dG_total_per_residue") for item in central)
    inter_per_residue = _median(item.get("dG_interchain_per_residue") for item in central)
    inter_per_area = _median(item.get("dG_interchain_per_buried_A2") for item in central)
    total = _median(item.get("dG_total") for item in central)
    inter = _median(item.get("dG_interchain") for item in central)
    assembly_fraction = (
        abs(inter) / (abs(total) + 1e-12)
        if total is not None and inter is not None else None
    )
    end_energy = _median(item.get("dG_interchain_per_residue") for item in ends)
    end_center = (
        end_energy - inter_per_residue
        if end_energy is not None and inter_per_residue is not None else None
    )
    favorable_fraction = _mean(
        1.0 if value < 0 else 0.0
        for value in _values(item.get("dG_interchain_per_residue") for item in central)
    )
    relative_dispersion = _relative_mad(item.get("dG_interchain_per_residue") for item in central)
    convergence = energy.get("metadata", {}).get("central_layer_convergence")
    coverage_metadata = energy.get("metadata", {}).get("coverage", {})
    convergence_score = _finite(convergence.get("score")) if isinstance(convergence, Mapping) else _finite(convergence)
    evidence_terms = [
        favorable_fraction,
        min(1.0, assembly_fraction) if assembly_fraction is not None else None,
        1.0 / (1.0 + relative_dispersion) if relative_dispersion is not None else None,
        convergence_score,
    ]
    evidence = _mean(value for value in evidence_terms if value is not None)
    total_burial = sum(max(0.0, _finite(item.get("delta_area_total")) or 0.0) for item in atoms)
    inter_burial = sum(max(0.0, _finite(item.get("delta_area_interchain")) or 0.0) for item in atoms)
    intrachain_burial = max(0.0, total_burial - inter_burial)
    h_bonds = energy.get("interactions", {}).get("hydrogen_bonds", [])
    intra_hbonds = sum(
        _atom_chain(item.get("acceptor")) == _atom_chain(item.get("donor"))
        for item in h_bonds
    )
    inter_hbonds = len(h_bonds) - intra_hbonds
    return {
        "dG_total_per_residue": total_per_residue,
        "dG_interchain_per_residue": inter_per_residue,
        "dG_interchain_per_buried_A2": inter_per_area,
        "fraction_stabilization_from_assembly": assembly_fraction,
        "fraction_central_layers_favorable_interchain": favorable_fraction,
        "end_minus_center_dG_interchain_per_residue": end_center,
        "central_layer_convergence": convergence_score,
        "central_layer_convergence_available": (
            bool(convergence.get("available")) if isinstance(convergence, Mapping) else convergence_score is not None
        ),
        "central_layer_convergence_unavailability_reason": (
            convergence.get("reason") if isinstance(convergence, Mapping) else None
        ),
        "energy_dispersion_relative_mad": relative_dispersion,
        "energy_coverage_fraction": _finite(
            coverage_metadata.get("effective_energy_coverage_fraction")
        ) if coverage_metadata else _median(item.get("coverage_fraction") for item in chains),
        "parameterized_fraction_of_all_polymer_residues": _finite(
            coverage_metadata.get("parameterized_fraction_of_all_polymer_residues")
        ),
        "completeness_within_parameterized_residues": _finite(
            coverage_metadata.get("completeness_within_parameterized_residues")
        ),
        "excluded_energy_residues": list(coverage_metadata.get("excluded_residues", [])),
        "total_buried_area_A2": total_burial,
        "interchain_buried_area_A2": inter_burial,
        "intrachain_buried_area_A2": intrachain_burial,
        "intrachain_interchain_burial_ratio": intrachain_burial / (inter_burial + 1e-12),
        "intrachain_hbond_count": intra_hbonds,
        "interchain_hbond_count": inter_hbonds,
        "intrachain_interchain_hbond_ratio": intra_hbonds / (inter_hbonds + 1e-12),
        "E_energy": evidence,
        "energy_mode": energy.get("metadata", {}).get("mode"),
    }


def confidence_features(metadata: Any) -> dict[str, Any]:
    values = _mapping(metadata)
    confidence = dict(values.get("confidence", values))
    mean_plddt = _finite(confidence.get("mean_plddt"))
    interface_plddt = _finite(confidence.get("interface_plddt"))
    iptm = _finite(confidence.get("iptm", confidence.get("ipTM")))
    ranking = _finite(confidence.get("ranking_confidence"))
    agreement = _finite(confidence.get("agreement_across_predictions"))
    normalized = [
        value / 100.0 if value is not None and value > 1.0 else value
        for value in (mean_plddt, interface_plddt)
    ] + [iptm, ranking, agreement]
    score = _mean(value for value in normalized if value is not None and 0.0 <= value <= 1.0)
    return {
        "mean_plddt": mean_plddt,
        "interface_plddt": interface_plddt,
        "interface_pae": _finite(confidence.get("interface_pae")),
        "ipTM": iptm,
        "ranking_confidence": ranking,
        "agreement_across_predictions": agreement,
        "C_confidence": score,
    }


def soluble_features(
    geometry: dict[str, Any], energy: dict[str, Any], metadata: Any = None
) -> dict[str, Any]:
    auxiliary = _mapping(metadata)
    residue_count = _finite(auxiliary.get("residue_count"))
    contact_density = (
        geometry.get("intrachain_contact_count") / residue_count
        if residue_count and geometry.get("intrachain_contact_count") is not None else None
    )
    normalized_rg = _finite(auxiliary.get("normalized_radius_of_gyration"))
    normalized_compactness = _finite(auxiliary.get("normalized_compactness"))
    assembly_fraction = energy.get("fraction_stabilization_from_assembly")
    total_energy = energy.get("dG_total_per_residue")
    favorable_total_weak_interchain = (
        1.0 - min(1.0, assembly_fraction)
        if total_energy is not None and total_energy < 0 and assembly_fraction is not None else None
    )
    burial_ratio = energy.get("intrachain_interchain_burial_ratio")
    hbond_ratio = energy.get("intrachain_interchain_hbond_ratio")
    burial_intrachain_fraction = (
        burial_ratio / (1.0 + burial_ratio)
        if burial_ratio is not None and burial_ratio >= 0 else None
    )
    hbond_intrachain_fraction = (
        hbond_ratio / (1.0 + hbond_ratio)
        if hbond_ratio is not None and hbond_ratio >= 0 else None
    )
    inverse_normalized_rg = (
        1.0 - normalized_rg
        if normalized_rg is not None and 0.0 <= normalized_rg <= 1.0
        else None
    )
    score_components = {
        "intrachain_burial_fraction": burial_intrachain_fraction,
        "intrachain_hbond_fraction": hbond_intrachain_fraction,
        "intrachain_contact_fraction": geometry.get("intrachain_contact_fraction"),
        "normalized_compactness": normalized_compactness,
        "inverse_normalized_radius_of_gyration": inverse_normalized_rg,
        "closed_ring_or_finite_oligomer": (
            1.0 if geometry.get("closed_topology_indicator") else 0.0
        ),
        "favorable_total_energy_with_weak_interchain": favorable_total_weak_interchain,
    }
    available_components = _values(score_components.values())
    n_soluble = _mean(available_components)
    return {
        "intrachain_interchain_burial_ratio": energy.get("intrachain_interchain_burial_ratio"),
        "intrachain_burial_fraction": burial_intrachain_fraction,
        "intrachain_interchain_hbond_ratio": energy.get("intrachain_interchain_hbond_ratio"),
        "intrachain_hbond_fraction": hbond_intrachain_fraction,
        "normalized_radius_of_gyration": normalized_rg,
        "inverse_normalized_radius_of_gyration": inverse_normalized_rg,
        "normalized_compactness": normalized_compactness,
        "intrachain_contact_density": contact_density,
        "intrachain_contact_fraction": geometry.get("intrachain_contact_fraction"),
        "closed_ring_or_finite_oligomer": bool(geometry.get("closed_topology_indicator")),
        "central_contact_concentration": geometry.get("central_contact_concentration"),
        "favorable_total_energy_with_weak_interchain": favorable_total_weak_interchain,
        "N_soluble": n_soluble,
        "N_soluble_component_count": len(available_components),
        "N_soluble_component_fraction": len(available_components) / len(score_components),
    }


def assemble_feature_groups(
    geometry: Any,
    packing: Any,
    energy: Any,
    *,
    prediction_metadata: Any = None,
    structural_metadata: Any = None,
) -> tuple[dict[str, dict[str, Any]], dict[str, float | None]]:
    """Return full interpretable groups and the canonical logistic feature vector."""
    geometry_group = geometry_features(geometry)
    packing_group = packing_features(packing)
    energy_group = energy_features(energy)
    soluble_group = soluble_features(geometry_group, energy_group, structural_metadata)
    confidence_group = confidence_features(prediction_metadata)
    groups = {
        "geometry": geometry_group,
        "packing": packing_group,
        "energy": energy_group,
        "soluble": soluble_group,
        "confidence": confidence_group,
    }
    features = {
        "C_beta": geometry_group["C_beta"],
        "R_repeat": geometry_group["R_repeat"],
        "E_extend": geometry_group["E_extend"],
        "D_packing": packing_group["D_packing"],
        # Sign is reversed so larger values mean more favorable interchain energy.
        "E_interchain": (
            -energy_group["dG_interchain_per_residue"]
            if energy_group["dG_interchain_per_residue"] is not None else None
        ),
        "N_globular": soluble_group["N_soluble"],
        "C_clash": packing_group["C_clash"],
    }
    return groups, features
