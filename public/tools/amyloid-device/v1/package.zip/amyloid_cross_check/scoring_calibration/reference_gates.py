"""Positive-reference gates for reference-free amyloid assembly assessment.

These gates describe compatibility with the validated Amyloid Atlas reference
distribution. They are deliberately not amyloid-versus-soluble classifier
thresholds: the current reference set contains known amyloids but no matched
negative assemblies.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import math
from typing import Any, Mapping


REFERENCE_GATE_SCHEMA = "amyloid-positive-reference-gates-1.0"


def _finite(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


@dataclass(frozen=True)
class PositiveReferenceBands:
    """Frozen Atlas-derived bands used by the prediction gate pilot."""

    schema_version: str = REFERENCE_GATE_SCHEMA
    source_run_id: str = "reference-distributions-soluble-20261013-161833"
    source_dataset: str = "atlas659_known_amyloid_positive_reference"
    geometry_compatible_q05: float = 0.6667468176998542
    geometry_strong: float = 0.90
    packing_compatible_q05: float = 0.0971035
    packing_typical_q25: float = 0.287223
    packing_repeat_compatible_q05: float = 0.883137
    interchain_energy_compatible_q95: float = 0.08124428377015203
    interchain_energy_favorable: float = 0.0
    soluble_core_high_q95: float = 0.3374937973088313

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


DEFAULT_POSITIVE_REFERENCE_BANDS = PositiveReferenceBands()


def soluble_intrachain_core(features: Mapping[str, Any]) -> dict[str, Any]:
    """Return the three-feature soluble/intrachain counterevidence core.

    A score is returned only when all three components are finite, so partial
    evidence is not silently rescaled into a superficially comparable value.
    """

    names = (
        "intrachain_burial_fraction",
        "intrachain_hbond_fraction",
        "intrachain_contact_fraction",
    )
    values = {name: _finite(features.get(name)) for name in names}
    present = [value for value in values.values() if value is not None]
    score = sum(present) / len(names) if len(present) == len(names) else None
    return {
        "N_soluble_core": score,
        "N_soluble_core_component_count": len(present),
        "N_soluble_core_component_fraction": len(present) / len(names),
        "N_soluble_core_components": values,
    }


def _high_state(value: float | None, compatible: float, strong: float) -> str:
    if value is None:
        return "unavailable"
    if value >= strong:
        return "strong_or_typical"
    if value >= compatible:
        return "compatible"
    return "atypical"


def _low_state(value: float | None, compatible: float, strong: float) -> str:
    if value is None:
        return "unavailable"
    if value <= strong:
        return "strong_or_typical"
    if value <= compatible:
        return "compatible"
    return "atypical"


def evaluate_positive_reference_gates(
    *,
    qc_status: str,
    geometry_score: Any,
    packing_score: Any,
    interchain_energy_per_residue: Any,
    soluble_core_score: Any,
    packing_repeat_score: Any = None,
    geometry_eligible: bool = True,
    geometry_limited: bool = False,
    packing_eligible: bool = True,
    energy_eligible: bool = True,
    bands: PositiveReferenceBands = DEFAULT_POSITIVE_REFERENCE_BANDS,
) -> dict[str, Any]:
    """Apply the frozen hierarchy without fitting to prediction labels."""

    geometry = _finite(geometry_score)
    packing = _finite(packing_score)
    energy = _finite(interchain_energy_per_residue)
    soluble = _finite(soluble_core_score)
    repeat = _finite(packing_repeat_score)

    geometry_state = _high_state(
        geometry, bands.geometry_compatible_q05, bands.geometry_strong
    )
    packing_state = _high_state(
        packing, bands.packing_compatible_q05, bands.packing_typical_q25
    )
    energy_state = _low_state(
        energy,
        bands.interchain_energy_compatible_q95,
        bands.interchain_energy_favorable,
    )
    repeat_state = (
        "unavailable"
        if repeat is None
        else "compatible"
        if repeat >= bands.packing_repeat_compatible_q05
        else "atypical"
    )
    soluble_warning = (
        None if soluble is None else soluble > bands.soluble_core_high_q95
    )

    quality_pass = qc_status == "pass"
    geometry_compatible = quality_pass and geometry_eligible and geometry_state in {
        "compatible", "strong_or_typical"
    }
    packing_compatible = packing_eligible and packing_state in {
        "compatible", "strong_or_typical"
    }
    energy_compatible = energy_eligible and energy_state in {
        "compatible", "strong_or_typical"
    }
    multi_gate_compatible = (
        geometry_compatible and packing_compatible and energy_compatible
    )
    high_support = (
        quality_pass
        and geometry_eligible
        and packing_eligible
        and energy_eligible
        and geometry_state == "strong_or_typical"
        and packing_state == "strong_or_typical"
        and energy_state == "strong_or_typical"
    )

    if not quality_pass:
        classification = "unassessable"
    elif geometry_limited:
        classification = "limited_geometry_evidence"
    elif not geometry_eligible:
        classification = "geometry_not_directly_assessable"
    elif geometry is None:
        classification = "insufficient_amyloid_geometry_evidence"
    elif not geometry_compatible:
        classification = "geometry_atypical_for_known_amyloids"
    elif high_support:
        classification = "amyloid_like_high_support"
    elif multi_gate_compatible:
        classification = "amyloid_compatible"
    else:
        classification = "amyloid_geometry_partial_support"

    warnings: list[str] = []
    if geometry_limited:
        warnings.append("two_layer_geometry_is_extrapolative")
    elif not geometry_eligible:
        warnings.append("direct_geometry_not_assessable")
    if not packing_eligible:
        warnings.append("packing_not_assessable")
    if not energy_eligible:
        warnings.append("interchain_energy_not_assessable")
    if soluble_warning:
        warnings.append("high_intrachain_soluble_counterevidence")
    if geometry_compatible and packing_state == "atypical":
        warnings.append("weak_interface_packing_support")
    if geometry_compatible and energy_state == "atypical":
        warnings.append("weak_or_unfavorable_interchain_energy_support")
    if repeat_state == "atypical":
        warnings.append("atypical_interface_repeat_consistency")
    for name, value in (
        ("packing", packing),
        ("interchain_energy", energy),
        ("soluble_core", soluble),
    ):
        if value is None:
            warnings.append(f"{name}_unavailable")

    return {
        "schema_version": bands.schema_version,
        "reference_source": bands.source_run_id,
        "quality_pass": quality_pass,
        "geometry_eligible": geometry_eligible,
        "geometry_limited": geometry_limited,
        "packing_eligible": packing_eligible,
        "energy_eligible": energy_eligible,
        "geometry_state": geometry_state,
        "packing_state": packing_state,
        "energy_state": energy_state,
        "packing_repeat_state": repeat_state,
        "soluble_counterevidence_high": soluble_warning,
        "geometry_compatible": geometry_compatible,
        "multi_gate_compatible": multi_gate_compatible,
        "high_support": high_support,
        "classification": classification,
        "warnings": warnings,
        "bands": bands.to_dict(),
    }
