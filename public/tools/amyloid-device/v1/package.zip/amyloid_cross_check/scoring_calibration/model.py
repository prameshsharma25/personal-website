"""Typed public records for score assembly and statistical calibration."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal


SCHEMA_VERSION = "amyloid-scoring-calibration-1.2"
MODEL_SCHEMA_VERSION = "amyloid-logistic-model-1.1"
FEATURE_SCHEMA_VERSION = "amyloid-seven-feature-vector-1.1"

Level = Literal["weak", "moderate", "strong", "unavailable"]


@dataclass(slots=True)
class AssemblyConfig:
    """Technical validity and component-specific eligibility settings.

    The default profile no longer requires every component to be eligible in
    order to retain the assessment.  Workflows that explicitly require a
    complete composite can opt back into the three ``require_*`` switches.
    """

    minimum_coordinate_coverage: float = 0.90
    minimum_energy_coverage: float = 0.90
    minimum_packing_coverage: float = 0.90
    catastrophic_clash_distance: float = 1.0
    maximum_catastrophic_clashes: int = 0
    require_layer_assignment: bool = False
    require_energy_coverage: bool = False
    require_packing_coverage: bool = False
    require_common: bool = True


@dataclass(slots=True)
class QualityGateResult:
    assessability: str
    qc_status: Literal["pass", "not_assessable", "physically_implausible"]
    passed: bool
    failures: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    measurements: dict[str, Any] = field(default_factory=dict)
    component_eligibility: dict[str, bool] = field(default_factory=dict)
    component_failures: dict[str, list[str]] = field(default_factory=dict)


@dataclass(slots=True)
class ComponentBundle:
    prediction_id: str
    geometry: dict[str, Any]
    packing: dict[str, Any]
    energy: dict[str, Any]
    common: dict[str, Any] = field(default_factory=dict)
    prediction_metadata: dict[str, Any] = field(default_factory=dict)
    structural_metadata: dict[str, Any] = field(default_factory=dict)
    target_id: str | None = None
    method: str | None = None
    rank_or_seed: str | None = None


@dataclass(slots=True)
class RuleProfile:
    """Benchmark-derived component cutoffs; no defaults are scientific cutoffs."""

    name: str
    component_cutoffs: dict[str, dict[str, float]]
    source: dict[str, Any] = field(default_factory=dict)
    target_sensitivity: float = 0.90
    target_specificity: float = 0.90

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "RuleProfile":
        return cls(
            name=str(value["name"]),
            component_cutoffs={
                str(component): {str(key): float(number) for key, number in cutoffs.items()}
                for component, cutoffs in value["component_cutoffs"].items()
            },
            source=dict(value.get("source", {})),
            target_sensitivity=float(value.get("target_sensitivity", 0.90)),
            target_specificity=float(value.get("target_specificity", 0.90)),
        )


@dataclass(slots=True)
class AssessmentResult:
    prediction_id: str
    target_id: str | None
    method: str | None
    rank_or_seed: str | None
    assessability: str
    qc_status: str
    G_geometry: float | None
    D_packing: float | None
    E_energy: float | None
    N_soluble: float | None
    C_confidence: float | None
    component_levels: dict[str, Level]
    amyloid_probability: float | None
    classification: str
    threshold_profile: str | None
    feature_vector: dict[str, float | None]
    feature_groups: dict[str, dict[str, Any]]
    quality_control: dict[str, Any]
    provenance: dict[str, Any]
    feature_schema_version: str
    geometry_version: str | None
    packing_version: str | None
    energy_version: str | None
    warnings: list[str] = field(default_factory=list)
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class CalibratedLogisticModel:
    feature_names: list[str]
    imputation_medians: list[float]
    standardization_means: list[float]
    standardization_scales: list[float]
    coefficients: list[float]
    intercept: float
    missing_indicator_features: list[str]
    calibration_slope: float = 1.0
    calibration_intercept: float = 0.0
    calibration_status: str = "not_calibrated"
    decision_thresholds: dict[str, float] = field(default_factory=dict)
    training_summary: dict[str, Any] = field(default_factory=dict)
    feature_schema_version: str = FEATURE_SCHEMA_VERSION
    component_schema_versions: dict[str, str] = field(default_factory=lambda: {
        "geometry": "amyloid-geometry-1.2",
        "packing": "amyloid-interface-dryness-1.1",
        "energy": "amyloid-energetics-1.3",
        "common": "amyloid-common-1.2",
    })
    packing_support_policy: str = "sasa_only"
    energy_mode: str = "sawaya_compat"
    energy_parameter_hash: str | None = None
    training_dataset_sha256: str | None = None
    training_split_sha256: str | None = None
    schema_version: str = MODEL_SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "CalibratedLogisticModel":
        if value.get("schema_version") != MODEL_SCHEMA_VERSION:
            raise ValueError(
                f"Unsupported calibrated-model schema {value.get('schema_version')!r}; "
                f"expected {MODEL_SCHEMA_VERSION!r}"
            )
        required_bindings = (
            "feature_schema_version", "component_schema_versions",
            "packing_support_policy", "energy_mode", "energy_parameter_hash",
            "training_dataset_sha256", "training_split_sha256",
        )
        missing = [key for key in required_bindings if value.get(key) in (None, "")]
        if missing:
            raise ValueError(
                "Calibrated model is missing compatibility bindings: "
                + ", ".join(missing)
            )
        component_versions = value.get("component_schema_versions", {})
        if set(component_versions) != {"common", "geometry", "packing", "energy"}:
            raise ValueError(
                "Calibrated model must bind common, geometry, packing, and energy schemas"
            )
        allowed = set(cls.__dataclass_fields__)
        return cls(**{key: item for key, item in value.items() if key in allowed})
