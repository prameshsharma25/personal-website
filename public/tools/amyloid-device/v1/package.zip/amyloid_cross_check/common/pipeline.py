"""End-to-end shared normalization, QC, equivalence, graph, and layer pipeline."""

from __future__ import annotations

import hashlib
import json
import platform
from dataclasses import asdict
from pathlib import Path
from typing import Sequence

import Bio
import numpy as np

from .alignment import all_pair_mappings, group_equivalent_chains
from .contacts import build_chain_contact_graph
from .io import load_assembly
from .layers import infer_layer_assignments, read_explicit_layer_assignments
from .model import AnalysisConfig, Assembly, CommonResult, NormalizationPolicy
from .qc import run_quality_control


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def normalized_assembly_sha256(assembly: Assembly) -> str:
    """Hash the normalized atom identity and coordinates, independent of file formatting."""
    rows = []
    for atom in sorted(assembly.atoms, key=lambda item: item.key):
        rows.append({
            "key": atom.key.text(),
            "coord": [float(value).hex() for value in atom.coord],
            "element": atom.element,
            "occupancy": float(atom.occupancy).hex(),
            "record_type": atom.record_type,
        })
    payload = json.dumps(rows, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def atom_identity_sha256(assembly: Assembly) -> str:
    payload = "\n".join(atom.key.text() for atom in sorted(assembly.atoms, key=lambda item: item.key))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def layer_assignment_sha256(layers: Sequence) -> str:
    """Hash canonical observed/virtual topology independently of row order."""
    rows = sorted(
        (
            str(item.chain_id),
            str(item.protofilament_id),
            int(item.layer_index),
            str(item.observed_or_virtual),
        )
        for item in layers
    )
    payload = json.dumps(rows, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _assessability(result: CommonResult) -> str:
    qc = result.quality_control
    if qc.severe_clashes:
        return "severe_clashes"
    if len(result.assembly.chains) == 1:
        return "single_chain_not_assessable"
    equivalent_contact_edges = [
        edge for edge in result.chain_graph.edges
        if edge.sequence_equivalent and edge.residue_contact_count > 0
    ]
    contact_degrees: dict[str, int] = {}
    for edge in equivalent_contact_edges:
        contact_degrees[edge.chain_a] = contact_degrees.get(edge.chain_a, 0) + 1
        contact_degrees[edge.chain_b] = contact_degrees.get(edge.chain_b, 0) + 1
    # A small component with no graph endpoints is a finite-ring candidate. Larger
    # lattices can contain harmless rectangular cycles between protofilaments.
    if 3 <= len(contact_degrees) <= 4 and all(value == 2 for value in contact_degrees.values()):
        return "ambiguous_layer_assignment"
    if len(result.alternative_layer_assignments) > 1:
        return "ambiguous_layer_assignment"
    if result.alternative_layer_assignments and result.alternative_layer_assignments[0]["closed_components"]:
        return "ambiguous_layer_assignment"
    counts: dict[str, int] = {}
    for assignment in result.layers:
        counts[assignment.protofilament_id] = counts.get(assignment.protofilament_id, 0) + 1
    maximum = max(counts.values(), default=0)
    if maximum >= 5:
        return "direct_five_or_more_layers"
    if maximum >= 3:
        return "direct_three_or_four_layers"
    if maximum == 2:
        return "two_layer_extrapolation_only"
    return "ambiguous_layer_assignment"


def analyze_assembly(
    assembly_or_path: Assembly | str | Path,
    *,
    model_index: int = 0,
    normalization_policy: NormalizationPolicy | None = None,
    config: AnalysisConfig | None = None,
    chain_id_source: str = "auto",
    explicit_layer_map: str | Path | None = None,
    prediction_metadata: dict | None = None,
    expected_chain_count: int | None = None,
    expected_protofilament_count: int | None = None,
    ph: float | None = None,
    command: Sequence[str] | None = None,
) -> CommonResult:
    config = config or AnalysisConfig()
    assembly = (
        assembly_or_path if isinstance(assembly_or_path, Assembly)
        else load_assembly(assembly_or_path, model_index, normalization_policy, chain_id_source)
    )
    quality = run_quality_control(assembly, config)
    mappings = all_pair_mappings(assembly)
    groups = group_equivalent_chains(assembly, config)
    graph = build_chain_contact_graph(assembly, config, mappings)
    if explicit_layer_map is not None:
        layers = read_explicit_layer_assignments(explicit_layer_map, set(assembly.chains))
        alternatives = [{
            "source": "explicit",
            "paths": [
                [item.chain_id for item in sorted(layers, key=lambda layer: layer.layer_index) if item.protofilament_id == protofilament]
                for protofilament in sorted({item.protofilament_id for item in layers})
            ],
            "closed_components": [],
        }]
    else:
        layers, alternatives = infer_layer_assignments(graph, config)
    layer_hash = layer_assignment_sha256(layers)
    warnings = list(assembly.warnings)
    if expected_chain_count is not None and len(assembly.chains) != expected_chain_count:
        warnings.append(f"Expected {expected_chain_count} chains but observed {len(assembly.chains)}")
    observed_protofilaments = len({layer.protofilament_id for layer in layers})
    if expected_protofilament_count is not None and observed_protofilaments != expected_protofilament_count:
        warnings.append(
            f"Expected {expected_protofilament_count} protofilaments but assigned {observed_protofilaments}"
        )
    parameter_document = {
        "model_index": model_index,
        "chain_id_source": chain_id_source,
        "explicit_layer_map": str(explicit_layer_map) if explicit_layer_map else None,
        "expected_chain_count": expected_chain_count,
        "expected_protofilament_count": expected_protofilament_count,
        "ph": ph,
        "normalization": asdict(normalization_policy or NormalizationPolicy()),
        "analysis": asdict(config),
    }
    parameter_hash = hashlib.sha256(
        json.dumps(parameter_document, sort_keys=True, default=sorted).encode("utf-8")
    ).hexdigest()
    metadata = {
        "schema_version": "amyloid-common-1.2",
        "command": list(command) if command is not None else None,
        "parameters": parameter_document,
        "parameter_hash": parameter_hash,
        "input": {
            "path": assembly.source,
            "sha256": sha256_file(assembly.source) if assembly.source else None,
            "source_file_sha256": sha256_file(assembly.source) if assembly.source else None,
            "normalized_assembly_sha256": normalized_assembly_sha256(assembly),
            "atom_identity_sha256": atom_identity_sha256(assembly),
            "layer_assignment_sha256": layer_hash,
            "model_index": assembly.model_index,
            "selected_model_identifier": assembly.parse_report.selected_model_identifier,
            "chain_id_source": assembly.parse_report.chain_id_source,
        },
        "component_validity": {
            "geometry_assessable": quality.geometry_assessable,
            "geometry_coverage": quality.geometry_coverage_fraction,
            "packing_coverage": quality.packing_coverage_fraction,
            "energy_coverage": quality.energy_coverage_fraction,
            "parameterized_fraction_of_all_polymer_residues": quality.parameterized_fraction_of_all_polymer_residues,
            "completeness_within_parameterized_residues": quality.completeness_within_parameterized_residues,
            "physical_plausibility": quality.physical_plausibility,
        },
        "software": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "biopython": Bio.__version__,
        },
        "prediction_metadata": prediction_metadata,
        "prediction_id": (prediction_metadata or {}).get("prediction_id"),
        "definitions": {
            "alternate_location": "highest occupancy; ties prefer blank, then A, then lexical",
            "residue_contact": "CB-CB (CA fallback) distance cutoff",
            "preliminary_bsa": "12*residue_contacts + 0.35*min(heavy_atom_contacts,4000); proxy only",
            "severe_clash": "nonlocal heavy-atom distance below configured cutoff",
        },
        "warnings": warnings,
    }
    result = CommonResult(
        assembly, quality, groups, mappings, graph, layers, "", alternatives, metadata,
    )
    result.assessability = _assessability(result)
    return result
