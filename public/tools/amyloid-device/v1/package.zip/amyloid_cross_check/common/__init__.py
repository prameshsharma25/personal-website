"""Shared structure representation and quality-control API."""

from .alignment import fit_pair_transform, group_equivalent_chains, map_equivalent_residues
from .contacts import build_chain_contact_graph
from .io import StructureError, load_assembly, normalize_assembly
from .layers import assign_candidate_layers, read_explicit_layer_assignments
from .model import (
    AnalysisConfig, Assembly, AtomKey, AtomRecord, ChainGraph, ChainGroup, ChainRecord,
    CommonResult, InterfaceRecord, LayerAssignment, NormalizationPolicy, PairwiseTransform,
    QualityControlReport, ResidueID, ResidueMapping, ResidueRecord, SCHEMA_VERSION,
)
from .output import write_outputs
from .pdb import pdb_atom_name
from .orchestrator import inspect_pipeline_state, run_structural_pipeline
from .pipeline import (
    analyze_assembly, atom_identity_sha256, layer_assignment_sha256,
    normalized_assembly_sha256, sha256_file,
)
from .qc import run_quality_control

__all__ = [
    "AnalysisConfig", "Assembly", "AtomKey", "AtomRecord", "ChainGraph", "ChainGroup",
    "ChainRecord", "CommonResult", "InterfaceRecord", "LayerAssignment",
    "NormalizationPolicy", "PairwiseTransform", "QualityControlReport", "ResidueID",
    "ResidueMapping", "ResidueRecord", "SCHEMA_VERSION", "StructureError",
    "analyze_assembly", "assign_candidate_layers", "build_chain_contact_graph",
    "fit_pair_transform", "group_equivalent_chains", "load_assembly",
    "map_equivalent_residues", "normalize_assembly", "run_quality_control", "write_outputs",
    "read_explicit_layer_assignments",
    "run_structural_pipeline",
    "inspect_pipeline_state",
    "atom_identity_sha256", "normalized_assembly_sha256", "sha256_file",
    "layer_assignment_sha256", "pdb_atom_name",
]
