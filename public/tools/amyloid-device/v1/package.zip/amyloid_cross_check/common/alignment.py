"""Sequence equivalence, residue mapping, and sequence-aware rigid transforms."""

from __future__ import annotations

from collections import defaultdict
from typing import Sequence

import numpy as np

from .model import (
    AnalysisConfig, Assembly, BACKBONE_ATOMS, ChainGroup, ChainRecord,
    PairwiseTransform, ResidueMapping,
)


def nw_pairs(sequence_a: str, sequence_b: str) -> list[tuple[int | None, int | None]]:
    """Needleman-Wunsch alignment with deterministic diagonal/up/left ties."""
    n, m, gap = len(sequence_a), len(sequence_b), -2
    score = np.zeros((n + 1, m + 1), dtype=int)
    trace = np.zeros((n + 1, m + 1), dtype=np.int8)
    score[:, 0] = np.arange(n + 1) * gap
    score[0, :] = np.arange(m + 1) * gap
    trace[1:, 0], trace[0, 1:] = 1, 2
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            choices = (
                score[i - 1, j - 1] + (2 if sequence_a[i - 1] == sequence_b[j - 1] else -1),
                score[i - 1, j] + gap,
                score[i, j - 1] + gap,
            )
            trace[i, j] = int(np.argmax(choices))
            score[i, j] = choices[int(trace[i, j])]
    result: list[tuple[int | None, int | None]] = []
    i, j = n, m
    while i or j:
        direction = int(trace[i, j])
        if direction == 0:
            i -= 1
            j -= 1
            result.append((i, j))
        elif direction == 1:
            i -= 1
            result.append((i, None))
        else:
            j -= 1
            result.append((None, j))
    return list(reversed(result))


def _chain_direction(chain: ChainRecord, indexes: Sequence[int]) -> np.ndarray:
    coordinates = [chain.residues[index].atom("CA") for index in indexes]
    arrays = [atom.array for atom in coordinates if atom is not None]
    if len(arrays) < 2:
        return np.zeros(3)
    width = max(1, min(3, len(arrays) // 3))
    vector = np.mean(arrays[-width:], axis=0) - np.mean(arrays[:width], axis=0)
    norm = float(np.linalg.norm(vector))
    return vector / norm if norm else np.zeros(3)


def map_equivalent_residues(chain_a: ChainRecord, chain_b: ChainRecord) -> ResidueMapping:
    aligned = [(a, b) for a, b in nw_pairs(chain_a.sequence, chain_b.sequence) if a is not None and b is not None]
    matches = sum(chain_a.sequence[a] == chain_b.sequence[b] for a, b in aligned)
    count = len(aligned)
    direction_a = _chain_direction(chain_a, [a for a, _ in aligned])
    direction_b = _chain_direction(chain_b, [b for _, b in aligned])
    orientation = "undetermined"
    if np.any(direction_a) and np.any(direction_b):
        orientation = "parallel" if float(np.dot(direction_a, direction_b)) >= 0 else "antiparallel"
    offsets = [b - a for a, b in aligned]
    register = int(round(float(np.median(offsets)))) if offsets else None
    return ResidueMapping(
        chain_a.id, chain_b.id, tuple(aligned),
        tuple((chain_a.residues[a].id, chain_b.residues[b].id) for a, b in aligned),
        matches / count if count else 0.0,
        count / len(chain_a.residues) if chain_a.residues else 0.0,
        count / len(chain_b.residues) if chain_b.residues else 0.0,
        orientation, register,
    )


def _equivalent(mapping: ResidueMapping, config: AnalysisConfig) -> bool:
    return (
        mapping.identity >= config.minimum_sequence_identity
        and min(mapping.coverage_a, mapping.coverage_b) >= config.minimum_sequence_coverage
        and len(mapping.pairs) >= config.minimum_mapped_residues
    )


def group_equivalent_chains(
    assembly: Assembly,
    config: AnalysisConfig | None = None,
) -> list[ChainGroup]:
    config = config or AnalysisConfig()
    ids = sorted(assembly.chains)
    adjacency: dict[str, set[str]] = {chain_id: set() for chain_id in ids}
    for position, chain_a in enumerate(ids):
        for chain_b in ids[position + 1:]:
            mapping = map_equivalent_residues(assembly.chains[chain_a], assembly.chains[chain_b])
            if _equivalent(mapping, config):
                adjacency[chain_a].add(chain_b)
                adjacency[chain_b].add(chain_a)
    groups: list[ChainGroup] = []
    unseen = set(ids)
    while unseen:
        start = min(unseen)
        unseen.remove(start)
        component, queue = {start}, [start]
        while queue:
            node = queue.pop()
            for neighbor in sorted(adjacency[node] & unseen):
                unseen.remove(neighbor)
                component.add(neighbor)
                queue.append(neighbor)
        groups.append(ChainGroup(f"CG{len(groups) + 1}", tuple(sorted(component))))
    return groups


def all_pair_mappings(assembly: Assembly) -> list[ResidueMapping]:
    ids = sorted(assembly.chains)
    return [
        map_equivalent_residues(assembly.chains[a], assembly.chains[b])
        for position, a in enumerate(ids) for b in ids[position + 1:]
    ]


def _kabsch(mobile: np.ndarray, target: np.ndarray) -> tuple[np.ndarray, np.ndarray, float]:
    if mobile.shape != target.shape or mobile.ndim != 2 or mobile.shape[1] != 3 or len(mobile) < 3:
        raise ValueError("Kabsch inputs must be matching N x 3 arrays with at least three points")
    mobile_center, target_center = mobile.mean(axis=0), target.mean(axis=0)
    covariance = (mobile - mobile_center).T @ (target - target_center)
    left, _singular, right = np.linalg.svd(covariance)
    correction = np.eye(3)
    correction[-1, -1] = np.sign(np.linalg.det(left @ right))
    rotation = left @ correction @ right
    translation = target_center - mobile_center @ rotation
    fitted = mobile @ rotation + translation
    rmsd = float(np.sqrt(np.mean(np.sum((fitted - target) ** 2, axis=1))))
    return rotation, translation, rmsd


def fit_pair_transform(
    chain_a: ChainRecord,
    chain_b: ChainRecord,
    residue_map: ResidueMapping,
) -> PairwiseTransform:
    coordinates_a: list[np.ndarray] = []
    coordinates_b: list[np.ndarray] = []
    fitted_residues = 0
    for index_a, index_b in residue_map.pairs:
        used = False
        for atom_name in sorted(BACKBONE_ATOMS):
            atom_a = chain_a.residues[index_a].atom(atom_name)
            atom_b = chain_b.residues[index_b].atom(atom_name)
            if atom_a is not None and atom_b is not None:
                coordinates_a.append(atom_a.array)
                coordinates_b.append(atom_b.array)
                used = True
        fitted_residues += int(used)
    rotation, translation, rmsd = _kabsch(np.asarray(coordinates_a), np.asarray(coordinates_b))
    centroid_displacement = chain_b.centroid - chain_a.centroid
    return PairwiseTransform(
        chain_a.id, chain_b.id,
        tuple(tuple(float(value) for value in row) for row in rotation),
        tuple(float(value) for value in translation),
        tuple(float(value) for value in centroid_displacement),
        len(coordinates_a), fitted_residues, rmsd,
        min(residue_map.coverage_a, residue_map.coverage_b),
    )


def mappings_by_pair(mappings: Sequence[ResidueMapping]) -> dict[frozenset[str], ResidueMapping]:
    return {frozenset((mapping.chain_a, mapping.chain_b)): mapping for mapping in mappings}

