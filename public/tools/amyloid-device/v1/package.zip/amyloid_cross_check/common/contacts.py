"""Chain contact graph and preliminary interface records."""

from __future__ import annotations

import math
from typing import Sequence

import numpy as np

from .alignment import fit_pair_transform, mappings_by_pair
from .model import (
    AnalysisConfig, Assembly, BACKBONE_ATOMS, ChainGraph, InterfaceRecord,
    ResidueMapping,
)


def _pair_contacts(chain_a, chain_b, config: AnalysisConfig):
    atoms_a = [(residue, atom) for residue in chain_a.residues for atom in residue.atoms.values()]
    atoms_b = [(residue, atom) for residue in chain_b.residues for atom in residue.atoms.values()]
    if not atoms_a or not atoms_b:
        return None, 0, 0, ()
    coordinates_b = np.asarray([atom.coord for _, atom in atoms_b])
    minimum = float("inf")
    heavy_count = 0
    backbone_count = 0
    contacts = set()
    for residue_a, atom_a in atoms_a:
        distances = np.linalg.norm(coordinates_b - atom_a.array, axis=1)
        minimum = min(minimum, float(np.min(distances)))
        heavy_count += int(np.count_nonzero(distances <= config.heavy_atom_contact_distance))
        if atom_a.name in BACKBONE_ATOMS:
            for index in np.flatnonzero(distances <= config.backbone_contact_distance):
                if atoms_b[int(index)][1].name in BACKBONE_ATOMS:
                    backbone_count += 1
    contact_b = []
    for residue_b in chain_b.residues:
        atom_b = residue_b.atom("CB") or residue_b.atom("CA")
        if atom_b is not None:
            contact_b.append((residue_b, atom_b.array))
    if contact_b:
        contact_coordinates_b = np.asarray([coord for _, coord in contact_b])
        for residue_a in chain_a.residues:
            atom_a = residue_a.atom("CB") or residue_a.atom("CA")
            if atom_a is None:
                continue
            for index in np.flatnonzero(
                np.linalg.norm(contact_coordinates_b - atom_a.array, axis=1)
                <= config.residue_contact_distance
            ):
                contacts.add((residue_a.id, contact_b[int(index)][0].id))
    return minimum, heavy_count, backbone_count, tuple(sorted(contacts))


def _equivalent(mapping: ResidueMapping | None, config: AnalysisConfig) -> bool:
    return bool(
        mapping is not None
        and mapping.identity >= config.minimum_sequence_identity
        and min(mapping.coverage_a, mapping.coverage_b) >= config.minimum_sequence_coverage
        and len(mapping.pairs) >= config.minimum_mapped_residues
    )


def build_chain_contact_graph(
    assembly: Assembly,
    config: AnalysisConfig | None = None,
    mappings: Sequence[ResidueMapping] | None = None,
) -> ChainGraph:
    config = config or AnalysisConfig()
    mapping_lookup = mappings_by_pair(mappings or ())
    edges: list[InterfaceRecord] = []
    ids = sorted(assembly.chains)
    for position, chain_a_id in enumerate(ids):
        for chain_b_id in ids[position + 1:]:
            chain_a, chain_b = assembly.chains[chain_a_id], assembly.chains[chain_b_id]
            minimum, heavy, backbone, contacts = _pair_contacts(chain_a, chain_b, config)
            mapping = mapping_lookup.get(frozenset((chain_a_id, chain_b_id)))
            equivalent = _equivalent(mapping, config)
            transform = None
            if equivalent and mapping is not None:
                directed_mapping = mapping
                if mapping.chain_a != chain_a_id:
                    directed_mapping = ResidueMapping(
                        chain_a_id, chain_b_id,
                        tuple((b, a) for a, b in mapping.pairs),
                        tuple((b, a) for a, b in mapping.residue_pairs),
                        mapping.identity, mapping.coverage_b, mapping.coverage_a,
                        mapping.orientation,
                        -mapping.register_offset if mapping.register_offset is not None else None,
                    )
                try:
                    transform = fit_pair_transform(chain_a, chain_b, directed_mapping)
                except ValueError:
                    transform = None
            # Same documented preliminary proxy as the geometry implementation.
            preliminary_bsa = float(12.0 * len(contacts) + 0.35 * min(heavy, 4000))
            edges.append(InterfaceRecord(
                chain_a_id, chain_b_id,
                minimum if minimum is not None and math.isfinite(minimum) else None,
                len(contacts), heavy, backbone, preliminary_bsa, equivalent,
                contacts, transform,
            ))
    return ChainGraph(tuple(ids), edges)
