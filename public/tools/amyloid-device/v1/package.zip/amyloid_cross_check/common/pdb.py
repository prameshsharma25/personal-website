"""PDB field-formatting helpers shared by structure backends."""

from __future__ import annotations


def pdb_atom_name(name: str, element: str) -> str:
    """Return the four-column PDB atom-name field.

    For one-character elements, the PDB convention places the element in the
    second atom-name column. Native libraries such as FreeSASA use these
    columns when applying residue/atom classifiers, so passing stripped names
    such as ``CD1`` can incorrectly trigger element-only radius guessing.
    """
    stripped_name = name.strip()
    stripped_element = element.strip()
    if not stripped_name:
        raise ValueError("PDB atom name must not be empty")
    if len(stripped_name) >= 4:
        return stripped_name[:4]
    if len(stripped_element) == 1:
        return f" {stripped_name:<3s}"
    return f"{stripped_name:<4s}"
