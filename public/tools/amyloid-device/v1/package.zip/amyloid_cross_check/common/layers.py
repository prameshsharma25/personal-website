"""Transform-family inference of candidate protofilaments and layer order."""

from __future__ import annotations

import math
import json
from collections import Counter, defaultdict
from typing import Sequence
from pathlib import Path

import numpy as np

from .model import AnalysisConfig, ChainGraph, InterfaceRecord, LayerAssignment


def _rotation_difference(a, b) -> float:
    relative = np.asarray(a).T @ np.asarray(b)
    return math.degrees(math.acos(float(np.clip((np.trace(relative) - 1.0) / 2.0, -1.0, 1.0))))


def _directed_transform(edge: InterfaceRecord, source: str):
    if edge.transform is None:
        return None
    return edge.transform if edge.chain_a == source else edge.transform.inverse()


def _similar(seed: InterfaceRecord, edge: InterfaceRecord, config: AnalysisConfig) -> bool:
    if seed.transform is None or edge.transform is None:
        return False
    variants = (edge.transform, edge.transform.inverse())
    seed_translation = np.asarray(seed.transform.translation)
    denominator = max(float(np.linalg.norm(seed_translation)), 1.0)
    return any(
        _rotation_difference(seed.transform.rotation, variant.rotation) <= config.transform_rotation_tolerance_degrees
        and float(np.linalg.norm(seed_translation - np.asarray(variant.translation))) / denominator
        <= config.transform_length_relative_tolerance
        for variant in variants
    )


def _families(edges: Sequence[InterfaceRecord], config: AnalysisConfig) -> list[list[InterfaceRecord]]:
    unique: dict[frozenset[tuple[str, str]], list[InterfaceRecord]] = {}
    for seed in edges:
        family = [edge for edge in edges if _similar(seed, edge, config)]
        key = frozenset(tuple(sorted((edge.chain_a, edge.chain_b))) for edge in family)
        unique[key] = family
    return sorted(
        unique.values(),
        key=lambda family: (
            len({chain for edge in family for chain in (edge.chain_a, edge.chain_b)}),
            sum(edge.residue_contact_count for edge in family),
            len(family),
        ),
        reverse=True,
    )


def _components(edges: Sequence[InterfaceRecord]) -> list[list[InterfaceRecord]]:
    adjacency: dict[str, set[str]] = defaultdict(set)
    for edge in edges:
        adjacency[edge.chain_a].add(edge.chain_b)
        adjacency[edge.chain_b].add(edge.chain_a)
    unseen = set(adjacency)
    result = []
    while unseen:
        start = min(unseen)
        unseen.remove(start)
        nodes, queue = {start}, [start]
        while queue:
            node = queue.pop()
            for neighbor in sorted(adjacency[node] & unseen):
                unseen.remove(neighbor)
                nodes.add(neighbor)
                queue.append(neighbor)
        result.append([edge for edge in edges if edge.chain_a in nodes and edge.chain_b in nodes])
    return result


def _maximum_support_path(edges: Sequence[InterfaceRecord]) -> tuple[list[str], bool]:
    degrees_all = Counter(chain for edge in edges for chain in (edge.chain_a, edge.chain_b))
    closed = len(degrees_all) >= 3 and all(degree == 2 for degree in degrees_all.values())
    parent: dict[str, str] = {}
    degree: Counter[str] = Counter()

    def root(node: str) -> str:
        parent.setdefault(node, node)
        while parent[node] != node:
            parent[node] = parent[parent[node]]
            node = parent[node]
        return node

    selected = []
    for edge in sorted(
        edges,
        key=lambda item: (-item.residue_contact_count, item.minimum_heavy_atom_distance or float("inf"), item.chain_a, item.chain_b),
    ):
        root_a, root_b = root(edge.chain_a), root(edge.chain_b)
        if root_a != root_b and degree[edge.chain_a] < 2 and degree[edge.chain_b] < 2:
            parent[root_a] = root_b
            degree[edge.chain_a] += 1
            degree[edge.chain_b] += 1
            selected.append(edge)
    if not selected:
        return [], closed
    adjacency: dict[str, list[str]] = defaultdict(list)
    for edge in selected:
        adjacency[edge.chain_a].append(edge.chain_b)
        adjacency[edge.chain_b].append(edge.chain_a)
    endpoints = sorted(node for node, neighbors in adjacency.items() if len(neighbors) == 1)
    current = endpoints[0] if endpoints else min(adjacency)
    path, previous = [], None
    while current is not None:
        path.append(current)
        following = [neighbor for neighbor in sorted(adjacency[current]) if neighbor != previous]
        previous, current = current, following[0] if following else None
    return path, closed


def infer_layer_assignments(
    chain_graph: ChainGraph,
    config: AnalysisConfig | None = None,
) -> tuple[list[LayerAssignment], list[dict]]:
    config = config or AnalysisConfig()
    candidates = [
        edge for edge in chain_graph.edges
        if edge.sequence_equivalent and edge.transform is not None
        and edge.residue_contact_count > 0
        and edge.transform.rmsd <= config.maximum_pair_rmsd
    ]
    families = _families(candidates, config)
    if not families:
        return [], []
    support = lambda family: sum(edge.residue_contact_count for edge in family)
    best_support = max(support(families[0]), 1)
    plausible = [family for family in families if support(family) / best_support >= 0.80]
    alternatives = []
    family_paths: list[list[tuple[list[str], bool]]] = []
    for family_index, family in enumerate(plausible):
        paths = [_maximum_support_path(component) for component in _components(family)]
        paths = [(path, closed) for path, closed in paths if len(path) >= 2]
        family_paths.append(paths)
        alternatives.append({
            "family_index": family_index,
            "support": support(family),
            "relative_support": support(family) / best_support,
            "paths": [path for path, _closed in paths],
            "closed_components": [path for path, closed in paths if closed],
        })
    assignments: list[LayerAssignment] = []
    for protofilament_index, (path, _closed) in enumerate(family_paths[0], 1):
        for layer, chain_id in enumerate(path):
            chain_alternatives = tuple(
                {"family_index": alternative["family_index"], "path": alt_path, "layer_index": alt_path.index(chain_id)}
                for alternative in alternatives[1:] for alt_path in alternative["paths"] if chain_id in alt_path
            )
            assignments.append(LayerAssignment(
                chain_id, f"PF{protofilament_index}", layer, "observed", chain_alternatives,
            ))
    return assignments, alternatives


def assign_candidate_layers(
    assembly, chain_graph: ChainGraph, mappings=None, config: AnalysisConfig | None = None,
) -> list[LayerAssignment]:
    """README-compatible public API; assembly/mappings are retained for call symmetry."""
    del assembly, mappings
    return infer_layer_assignments(chain_graph, config)[0]


def read_explicit_layer_assignments(path, known_chains: set[str]) -> list[LayerAssignment]:
    """Read and validate list- or mapping-shaped layer JSON."""
    with Path(path).open(encoding="utf-8") as handle:
        document = json.load(handle)
    raw = document.get("chains", document)
    items = []
    if isinstance(raw, dict):
        for chain_id, value in raw.items():
            item = dict(value) if isinstance(value, dict) else {"layer": value}
            item.setdefault("chain_id", chain_id)
            items.append(item)
    elif isinstance(raw, list):
        items = raw
    else:
        raise ValueError("Explicit layer map must contain a 'chains' list or mapping")
    result = []
    occupied = set()
    for item in items:
        chain_id = str(item.get("chain_id", item.get("chain", "")))
        if chain_id not in known_chains:
            raise ValueError(f"Explicit layer map contains unknown chain {chain_id!r}")
        protofilament = str(item.get("protofilament_id", item.get("protofilament", "PF1")))
        raw_layer = item.get("layer_index", item.get("layer", item.get("layer_id")))
        if raw_layer is None:
            raise ValueError(f"Explicit layer map lacks a layer index for chain {chain_id!r}")
        layer = int(raw_layer)
        key = (protofilament, layer)
        if key in occupied:
            raise ValueError(f"Duplicate explicit layer {protofilament}:{layer}")
        occupied.add(key)
        result.append(LayerAssignment(
            chain_id, protofilament, layer,
            str(item.get("observed_or_virtual", "observed")), (),
        ))
    if len({item.chain_id for item in result}) != len(result):
        raise ValueError("A chain occurs more than once in the explicit layer map")
    return sorted(result, key=lambda item: (item.protofilament_id, item.layer_index, item.chain_id))
