"""Versioned JSON and tidy CSV serialization."""

from __future__ import annotations

import csv
import json
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np

from .model import CommonResult


def _jsonable(value: Any) -> Any:
    if is_dataclass(value):
        return _jsonable(asdict(value))
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, tuple):
        # Tuples encode an intentional scientific order (for example the
        # alternative layer assignments attached to a chain).  asdict()
        # preserves a tuple while converting nested dataclasses to dicts, and
        # dicts are not orderable in Python 3.  Preserve the tuple order rather
        # than treating it like an unordered set.
        return [_jsonable(item) for item in value]
    if isinstance(value, (set, frozenset)):
        converted = [_jsonable(item) for item in value]
        return sorted(
            converted,
            key=lambda item: json.dumps(item, sort_keys=True, separators=(",", ":")),
        )
    if isinstance(value, list):
        return [_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, Path):
        return str(value)
    return value


def _write_csv(path: Path, rows: Iterable[dict[str, Any]], empty_fields: list[str]) -> None:
    materialized = list(rows)
    fields = list(materialized[0]) if materialized else empty_fields
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(materialized)


def write_outputs(result: CommonResult, output: str | Path) -> list[Path]:
    target = Path(output)
    if target.suffix.lower() == ".json":
        prefix = target.with_suffix("")
        if prefix.name.endswith(".qc"):
            prefix = prefix.with_name(prefix.name[:-3])
        qc_path = target
    else:
        prefix = target
        qc_path = Path(str(prefix) + ".qc.json")
    qc_path.parent.mkdir(parents=True, exist_ok=True)
    qc_document = {
        **result.metadata,
        "assessability": result.assessability,
        "quality_control": _jsonable(result.quality_control),
        "parse_report": _jsonable(result.assembly.parse_report),
    }
    qc_path.write_text(json.dumps(_jsonable(qc_document), indent=2, sort_keys=True) + "\n")

    group_by_chain = {
        chain: group.id for group in result.chain_groups for chain in group.chain_ids
    }
    chain_rows = [{
        "chain_id": chain.id,
        "chain_group": group_by_chain.get(chain.id, ""),
        "sequence": chain.sequence,
        "residue_count": len(chain.residues),
        "atom_count": len(chain.atoms),
    } for chain in sorted(result.assembly.chains.values(), key=lambda item: item.id)]
    chain_path = Path(str(prefix) + ".chains.csv")
    _write_csv(chain_path, chain_rows, ["chain_id", "chain_group", "sequence"])

    mapping_rows = []
    for mapping in result.mappings:
        for (index_a, index_b), (residue_a, residue_b) in zip(mapping.pairs, mapping.residue_pairs):
            mapping_rows.append({
                "chain_a": mapping.chain_a, "chain_b": mapping.chain_b,
                "index_a": index_a, "index_b": index_b,
                "residue_a": residue_a.text(), "residue_b": residue_b.text(),
                "sequence_identity": mapping.identity,
                "coverage_a": mapping.coverage_a, "coverage_b": mapping.coverage_b,
                "orientation": mapping.orientation, "register_offset": mapping.register_offset,
            })
    mapping_path = Path(str(prefix) + ".residue_map.csv")
    _write_csv(mapping_path, mapping_rows, ["chain_a", "chain_b", "residue_a", "residue_b"])

    edge_rows = []
    for edge in result.chain_graph.edges:
        transform = edge.transform
        edge_rows.append({
            "chain_a": edge.chain_a, "chain_b": edge.chain_b,
            "minimum_heavy_atom_distance_A": edge.minimum_heavy_atom_distance,
            "residue_contact_count": edge.residue_contact_count,
            "heavy_atom_contact_count": edge.heavy_atom_contact_count,
            "backbone_contact_count": edge.backbone_contact_count,
            "preliminary_bsa_A2": edge.preliminary_bsa,
            "sequence_equivalent": edge.sequence_equivalent,
            "transform_rmsd_A": transform.rmsd if transform else None,
            "fitted_atom_count": transform.fitted_atom_count if transform else None,
            "rotation_matrix": json.dumps(transform.rotation) if transform else None,
            "translation_vector": json.dumps(transform.translation) if transform else None,
        })
    edge_path = Path(str(prefix) + ".chain_edges.csv")
    _write_csv(edge_path, edge_rows, ["chain_a", "chain_b"])

    layer_path = Path(str(prefix) + ".layers.json")
    layer_indices: dict[str, list[int]] = {}
    for layer in result.layers:
        layer_indices.setdefault(layer.protofilament_id, []).append(layer.layer_index)
    layer_rows = []
    for layer in result.layers:
        indices = layer_indices[layer.protofilament_id]
        layer_rows.append({
            **_jsonable(layer),
            "protofilament": layer.protofilament_id,
            "layer": layer.layer_index,
            "end_or_central": "end" if layer.layer_index in {min(indices), max(indices)} else "central",
        })
    layer_document = {
        **result.metadata,
        "assessability": result.assessability,
        "chains": layer_rows,
        "alternative_assignments": _jsonable(result.alternative_layer_assignments),
    }
    layer_path.write_text(json.dumps(_jsonable(layer_document), indent=2, sort_keys=True) + "\n")
    return [qc_path, chain_path, mapping_path, edge_path, layer_path]
