"""Command-line entry point for common assembly normalization and QC."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .io import StructureError
from .model import AnalysisConfig, NormalizationPolicy
from .output import write_outputs
from .pipeline import analyze_assembly


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--structure", type=Path, required=True, help="Input PDB, CIF, or mmCIF")
    parser.add_argument("--output", type=Path, required=True, help="Output prefix or <model>.qc.json")
    parser.add_argument("--model-index", type=int, default=0, help="Zero-based model index")
    parser.add_argument("--chain-id-source", choices=("auto", "author", "label"), default="auto")
    parser.add_argument("--retain", action="append", default=[], metavar="RESNAME", help="Retain named nonpolymer residue")
    parser.add_argument("--retain-metals", action="store_true")
    parser.add_argument("--layer-map", type=Path, help="Explicit chain-to-protofilament/layer JSON")
    parser.add_argument("--prediction-metadata", type=Path, help="Optional prediction metadata JSON")
    parser.add_argument("--expected-chains", type=int)
    parser.add_argument("--expected-protofilaments", type=int)
    parser.add_argument("--ph", type=float, help="Record pH for downstream energetics")
    parser.add_argument("--minimum-sequence-identity", type=float, default=0.85)
    parser.add_argument("--minimum-sequence-coverage", type=float, default=0.70)
    parser.add_argument("--severe-clash-distance", type=float, default=2.0)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    normalization = NormalizationPolicy(
        retain_nonpolymer_names=frozenset(name.upper() for name in args.retain),
        retain_metals=args.retain_metals,
    )
    config = AnalysisConfig(
        minimum_sequence_identity=args.minimum_sequence_identity,
        minimum_sequence_coverage=args.minimum_sequence_coverage,
        severe_clash_distance=args.severe_clash_distance,
    )
    command = [sys.executable, "-m", "amyloid_cross_check.common", *(argv if argv is not None else sys.argv[1:])]
    try:
        prediction_metadata = None
        if args.prediction_metadata is not None:
            prediction_metadata = json.loads(args.prediction_metadata.read_text())
        result = analyze_assembly(
            args.structure, model_index=args.model_index,
            normalization_policy=normalization, config=config,
            chain_id_source=args.chain_id_source, command=command,
            explicit_layer_map=args.layer_map,
            prediction_metadata=prediction_metadata,
            expected_chain_count=args.expected_chains,
            expected_protofilament_count=args.expected_protofilaments,
            ph=args.ph,
        )
        paths = write_outputs(result, args.output)
    except (FileNotFoundError, StructureError, ValueError) as error:
        print(f"common: {error}", file=sys.stderr)
        return 2
    for path in paths:
        print(f"wrote {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
