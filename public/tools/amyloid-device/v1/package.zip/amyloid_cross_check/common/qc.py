"""Completeness and physical-plausibility audits."""

from __future__ import annotations

import math
from collections import defaultdict

import numpy as np

from .model import (
    AnalysisConfig, Assembly, BACKBONE_ATOMS, METAL_ELEMENTS, QualityControlReport,
    STANDARD_RESIDUES,
)


EXPECTED_SIDECHAIN = {
    "ALA": {"CB"}, "ARG": {"CB", "CG", "CD", "NE", "CZ", "NH1", "NH2"},
    "ASN": {"CB", "CG", "OD1", "ND2"}, "ASP": {"CB", "CG", "OD1", "OD2"},
    "CYS": {"CB", "SG"}, "GLN": {"CB", "CG", "CD", "OE1", "NE2"},
    "GLU": {"CB", "CG", "CD", "OE1", "OE2"}, "GLY": set(),
    "HIS": {"CB", "CG", "ND1", "CD2", "CE1", "NE2"},
    "ILE": {"CB", "CG1", "CG2", "CD1"}, "LEU": {"CB", "CG", "CD1", "CD2"},
    "LYS": {"CB", "CG", "CD", "CE", "NZ"}, "MET": {"CB", "CG", "SD", "CE"},
    "PHE": {"CB", "CG", "CD1", "CD2", "CE1", "CE2", "CZ"},
    "PRO": {"CB", "CG", "CD"}, "SER": {"CB", "OG"},
    "THR": {"CB", "OG1", "CG2"},
    "TRP": {"CB", "CG", "CD1", "CD2", "NE1", "CE2", "CE3", "CZ2", "CZ3", "CH2"},
    "TYR": {"CB", "CG", "CD1", "CD2", "CE1", "CE2", "CZ", "OH"},
    "VAL": {"CB", "CG1", "CG2"},
}


def _local_pair(atom_a, atom_b, positions: dict[tuple[str, int, str], int]) -> bool:
    """Return true only for local pairs that are certainly bonded or 1--3.

    Intrarestraint topology is not yet represented explicitly, so pairs within
    one residue remain excluded.  Across a peptide bond, however, excluding all
    atoms from adjacent residues hides real side-chain clashes.  The small set
    below is the peptide bond and its heavy-atom 1--3 neighbours.
    """
    key_a = atom_a.key
    key_b = atom_b.key
    residue_a = (key_a.chain_id, key_a.residue_number, key_a.insertion_code)
    residue_b = (key_b.chain_id, key_b.residue_number, key_b.insertion_code)
    if residue_a == residue_b:
        return True
    if key_a.chain_id != key_b.chain_id:
        return False
    position_a = positions.get(residue_a, -1000)
    position_b = positions.get(residue_b, 1000)
    if abs(position_a - position_b) != 1:
        return False
    if position_a < position_b:
        previous_name, next_name = key_a.atom_name, key_b.atom_name
    else:
        previous_name, next_name = key_b.atom_name, key_a.atom_name
    return (previous_name, next_name) in {
        ("C", "N"),       # peptide bond
        ("CA", "N"),      # CA(i)-C(i)-N(i+1)
        ("O", "N"),       # O(i)-C(i)-N(i+1)
        ("C", "CA"),      # C(i)-N(i+1)-CA(i+1)
    }


def _nonbonded_distances(assembly: Assembly, cutoff: float) -> tuple[float | None, list[dict]]:
    atoms = assembly.atoms
    if len(atoms) < 2:
        return None, []
    positions = {
        (chain.id, residue.id.residue_number, residue.id.insertion_code): residue.sequence_index
        for chain in assembly.chains.values() for residue in chain.residues
    }
    cell_size = max(cutoff, 2.5)
    cells: dict[tuple[int, int, int], list[int]] = defaultdict(list)
    for index, atom in enumerate(atoms):
        cell = tuple(int(math.floor(value / cell_size)) for value in atom.coord)
        cells[cell].append(index)
    minimum = float("inf")
    clashes: list[dict] = []
    offsets = [(x, y, z) for x in (-1, 0, 1) for y in (-1, 0, 1) for z in (-1, 0, 1)]
    for index_a, atom_a in enumerate(atoms):
        cell = tuple(int(math.floor(value / cell_size)) for value in atom_a.coord)
        candidates = set()
        for offset in offsets:
            candidates.update(cells.get(tuple(cell[i] + offset[i] for i in range(3)), []))
        for index_b in sorted(candidate for candidate in candidates if candidate > index_a):
            atom_b = atoms[index_b]
            if _local_pair(atom_a, atom_b, positions):
                continue
            distance = float(np.linalg.norm(atom_a.array - atom_b.array))
            minimum = min(minimum, distance)
            if distance < cutoff:
                clashes.append({
                    "atom_a": atom_a.key.text(), "atom_b": atom_b.key.text(),
                    "distance_A": distance,
                    "scope": (
                        "intrachain"
                        if atom_a.key.chain_id == atom_b.key.chain_id
                        else "interchain"
                    ),
                })
    # The first pass is enough for clashes. Expand the cell neighborhood far
    # enough to prove the exact minimum; fall back to all pairs when no nearby
    # nonlocal pair supplied an initial upper bound.
    if math.isfinite(minimum):
        radius = max(1, int(math.ceil(minimum / cell_size)))
        wider_offsets = [
            (x, y, z) for x in range(-radius, radius + 1)
            for y in range(-radius, radius + 1) for z in range(-radius, radius + 1)
        ]
        for index_a, atom_a in enumerate(atoms):
            cell = tuple(int(math.floor(value / cell_size)) for value in atom_a.coord)
            candidates = set()
            for offset in wider_offsets:
                candidates.update(cells.get(tuple(cell[i] + offset[i] for i in range(3)), []))
            for index_b in (candidate for candidate in candidates if candidate > index_a):
                atom_b = atoms[index_b]
                if not _local_pair(atom_a, atom_b, positions):
                    minimum = min(minimum, float(np.linalg.norm(atom_a.array - atom_b.array)))
    else:
        for index_a, atom_a in enumerate(atoms):
            for atom_b in atoms[index_a + 1:]:
                if not _local_pair(atom_a, atom_b, positions):
                    minimum = min(minimum, float(np.linalg.norm(atom_a.array - atom_b.array)))
    return (minimum if math.isfinite(minimum) else None), clashes


def run_quality_control(
    assembly: Assembly,
    policy: AnalysisConfig | None = None,
) -> QualityControlReport:
    config = policy or AnalysisConfig()
    missing_backbone: list[dict] = []
    incomplete_sidechains: list[dict] = []
    nonstandard: list[str] = []
    zero_occupancy: list[str] = []
    chain_breaks: list[dict] = []
    discontinuities: list[dict] = []
    residue_count = 0
    complete_count = 0
    backbone_complete_count = 0
    parameterized_count = 0
    for chain in assembly.chains.values():
        for index, residue in enumerate(chain.residues):
            residue_count += 1
            missing = sorted(BACKBONE_ATOMS - residue.atoms.keys())
            if missing:
                missing_backbone.append({"residue": residue.id.text(), "missing_atoms": missing})
            expected = EXPECTED_SIDECHAIN.get(residue.normalized_name)
            missing_sidechain = sorted(expected - residue.atoms.keys()) if expected is not None else []
            if missing_sidechain:
                incomplete_sidechains.append({"residue": residue.id.text(), "missing_atoms": missing_sidechain})
            if residue.normalized_name not in STANDARD_RESIDUES:
                nonstandard.append(residue.id.text())
            if not missing:
                backbone_complete_count += 1
            if expected is not None:
                parameterized_count += 1
            if not missing and not missing_sidechain and expected is not None:
                complete_count += 1
            zero_occupancy.extend(atom.key.text() for atom in residue.atoms.values() if atom.occupancy <= 0.0)
            if index:
                previous = chain.residues[index - 1]
                delta = residue.id.residue_number - previous.id.residue_number
                if delta != 1 and not (delta == 0 and residue.id.insertion_code != previous.id.insertion_code):
                    discontinuities.append({
                        "chain_id": chain.id, "previous": previous.id.text(),
                        "next": residue.id.text(), "number_delta": delta,
                    })
                carbon, nitrogen = previous.atom("C"), residue.atom("N")
                if carbon is not None and nitrogen is not None:
                    distance = float(np.linalg.norm(carbon.array - nitrogen.array))
                    if distance > config.chain_break_cn_distance:
                        chain_breaks.append({
                            "chain_id": chain.id, "previous": previous.id.text(),
                            "next": residue.id.text(), "C_N_distance_A": distance,
                        })
    minimum, clashes = _nonbonded_distances(assembly, config.severe_clash_distance)
    ligands = sorted(
        {residue.original_name for residue in assembly.nonpolymer_residues}
        | set(assembly.parse_report.removed_ligand_names)
    )
    metals = sorted({
        atom.element for residue in assembly.nonpolymer_residues
        for atom in residue.atoms.values() if atom.element in METAL_ELEMENTS
    } | set(assembly.parse_report.removed_metal_elements))
    geometry_coverage = backbone_complete_count / residue_count if residue_count else 0.0
    packing_coverage = complete_count / residue_count if residue_count else 0.0
    parameterized_fraction = parameterized_count / residue_count if residue_count else 0.0
    parameterized_completeness = complete_count / parameterized_count if parameterized_count else 0.0
    energy_coverage = complete_count / residue_count if residue_count else 0.0
    return QualityControlReport(
        counts={
            "models": assembly.parse_report.total_models,
            "chains": len(assembly.chains),
            "residues": residue_count,
            "atoms": len(assembly.atoms),
            "retained_nonpolymer_residues": len(assembly.nonpolymer_residues),
        },
        missing_backbone=missing_backbone,
        incomplete_sidechains=incomplete_sidechains,
        duplicate_atom_identifiers=list(assembly.parse_report.duplicate_raw_atom_keys),
        alternate_conformations={
            "atom_sites": assembly.parse_report.alternate_atom_site_count,
            "discarded": assembly.parse_report.discarded_alternate_count,
        },
        nonstandard_residues=sorted(set(nonstandard)), ligands=ligands, metals=metals,
        waters_removed=assembly.parse_report.water_count_removed,
        minimum_nonbonded_heavy_atom_distance=minimum,
        severe_clashes=clashes,
        intrachain_severe_clashes=[item for item in clashes if item["scope"] == "intrachain"],
        interchain_severe_clashes=[item for item in clashes if item["scope"] == "interchain"],
        chain_breaks=chain_breaks, residue_number_discontinuities=discontinuities,
        zero_occupancy_atoms=zero_occupancy,
        invalid_coordinate_count=assembly.parse_report.invalid_coordinate_count,
        completeness_fraction=complete_count / residue_count if residue_count else 0.0,
        energy_coverage_complete=not missing_backbone and not incomplete_sidechains and not nonstandard,
        geometry_coverage_fraction=geometry_coverage,
        packing_coverage_fraction=packing_coverage,
        energy_coverage_fraction=energy_coverage,
        parameterized_fraction_of_all_polymer_residues=parameterized_fraction,
        completeness_within_parameterized_residues=parameterized_completeness,
        geometry_assessable=geometry_coverage > 0.0,
        physical_plausibility=not clashes,
    )
