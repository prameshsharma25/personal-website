"""PDB/mmCIF parsing and deterministic coordinate normalization."""

from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from Bio.PDB.MMCIF2Dict import MMCIF2Dict

from .model import (
    Assembly, AtomKey, AtomRecord, ChainRecord, METAL_ELEMENTS, NormalizationPolicy,
    ONE_LETTER, ParseReport, ResidueID, ResidueRecord, STANDARD_RESIDUES, WATER_NAMES,
)


class StructureError(ValueError):
    """Raised when a structure cannot be parsed without ambiguity."""


TYR_HEAVY_ATOMS = frozenset({
    "N", "CA", "C", "O", "OXT", "CB", "CG", "CD1", "CD2", "CE1",
    "CE2", "CZ", "OH",
})
UNMODIFIED_SUBSTITUTION_ATOMS = {
    "PTR": TYR_HEAVY_ATOMS,
    "TYC": TYR_HEAVY_ATOMS,
}


@dataclass(slots=True)
class _RawAtom:
    model: str
    record: str
    serial: str
    chain: str
    residue_number: int
    insertion: str
    residue_name: str
    atom_name: str
    altloc: str
    occupancy: float
    b_factor: float | None
    element: str
    coord: tuple[float, float, float] | None


def _clean(value: Any) -> str:
    text = str(value).strip()
    return "" if text in {".", "?", "None"} else text


def _float(value: Any, default: float | None = None) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return default
    return result if math.isfinite(result) else default


def _element(atom_name: str, explicit: str = "") -> str:
    explicit = _clean(explicit).upper()
    if explicit:
        return explicit
    letters = "".join(character for character in atom_name if character.isalpha()).upper()
    if not letters:
        return ""
    if letters.startswith(("BR", "CL")):
        return letters[:2]
    return letters[0]


def _pdb_rows(path: Path) -> tuple[list[_RawAtom], list[str]]:
    rows: list[_RawAtom] = []
    models: list[str] = []
    current = "1"
    saw_model = False
    for line_number, line in enumerate(path.read_text(errors="replace").splitlines(), 1):
        record = line[0:6].strip().upper()
        if record == "MODEL":
            saw_model = True
            current = line[10:14].strip() or str(len(models) + 1)
            if current not in models:
                models.append(current)
            continue
        if record not in {"ATOM", "HETATM"}:
            continue
        if not saw_model and "1" not in models:
            models.append("1")
        try:
            residue_number = int(line[22:26])
        except ValueError as error:
            raise StructureError(f"Invalid residue number at {path}:{line_number}") from error
        coordinates = tuple(_float(line[start:end]) for start, end in ((30, 38), (38, 46), (46, 54)))
        valid = all(value is not None for value in coordinates)
        rows.append(_RawAtom(
            current, record, line[6:11].strip() or str(line_number),
            line[21:22].strip() or "_", residue_number, line[26:27].strip(),
            line[17:20].strip().upper() or "UNK", line[12:16].strip().upper(),
            line[16:17].strip(), _float(line[54:60], 1.0) or 0.0,
            _float(line[60:66]), _element(line[12:16], line[76:78] if len(line) >= 78 else ""),
            tuple(float(value) for value in coordinates) if valid else None,
        ))
    return rows, models


def _column(data: dict[str, Any], name: str, count: int, default: str = "") -> list[str]:
    raw = data.get(name)
    if raw is None:
        return [default] * count
    values = raw if isinstance(raw, list) else [raw]
    if len(values) == 1 and count > 1:
        values = values * count
    if len(values) != count:
        raise StructureError(f"Inconsistent mmCIF column {name}: {len(values)} values for {count} rows")
    return [str(value) for value in values]


def _mmcif_rows(path: Path, chain_id_source: str) -> tuple[list[_RawAtom], list[str], str]:
    try:
        data = MMCIF2Dict(str(path))
    except Exception as error:
        raise StructureError(f"Unable to parse mmCIF {path}: {error}") from error
    group = data.get("_atom_site.group_PDB", [])
    groups = group if isinstance(group, list) else [group]
    count = len(groups)
    if not count:
        raise StructureError(f"No _atom_site rows found in {path}")
    label_chains = _column(data, "_atom_site.label_asym_id", count, "_")
    auth_chains = _column(data, "_atom_site.auth_asym_id", count, "_")
    if chain_id_source == "auto":
        # label_asym_id is unique for expanded assemblies; author IDs can be reused.
        chain_id_source = "label" if any(len(_clean(value)) > 1 for value in label_chains) or len(set(label_chains)) >= len(set(auth_chains)) else "author"
    chains = label_chains if chain_id_source == "label" else auth_chains
    models_column = _column(data, "_atom_site.pdbx_PDB_model_num", count, "1")
    models = list(dict.fromkeys(_clean(value) or "1" for value in models_column))
    rows: list[_RawAtom] = []
    columns = {
        "serial": _column(data, "_atom_site.id", count),
        "label_atom": _column(data, "_atom_site.label_atom_id", count),
        "auth_atom": _column(data, "_atom_site.auth_atom_id", count),
        "label_comp": _column(data, "_atom_site.label_comp_id", count, "UNK"),
        "auth_comp": _column(data, "_atom_site.auth_comp_id", count),
        "label_seq": _column(data, "_atom_site.label_seq_id", count),
        "auth_seq": _column(data, "_atom_site.auth_seq_id", count),
        "insertion": _column(data, "_atom_site.pdbx_PDB_ins_code", count),
        "alt_label": _column(data, "_atom_site.label_alt_id", count),
        "alt_auth": _column(data, "_atom_site.auth_alt_id", count),
        "occupancy": _column(data, "_atom_site.occupancy", count, "1"),
        "bfactor": _column(data, "_atom_site.B_iso_or_equiv", count),
        "element": _column(data, "_atom_site.type_symbol", count),
        "x": _column(data, "_atom_site.Cartn_x", count),
        "y": _column(data, "_atom_site.Cartn_y", count),
        "z": _column(data, "_atom_site.Cartn_z", count),
    }
    for index in range(count):
        seq = _clean(columns["auth_seq"][index]) or _clean(columns["label_seq"][index])
        try:
            residue_number = int(float(seq))
        except ValueError as error:
            raise StructureError(f"Invalid mmCIF residue number {seq!r} in row {index + 1}") from error
        coordinates = tuple(_float(columns[name][index]) for name in ("x", "y", "z"))
        valid = all(value is not None for value in coordinates)
        atom_name = (_clean(columns["auth_atom"][index]) or _clean(columns["label_atom"][index])).upper()
        rows.append(_RawAtom(
            _clean(models_column[index]) or "1", str(groups[index]).upper(),
            _clean(columns["serial"][index]) or str(index + 1), _clean(chains[index]) or "_",
            residue_number, _clean(columns["insertion"][index]),
            (_clean(columns["auth_comp"][index]) or _clean(columns["label_comp"][index]) or "UNK").upper(),
            atom_name, _clean(columns["alt_auth"][index]) or _clean(columns["alt_label"][index]),
            _float(columns["occupancy"][index], 1.0) or 0.0,
            _float(columns["bfactor"][index]), _element(atom_name, columns["element"][index]),
            tuple(float(value) for value in coordinates) if valid else None,
        ))
    return rows, models, chain_id_source


def _is_hydrogen(row: _RawAtom) -> bool:
    return row.element.upper() in {"H", "D"} or row.atom_name.upper().startswith(("H", "D"))


def _is_polymer(row: _RawAtom, policy: NormalizationPolicy) -> bool:
    return (
        row.record == "ATOM"
        or row.residue_name in STANDARD_RESIDUES
        or row.residue_name in policy.residue_name_map
    )


def _alt_rank(row: _RawAtom) -> tuple[float, int, str]:
    preference = 2 if not row.altloc else 1 if row.altloc == "A" else 0
    # max() selects occupancy, then blank/A, then deterministic reverse lexical.
    return (row.occupancy, preference, "".join(chr(255 - ord(c)) for c in row.altloc))


def _select_alternate_residue_identities(
    rows: list[_RawAtom], report: ParseReport
) -> list[_RawAtom]:
    """Choose one residue name when alternate identities occupy one sequence site.

    PDB microheterogeneity can encode, for example, MET altloc A and VAL altloc
    B at the same chain/residue number. Atom-level grouping by residue name
    alone retains both identities and creates duplicate backbone atom keys.
    Select the residue identity by the same occupancy/blank/A/lexical policy
    used for ordinary atom alternates, while rejecting genuinely ambiguous
    sites that do not carry alternate-location identifiers.
    """
    by_site: dict[tuple[str, int, str], list[_RawAtom]] = defaultdict(list)
    for row in rows:
        by_site[(row.chain, row.residue_number, row.insertion)].append(row)

    selected: list[_RawAtom] = []
    for site, site_rows in by_site.items():
        by_name: dict[str, list[_RawAtom]] = defaultdict(list)
        for row in site_rows:
            by_name[row.residue_name].append(row)
        if len(by_name) == 1:
            selected.extend(site_rows)
            continue
        if not any(row.altloc for row in site_rows):
            chain, number, insertion = site
            raise StructureError(
                "Multiple residue identities without alternate-location labels "
                f"at {chain}:{number}{insertion}: {','.join(sorted(by_name))}"
            )

        ranks = {
            name: max((_alt_rank(row) for row in name_rows))
            for name, name_rows in by_name.items()
        }
        best_rank = max(ranks.values())
        winners = sorted(name for name, rank in ranks.items() if rank == best_rank)
        if len(winners) != 1:
            chain, number, insertion = site
            raise StructureError(
                "Ambiguous alternate residue identities at "
                f"{chain}:{number}{insertion}: {','.join(winners)}"
            )
        winner = winners[0]
        retained = by_name[winner]
        discarded_count = len(site_rows) - len(retained)
        report.alternate_atom_site_count += discarded_count
        report.discarded_alternate_count += discarded_count
        selected.extend(retained)
    return selected


def _normalized_atom_name(original_residue: str, normalized_residue: str, atom_name: str) -> str:
    if original_residue == "MSE" and normalized_residue == "MET" and atom_name == "SE":
        return "SD"
    if original_residue == "SEC" and normalized_residue == "CYS" and atom_name == "SE":
        return "SG"
    return atom_name


def load_assembly(
    path: str | Path,
    model_index: int = 0,
    policy: NormalizationPolicy | None = None,
    chain_id_source: str = "auto",
) -> Assembly:
    """Load one model and deterministically select alternate atom locations."""
    source = Path(path)
    if not source.is_file():
        raise FileNotFoundError(source)
    if chain_id_source not in {"auto", "author", "label"}:
        raise ValueError("chain_id_source must be auto, author, or label")
    policy = policy or NormalizationPolicy()
    if source.suffix.lower() in {".cif", ".mmcif"}:
        raw, models, selected_chain_source = _mmcif_rows(source, chain_id_source)
    else:
        raw, models = _pdb_rows(source)
        selected_chain_source = "pdb_chain_id"
    if not models:
        raise StructureError(f"No atoms found in {source}")
    if not 0 <= model_index < len(models):
        raise StructureError(f"model_index {model_index} is outside 0..{len(models) - 1}")
    model_identifier = models[model_index]
    report = ParseReport(len(models), model_identifier, selected_chain_source)
    selected_rows = [row for row in raw if row.model == model_identifier]
    report.invalid_coordinate_count = sum(row.coord is None for row in selected_rows)
    selected_rows = [row for row in selected_rows if row.coord is not None]
    selected_rows = _select_alternate_residue_identities(selected_rows, report)

    grouped: dict[tuple[str, int, str, str, str], list[_RawAtom]] = defaultdict(list)
    raw_keys: set[tuple[str, int, str, str, str, str]] = set()
    for row in selected_rows:
        raw_key = (row.chain, row.residue_number, row.insertion, row.residue_name, row.atom_name, row.altloc)
        if raw_key in raw_keys:
            report.duplicate_raw_atom_keys.append(":".join(map(str, raw_key)))
        raw_keys.add(raw_key)
        grouped[(row.chain, row.residue_number, row.insertion, row.residue_name, row.atom_name)].append(row)
    chosen: list[_RawAtom] = []
    for choices in grouped.values():
        if len(choices) > 1 or any(choice.altloc for choice in choices):
            report.alternate_atom_site_count += len(choices)
            report.discarded_alternate_count += len(choices) - 1
        chosen.append(max(choices, key=_alt_rank))

    residues: dict[tuple[str, int, str, str, str], list[_RawAtom]] = defaultdict(list)
    removed_waters: set[tuple[str, int, str, str]] = set()
    removed_ligands: set[tuple[str, int, str, str]] = set()
    removed_ligand_names: set[str] = set()
    removed_metal_elements: set[str] = set()
    for row in chosen:
        if policy.remove_hydrogens and _is_hydrogen(row):
            report.hydrogen_count_removed += 1
            continue
        entity = "polymer" if _is_polymer(row, policy) else "water" if row.residue_name in WATER_NAMES else "nonpolymer"
        if entity == "water" and policy.remove_waters:
            removed_waters.add((row.chain, row.residue_number, row.insertion, row.residue_name))
            continue
        if entity == "nonpolymer":
            keep = row.residue_name in policy.retain_nonpolymer_names or (policy.retain_metals and row.element in METAL_ELEMENTS)
            if not keep:
                removed_ligands.add((row.chain, row.residue_number, row.insertion, row.residue_name))
                removed_ligand_names.add(row.residue_name)
                if row.element in METAL_ELEMENTS:
                    removed_metal_elements.add(row.element)
                continue
        residues[(row.chain, row.residue_number, row.insertion, row.residue_name, entity)].append(row)
    report.water_count_removed = len(removed_waters)
    report.ligand_count_removed = len(removed_ligands)
    report.removed_ligand_names = sorted(removed_ligand_names)
    report.removed_metal_elements = sorted(removed_metal_elements)

    chains: dict[str, ChainRecord] = {}
    nonpolymer: list[ResidueRecord] = []
    by_chain: dict[str, list[tuple[tuple[str, int, str, str, str], list[_RawAtom]]]] = defaultdict(list)
    for key, rows in residues.items():
        by_chain[key[0]].append((key, rows))
    for chain_id in sorted(by_chain):
        polymer_records: list[ResidueRecord] = []
        for key, rows in sorted(by_chain[chain_id], key=lambda item: (item[0][1], item[0][2], item[0][3])):
            _chain, number, insertion, original, entity = key
            normalized = policy.residue_name_map.get(original, original)
            if normalized != original:
                report.normalized_residues.append({
                    "chain_id": chain_id, "residue": f"{number}{insertion}",
                    "original_name": original, "normalized_name": normalized,
                })
            residue_id = ResidueID(model_index, chain_id, number, insertion, normalized)
            atoms: dict[str, AtomRecord] = {}
            for row in rows:
                allowed_atoms = UNMODIFIED_SUBSTITUTION_ATOMS.get(original)
                if allowed_atoms is not None and row.atom_name not in allowed_atoms:
                    report.discarded_modification_atoms.append({
                        "chain_id": chain_id,
                        "residue": f"{number}{insertion}",
                        "original_name": original,
                        "normalized_name": normalized,
                        "atom_name": row.atom_name,
                        "element": row.element,
                    })
                    continue
                atom_name = _normalized_atom_name(original, normalized, row.atom_name)
                atom_key = AtomKey(model_index, chain_id, number, insertion, normalized, atom_name, row.altloc)
                atoms[atom_name] = AtomRecord(
                    atom_key, row.coord or (0.0, 0.0, 0.0), row.element, row.occupancy,
                    row.b_factor, row.record, row.serial,
                )
            record = ResidueRecord(
                residue_id, original, normalized, ONE_LETTER.get(normalized, "X"), atoms,
                len(polymer_records) if entity == "polymer" else -1, rows[0].record,
            )
            if entity == "polymer":
                polymer_records.append(record)
            else:
                nonpolymer.append(record)
        if polymer_records:
            chains[chain_id] = ChainRecord(chain_id, polymer_records)
    if not chains:
        raise StructureError(f"No polymer chains found in selected model of {source}")
    warnings = []
    if report.invalid_coordinate_count:
        warnings.append(f"{report.invalid_coordinate_count} atoms with invalid coordinates were omitted")
    if report.normalized_residues:
        warnings.append(f"{len(report.normalized_residues)} residue names were normalized with provenance retained")
    if report.discarded_modification_atoms:
        warnings.append(
            f"{len(report.discarded_modification_atoms)} modification-specific atoms "
            "were discarded during unmodified-residue substitution"
        )
    return Assembly(chains, nonpolymer, str(source.resolve()), model_index, report, warnings)


def normalize_assembly(assembly: Assembly, policy: NormalizationPolicy | None = None) -> Assembly:
    """Return an already-normalized assembly; parsing performs normalization atomically.

    This explicit API exists so callers can share the README's load/normalize workflow.
    Re-normalizing with a different policy requires loading the source again, because
    discarded alternate locations and solvent are intentionally not retained in memory.
    """
    if policy is None:
        return assembly
    if assembly.source is None:
        raise ValueError("Cannot apply a new normalization policy without assembly.source")
    return load_assembly(assembly.source, assembly.model_index, policy)
