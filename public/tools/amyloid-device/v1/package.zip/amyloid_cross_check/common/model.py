"""Typed, stable in-memory representation shared by structure scorers."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

import numpy as np


SCHEMA_VERSION = "amyloid-common-1.2"
BACKBONE_ATOMS = frozenset({"N", "CA", "C", "O"})
ONE_LETTER = {
    "ALA": "A", "ARG": "R", "ASN": "N", "ASP": "D", "CYS": "C",
    "GLN": "Q", "GLU": "E", "GLY": "G", "HIS": "H", "ILE": "I",
    "LEU": "L", "LYS": "K", "MET": "M", "PHE": "F", "PRO": "P",
    "SER": "S", "THR": "T", "TRP": "W", "TYR": "Y", "VAL": "V",
}
STANDARD_RESIDUES = frozenset(ONE_LETTER)
WATER_NAMES = frozenset({"HOH", "WAT", "DOD", "H2O"})
METAL_ELEMENTS = frozenset({
    "LI", "NA", "K", "RB", "CS", "MG", "CA", "SR", "BA", "AL", "GA",
    "MN", "FE", "CO", "NI", "CU", "ZN", "CD", "HG", "CR", "MO", "W",
})


@dataclass(frozen=True, order=True, slots=True)
class ResidueID:
    model_id: int
    chain_id: str
    residue_number: int
    insertion_code: str
    residue_name: str

    def text(self) -> str:
        return f"{self.chain_id}:{self.residue_number}{self.insertion_code}:{self.residue_name}"


@dataclass(frozen=True, order=True, slots=True)
class AtomKey:
    model_id: int
    chain_id: str
    residue_number: int
    insertion_code: str
    residue_name: str
    atom_name: str
    alternate_location: str

    def text(self) -> str:
        insertion = self.insertion_code or ""
        alt = f":alt{self.alternate_location}" if self.alternate_location else ""
        return (
            f"{self.model_id}:{self.chain_id}:{self.residue_number}{insertion}:"
            f"{self.residue_name}:{self.atom_name}{alt}"
        )


@dataclass(frozen=True, slots=True)
class AtomRecord:
    key: AtomKey
    coord: tuple[float, float, float]
    element: str
    occupancy: float
    b_factor: float | None
    record_type: str
    source_serial: str

    @property
    def name(self) -> str:
        return self.key.atom_name

    @property
    def alternate_location(self) -> str:
        return self.key.alternate_location

    @property
    def array(self) -> np.ndarray:
        return np.asarray(self.coord, dtype=float)


@dataclass(slots=True)
class ResidueRecord:
    id: ResidueID
    original_name: str
    normalized_name: str
    one_letter: str
    atoms: dict[str, AtomRecord]
    sequence_index: int
    record_type: str = "ATOM"

    def atom(self, name: str) -> AtomRecord | None:
        return self.atoms.get(name.upper())


@dataclass(slots=True)
class ChainRecord:
    id: str
    residues: list[ResidueRecord]

    @property
    def sequence(self) -> str:
        return "".join(residue.one_letter for residue in self.residues)

    @property
    def atoms(self) -> list[AtomRecord]:
        return [atom for residue in self.residues for atom in residue.atoms.values()]

    @property
    def centroid(self) -> np.ndarray:
        atoms = self.atoms
        return np.mean([atom.coord for atom in atoms], axis=0) if atoms else np.zeros(3)


@dataclass(slots=True)
class ParseReport:
    total_models: int = 0
    selected_model_identifier: str = ""
    chain_id_source: str = "pdb_chain_id"
    alternate_atom_site_count: int = 0
    discarded_alternate_count: int = 0
    hydrogen_count_removed: int = 0
    water_count_removed: int = 0
    ligand_count_removed: int = 0
    removed_ligand_names: list[str] = field(default_factory=list)
    removed_metal_elements: list[str] = field(default_factory=list)
    invalid_coordinate_count: int = 0
    duplicate_raw_atom_keys: list[str] = field(default_factory=list)
    normalized_residues: list[dict[str, str]] = field(default_factory=list)
    discarded_modification_atoms: list[dict[str, str]] = field(default_factory=list)


@dataclass(slots=True)
class Assembly:
    chains: dict[str, ChainRecord]
    nonpolymer_residues: list[ResidueRecord] = field(default_factory=list)
    source: str | None = None
    model_index: int = 0
    parse_report: ParseReport = field(default_factory=ParseReport)
    warnings: list[str] = field(default_factory=list)

    @property
    def atoms(self) -> list[AtomRecord]:
        polymer = [atom for chain in self.chains.values() for atom in chain.atoms]
        other = [atom for residue in self.nonpolymer_residues for atom in residue.atoms.values()]
        return polymer + other


@dataclass(slots=True)
class NormalizationPolicy:
    remove_hydrogens: bool = True
    remove_waters: bool = True
    retain_nonpolymer_names: frozenset[str] = frozenset()
    retain_metals: bool = False
    residue_name_map: dict[str, str] = field(default_factory=lambda: {
        "MSE": "MET", "SEC": "CYS", "PYL": "LYS",
        "PTR": "TYR", "TYC": "TYR",
    })


@dataclass(slots=True)
class AnalysisConfig:
    minimum_sequence_identity: float = 0.85
    minimum_sequence_coverage: float = 0.70
    minimum_mapped_residues: int = 3
    residue_contact_distance: float = 8.0
    heavy_atom_contact_distance: float = 4.5
    backbone_contact_distance: float = 5.5
    severe_clash_distance: float = 2.0
    chain_break_cn_distance: float = 2.0
    maximum_pair_rmsd: float = 3.0
    transform_rotation_tolerance_degrees: float = 15.0
    transform_length_relative_tolerance: float = 0.45


@dataclass(frozen=True, slots=True)
class ResidueMapping:
    chain_a: str
    chain_b: str
    pairs: tuple[tuple[int, int], ...]
    residue_pairs: tuple[tuple[ResidueID, ResidueID], ...]
    identity: float
    coverage_a: float
    coverage_b: float
    orientation: Literal["parallel", "antiparallel", "undetermined"]
    register_offset: int | None


@dataclass(frozen=True, slots=True)
class PairwiseTransform:
    chain_a: str
    chain_b: str
    rotation: tuple[tuple[float, float, float], ...]
    translation: tuple[float, float, float]
    centroid_displacement: tuple[float, float, float]
    fitted_atom_count: int
    fitted_residue_count: int
    rmsd: float
    sequence_coverage: float

    def apply(self, coordinates: np.ndarray) -> np.ndarray:
        return np.asarray(coordinates) @ np.asarray(self.rotation) + np.asarray(self.translation)

    def inverse(self) -> "PairwiseTransform":
        rotation = np.asarray(self.rotation).T
        translation = -np.asarray(self.translation) @ rotation
        return PairwiseTransform(
            self.chain_b, self.chain_a,
            tuple(tuple(float(x) for x in row) for row in rotation),
            tuple(float(x) for x in translation),
            tuple(-x for x in self.centroid_displacement),
            self.fitted_atom_count, self.fitted_residue_count, self.rmsd,
            self.sequence_coverage,
        )


@dataclass(slots=True)
class InterfaceRecord:
    chain_a: str
    chain_b: str
    minimum_heavy_atom_distance: float | None
    residue_contact_count: int
    heavy_atom_contact_count: int
    backbone_contact_count: int
    preliminary_bsa: float
    sequence_equivalent: bool
    residue_contacts: tuple[tuple[ResidueID, ResidueID], ...]
    transform: PairwiseTransform | None = None


@dataclass(slots=True)
class ChainGraph:
    nodes: tuple[str, ...]
    edges: list[InterfaceRecord]


@dataclass(slots=True)
class ChainGroup:
    id: str
    chain_ids: tuple[str, ...]


@dataclass(slots=True)
class LayerAssignment:
    chain_id: str
    protofilament_id: str
    layer_index: int
    observed_or_virtual: Literal["observed", "virtual"] = "observed"
    alternatives: tuple[dict[str, Any], ...] = ()


@dataclass(slots=True)
class QualityControlReport:
    counts: dict[str, int]
    missing_backbone: list[dict[str, Any]]
    incomplete_sidechains: list[dict[str, Any]]
    duplicate_atom_identifiers: list[str]
    alternate_conformations: dict[str, int]
    nonstandard_residues: list[str]
    ligands: list[str]
    metals: list[str]
    waters_removed: int
    minimum_nonbonded_heavy_atom_distance: float | None
    severe_clashes: list[dict[str, Any]]
    intrachain_severe_clashes: list[dict[str, Any]]
    interchain_severe_clashes: list[dict[str, Any]]
    chain_breaks: list[dict[str, Any]]
    residue_number_discontinuities: list[dict[str, Any]]
    zero_occupancy_atoms: list[str]
    invalid_coordinate_count: int
    completeness_fraction: float
    energy_coverage_complete: bool
    geometry_coverage_fraction: float
    packing_coverage_fraction: float
    energy_coverage_fraction: float
    parameterized_fraction_of_all_polymer_residues: float
    completeness_within_parameterized_residues: float
    geometry_assessable: bool
    physical_plausibility: bool


@dataclass(slots=True)
class CommonResult:
    assembly: Assembly
    quality_control: QualityControlReport
    chain_groups: list[ChainGroup]
    mappings: list[ResidueMapping]
    chain_graph: ChainGraph
    layers: list[LayerAssignment]
    assessability: str
    alternative_layer_assignments: list[dict[str, Any]]
    metadata: dict[str, Any]
