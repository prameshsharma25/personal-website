"""Narrow adapters for the existing geometry and energetics implementations."""

from __future__ import annotations

from .model import Assembly


def to_energy_atoms(assembly: Assembly):
    """Convert to energetics.model.Atom objects without reparsing the structure."""
    try:
        from amyloid_cross_check.energetics.model import Atom
    except ImportError as error:  # pragma: no cover - depends on sibling installation
        raise ImportError("Install/import the energetics package before using to_energy_atoms") from error
    result = []
    for fallback_serial, atom in enumerate(assembly.atoms, 1):
        try:
            serial = int(atom.source_serial)
        except ValueError:
            serial = fallback_serial
        result.append(Atom(
            serial, atom.name, atom.key.residue_name, atom.key.chain_id,
            atom.key.residue_number, atom.key.insertion_code,
            *atom.coord, atom.element, atom.record_type,
        ))
    return result


def to_geometry_assembly(assembly: Assembly):
    """Convert to geometry.score_geometry records without writing temporary files."""
    try:
        from amyloid_cross_check.geometry import score_geometry as geometry
    except ImportError as error:  # pragma: no cover - depends on sibling installation
        raise ImportError("Import the geometry package before using to_geometry_assembly") from error
    chains = {}
    for chain in assembly.chains.values():
        residues = []
        for residue in chain.residues:
            residue_id = geometry.ResidueID(
                residue.id.model_id, residue.id.chain_id, residue.id.residue_number,
                residue.id.insertion_code, residue.normalized_name,
            )
            atoms = {
                name: geometry.AtomRecord(
                    name, atom.element, atom.array.copy(), atom.occupancy,
                    atom.alternate_location,
                )
                for name, atom in residue.atoms.items()
            }
            residues.append(geometry.ResidueRecord(
                residue_id, residue.one_letter, atoms, residue.sequence_index,
            ))
        chains[chain.id] = geometry.ChainRecord(chain.id, residues)
    from .pipeline import atom_identity_sha256, normalized_assembly_sha256, sha256_file

    return geometry.Assembly(
        chains,
        assembly.source,
        assembly.model_index,
        list(assembly.warnings),
        {
            "source_file_sha256": sha256_file(assembly.source) if assembly.source else None,
            "normalized_assembly_sha256": normalized_assembly_sha256(assembly),
            "atom_identity_sha256": atom_identity_sha256(assembly),
            "chain_id_source": assembly.parse_report.chain_id_source,
        },
    )
