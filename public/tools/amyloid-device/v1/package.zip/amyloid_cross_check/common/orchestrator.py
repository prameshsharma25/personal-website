"""Canonical, restartable one-parse orchestration for structural components."""

from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from typing import Any, Sequence

from .adapters import to_energy_atoms, to_geometry_assembly
from .io import load_assembly
from .model import AnalysisConfig, NormalizationPolicy
from .output import write_outputs as write_common_outputs
from .pipeline import (
    analyze_assembly,
    atom_identity_sha256,
    layer_assignment_sha256,
    normalized_assembly_sha256,
    sha256_file,
)


COMPONENT_SCHEMAS = {
    "common": "amyloid-common-1.2",
    "geometry": "amyloid-geometry-1.2",
    "packing": "amyloid-interface-dryness-1.1",
    "energy": "amyloid-energetics-1.3",
}

REQUEST_SCHEMA_VERSION = "amyloid-structural-pipeline-request-1.0"


def _read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected a JSON object in {path}")
    return value


def _schema(name: str, document: dict[str, Any]) -> str | None:
    if name in {"packing", "energy"}:
        return document.get("metadata", {}).get("schema_version")
    return document.get("schema_version")


def _json_default(value: Any) -> Any:
    if isinstance(value, (set, frozenset)):
        return sorted(value)
    raise TypeError(f"Object of type {type(value).__name__} is not JSON serializable")


def _document_sha256(document: dict[str, Any]) -> str:
    encoded = json.dumps(
        document, sort_keys=True, separators=(",", ":"), default=_json_default,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _scientific_request(
    *,
    structure_path: Path,
    prediction_id: str,
    model_index: int,
    chain_id_source: str,
    explicit_layer_map: str | Path | None,
    common_config: AnalysisConfig,
    normalization_policy: NormalizationPolicy,
    geometry_config: Any,
    packing_config: Any,
    energy_config: Any,
) -> tuple[dict[str, Any], str]:
    """Build the content-addressed scientific contract used for safe reuse."""
    packing_parameters = asdict(packing_config)
    packing_parameters.pop("threads", None)
    energy_parameters = asdict(energy_config)
    energy_parameters.pop("threads", None)
    layer_map_path = (
        Path(explicit_layer_map).resolve() if explicit_layer_map is not None else None
    )
    request = {
        "schema_version": REQUEST_SCHEMA_VERSION,
        "prediction_id": prediction_id,
        "input": {
            "source_file_sha256": sha256_file(structure_path),
            "structure_format": (
                "mmcif" if structure_path.suffix.lower() in {".cif", ".mmcif"}
                else "pdb"
            ),
            "model_index": model_index,
            "chain_id_source": chain_id_source,
            "explicit_layer_map_sha256": (
                sha256_file(layer_map_path) if layer_map_path is not None else None
            ),
        },
        "component_schemas": dict(COMPONENT_SCHEMAS),
        "scientific_parameters": {
            "common": {
                "normalization": asdict(normalization_policy),
                "analysis": asdict(common_config),
            },
            "geometry": asdict(geometry_config),
            "packing": packing_parameters,
            "energy": energy_parameters,
        },
    }
    # Store the exact JSON-native value that is hashed.  This avoids type-only
    # differences (for example, a frozenset before publication and a list after
    # reading JSON) from invalidating an otherwise intact result.
    request = json.loads(json.dumps(request, sort_keys=True, default=_json_default))
    return request, _document_sha256(request)


def inspect_pipeline_state(
    result_directory: str | Path,
    *,
    expected_request_fingerprint_sha256: str | None = None,
) -> dict[str, Any]:
    """Classify a published result without treating partial output as complete."""
    result = Path(result_directory)
    if not result.exists():
        return {"status": "missing", "result_directory": str(result)}
    if not result.is_dir():
        return {
            "status": "corrupt",
            "result_directory": str(result),
            "reason": "result path is not a directory",
        }
    marker = result / "COMPLETED.json"
    if not marker.exists():
        return {
            "status": "partial",
            "result_directory": str(result),
            "reason": "completion marker is absent",
        }
    try:
        completion = _read_json(marker)
        manifest_path = Path(completion["manifest_path"])
        manifest = _read_json(manifest_path)
        rows = manifest.get("rows")
        if not isinstance(rows, list) or len(rows) != 1 or not isinstance(rows[0], dict):
            raise ValueError("manifest must contain exactly one row")
        row = rows[0]
        observed: dict[str, str | None] = {}
        for name in COMPONENT_SCHEMAS:
            component_path = Path(row[name])
            document = _read_json(component_path)
            observed[name] = _schema(name, document)
        for paths in manifest.get("artifacts", {}).values():
            if not isinstance(paths, list):
                raise ValueError("artifact entries must be lists")
            for path in paths:
                artifact = Path(path)
                if not artifact.is_file() or artifact.stat().st_size == 0:
                    raise ValueError(f"missing or empty artifact: {artifact}")
    except (KeyError, OSError, TypeError, ValueError, json.JSONDecodeError) as error:
        return {
            "status": "corrupt",
            "result_directory": str(result),
            "reason": str(error),
        }
    incompatible = {
        name: {"expected": COMPONENT_SCHEMAS[name], "observed": observed.get(name)}
        for name in COMPONENT_SCHEMAS
        if observed.get(name) != COMPONENT_SCHEMAS[name]
    }
    if incompatible:
        return {
            "status": "incompatible_schema",
            "result_directory": str(result),
            "schemas": incompatible,
            "manifest_path": str(manifest_path),
        }
    request = manifest.get("request")
    manifest_fingerprint = manifest.get("request_fingerprint_sha256")
    completion_fingerprint = completion.get("request_fingerprint_sha256")
    if not isinstance(request, dict) or not isinstance(manifest_fingerprint, str):
        return {
            "status": "incompatible_request",
            "result_directory": str(result),
            "manifest_path": str(manifest_path),
            "reason": "published result has no reusable scientific request fingerprint",
        }
    if (
        _document_sha256(request) != manifest_fingerprint
        or completion_fingerprint != manifest_fingerprint
    ):
        return {
            "status": "corrupt",
            "result_directory": str(result),
            "manifest_path": str(manifest_path),
            "reason": "request fingerprint does not match the published request contract",
        }
    if (
        expected_request_fingerprint_sha256 is not None
        and manifest_fingerprint != expected_request_fingerprint_sha256
    ):
        return {
            "status": "incompatible_request",
            "result_directory": str(result),
            "manifest_path": str(manifest_path),
            "reason": "published result was produced for a different scientific request",
            "request_fingerprints": {
                "expected": expected_request_fingerprint_sha256,
                "observed": manifest_fingerprint,
            },
        }
    return {
        "status": "complete",
        "result_directory": str(result),
        "manifest_path": str(manifest_path),
        "manifest": manifest,
        "completion": completion,
    }


def _git_state(source: Path) -> dict[str, Any]:
    try:
        root = subprocess.run(
            ["git", "-C", str(source), "rev-parse", "--show-toplevel"],
            check=True, capture_output=True, text=True, timeout=5,
        ).stdout.strip()
        commit = subprocess.run(
            ["git", "-C", root, "rev-parse", "HEAD"],
            check=True, capture_output=True, text=True, timeout=5,
        ).stdout.strip()
        dirty = bool(subprocess.run(
            ["git", "-C", root, "status", "--porcelain"],
            check=True, capture_output=True, text=True, timeout=5,
        ).stdout.strip())
        return {"root": root, "commit": commit, "dirty": dirty}
    except (OSError, subprocess.SubprocessError):
        return {"root": None, "commit": None, "dirty": None}


def _validate_work_products(
    primary: dict[str, Path], artifacts: dict[str, list[Path]]
) -> tuple[dict[str, dict[str, Any]], dict[str, str]]:
    documents: dict[str, dict[str, Any]] = {}
    schemas: dict[str, str] = {}
    for name, expected in COMPONENT_SCHEMAS.items():
        document = _read_json(primary[name])
        observed = _schema(name, document)
        if observed != expected:
            raise ValueError(
                f"{name} emitted incompatible schema {observed!r}; expected {expected!r}"
            )
        documents[name] = document
        schemas[name] = observed
    for name, paths in artifacts.items():
        if not paths:
            raise ValueError(f"{name} emitted no artifacts")
        for path in paths:
            if not path.is_file() or path.stat().st_size == 0:
                raise ValueError(f"{name} emitted a missing or empty artifact: {path}")
    return documents, schemas


def run_structural_pipeline(
    structure: str | Path,
    output_directory: str | Path,
    *,
    prediction_id: str,
    model_index: int = 0,
    chain_id_source: str = "auto",
    explicit_layer_map: str | Path | None = None,
    energy_mode: str = "sawaya_compat",
    threads: int = 1,
    unsupported_residue_policy: str = "error",
    command: Sequence[str] | None = None,
) -> dict[str, Any]:
    """Run all components in temporary storage and atomically publish them."""
    from amyloid_cross_check.energetics.io import write_results as write_energy_outputs
    from amyloid_cross_check.energetics.model import EnergyConfig
    from amyloid_cross_check.energetics.scoring import score_sawaya
    from amyloid_cross_check.geometry import score_geometry as geometry
    from amyloid_cross_check.interface_dryness import PackingConfig, score_packing
    from amyloid_cross_check.interface_dryness.output import write_outputs as write_packing_outputs

    if not prediction_id or Path(prediction_id).name != prediction_id:
        raise ValueError("prediction_id must be a non-empty filename-safe identifier")
    if threads < 1:
        raise ValueError("threads must be positive")
    started = datetime.now(timezone.utc)
    started_clock = time.monotonic()
    effective_command = list(command) if command is not None else [
        "python-api:run_structural_pipeline"
    ]
    structure_path = Path(structure).resolve()
    output_root = Path(output_directory).resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    common_config = AnalysisConfig()
    normalization_policy = NormalizationPolicy()
    geometry_config = geometry.GeometryConfig(model_index=model_index)
    packing_config = PackingConfig(threads=threads)
    energy_config = EnergyConfig(
        mode=energy_mode,
        threads=threads,
        unsupported_policy=unsupported_residue_policy,
    )
    request, request_fingerprint = _scientific_request(
        structure_path=structure_path,
        prediction_id=prediction_id,
        model_index=model_index,
        chain_id_source=chain_id_source,
        explicit_layer_map=explicit_layer_map,
        common_config=common_config,
        normalization_policy=normalization_policy,
        geometry_config=geometry_config,
        packing_config=packing_config,
        energy_config=energy_config,
    )
    final_directory = output_root / prediction_id
    state = inspect_pipeline_state(
        final_directory,
        expected_request_fingerprint_sha256=request_fingerprint,
    )
    if state["status"] == "complete":
        manifest = dict(state["manifest"])
        manifest.update({
            "manifest_path": state["manifest_path"],
            "publication_state": "complete",
            "reused": True,
        })
        return manifest
    if state["status"] != "missing":
        raise RuntimeError(
            f"Refusing to overwrite {state['status']} result at {final_directory}: "
            f"{state.get('reason', state.get('schemas', 'manual review required'))}"
        )

    temporary_parent = Path(os.environ.get("TMPDIR", str(output_root)))
    if not temporary_parent.is_dir():
        temporary_parent = output_root
    work_directory = Path(tempfile.mkdtemp(
        prefix=f".{prediction_id}.work-", dir=temporary_parent
    ))
    publish_directory: Path | None = None
    try:
        assembly = load_assembly(
            structure_path,
            model_index=model_index,
            policy=normalization_policy,
            chain_id_source=chain_id_source,
        )
        common = analyze_assembly(
            assembly,
            model_index=model_index,
            normalization_policy=normalization_policy,
            config=common_config,
            chain_id_source=chain_id_source,
            explicit_layer_map=explicit_layer_map,
            prediction_metadata={"prediction_id": prediction_id},
            command=effective_command,
        )
        common_paths = write_common_outputs(common, work_directory / prediction_id)

        layer_hash = layer_assignment_sha256(common.layers)
        geometry_assembly = to_geometry_assembly(assembly)
        geometry_assembly.identity["layer_assignment_sha256"] = layer_hash
        geometry_assembly.identity["prediction_id"] = prediction_id
        geometry_result = geometry.score_geometry(
            geometry_assembly,
            config=geometry_config,
            layer_assignments=common.layers,
        )
        geometry_path = work_directory / f"{prediction_id}.geometry.json"
        geometry.write_outputs(geometry_result, geometry_path)
        geometry_paths = [
            geometry_path,
            work_directory / f"{prediction_id}.pairs.csv",
            work_directory / f"{prediction_id}.transforms.csv",
            work_directory / f"{prediction_id}.hydrogen_bonds.csv",
            work_directory / f"{prediction_id}.extensions.csv",
        ]

        packing_result = score_packing(
            assembly,
            layers=common.layers,
            config=packing_config,
            prediction_id=prediction_id,
            command=effective_command,
        )
        packing_paths = write_packing_outputs(
            packing_result, work_directory / prediction_id
        )

        indices_by_protofilament: dict[str, list[int]] = {}
        for item in common.layers:
            indices_by_protofilament.setdefault(item.protofilament_id, []).append(item.layer_index)
        energy_layers = {
            item.chain_id: {
                "layer": item.layer_index,
                "protofilament": item.protofilament_id,
                "observed_or_virtual": item.observed_or_virtual,
                "end_or_central": (
                    "end" if item.layer_index in {
                        min(indices_by_protofilament[item.protofilament_id]),
                        max(indices_by_protofilament[item.protofilament_id]),
                    } else "central"
                ),
            }
            for item in common.layers
        }
        identity = {
            "path": assembly.source,
            "source_file_sha256": sha256_file(assembly.source) if assembly.source else None,
            "normalized_assembly_sha256": normalized_assembly_sha256(assembly),
            "atom_identity_sha256": atom_identity_sha256(assembly),
            "layer_assignment_sha256": layer_hash,
            "model_index": assembly.model_index,
            "chain_id_source": assembly.parse_report.chain_id_source,
            "prediction_id": prediction_id,
        }
        energy_result = score_sawaya(
            to_energy_atoms(assembly),
            energy_layers,
            energy_config,
            input_identity=identity,
        )
        energy_result.metadata["prediction_id"] = prediction_id
        energy_paths = write_energy_outputs(
            energy_result, work_directory / prediction_id
        )

        primary_work = {
            "common": common_paths[0], "geometry": geometry_path,
            "packing": packing_paths[0], "energy": energy_paths[0],
        }
        artifacts_work = {
            "common": common_paths, "geometry": geometry_paths,
            "packing": packing_paths, "energy": energy_paths,
        }
        documents, schemas = _validate_work_products(primary_work, artifacts_work)
        final_paths = {
            name: final_directory / path.name for name, path in primary_work.items()
        }
        primary = {
            "prediction_id": prediction_id,
            **{name: str(path) for name, path in final_paths.items()},
        }
        final_artifacts = {
            name: [str(final_directory / path.name) for path in paths]
            for name, paths in artifacts_work.items()
        }
        parameter_hashes = {
            "common": documents["common"].get("parameter_hash"),
            "geometry": documents["geometry"].get("config", {}).get("parameter_hash"),
            "packing": documents["packing"].get("metadata", {}).get("parameter_hash"),
            "energy": documents["energy"].get("metadata", {}).get("parameter_hash"),
        }
        ended = datetime.now(timezone.utc)
        provenance = {
            "started_at_utc": started.isoformat(),
            "completed_at_utc": ended.isoformat(),
            "runtime_seconds": round(time.monotonic() - started_clock, 6),
            "command": effective_command,
            "working_directory": str(Path.cwd()),
            "host": socket.gethostname(),
            "python": platform.python_version(),
            "platform": platform.platform(),
            "environment": {
                "python_executable": sys.executable,
                "slurm_submit_dir": os.environ.get("SLURM_SUBMIT_DIR"),
                "slurm_job_name": os.environ.get("SLURM_JOB_NAME"),
                "omp_num_threads": os.environ.get("OMP_NUM_THREADS"),
                "mkl_num_threads": os.environ.get("MKL_NUM_THREADS"),
            },
            "resources": {
                "threads": threads,
                "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
                "slurm_cpus_per_task": os.environ.get("SLURM_CPUS_PER_TASK"),
                "slurm_ntasks": os.environ.get("SLURM_NTASKS"),
                "tmpdir": str(temporary_parent),
            },
            "git": _git_state(Path.cwd()),
            "component_schemas": schemas,
            "parameter_hashes": parameter_hashes,
            "input": identity,
            "request_fingerprint_sha256": request_fingerprint,
        }
        manifest = {
            "schema_version": "amyloid-structural-pipeline-manifest-1.1",
            "prediction_id": prediction_id,
            "normalized_assembly_sha256": identity["normalized_assembly_sha256"],
            "source_file_sha256": identity["source_file_sha256"],
            "model_index": model_index,
            "chain_id_source": assembly.parse_report.chain_id_source,
            "request": request,
            "request_fingerprint_sha256": request_fingerprint,
            "rows": [primary],
            "components": {name: str(path) for name, path in final_paths.items()},
            "artifacts": final_artifacts,
            "provenance": provenance,
        }
        manifest_name = f"{prediction_id}.manifest.json"
        manifest_path = final_directory / manifest_name

        publish_directory = Path(tempfile.mkdtemp(
            prefix=f".{prediction_id}.publish-", dir=output_root
        ))
        shutil.copytree(work_directory, publish_directory, dirs_exist_ok=True)
        (publish_directory / manifest_name).write_text(
            json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8",
        )
        completion = {
            "schema_version": "amyloid-structural-pipeline-completion-1.1",
            "prediction_id": prediction_id,
            "manifest_path": str(manifest_path),
            "completed_at_utc": ended.isoformat(),
            "component_schemas": schemas,
            "normalized_assembly_sha256": identity["normalized_assembly_sha256"],
            "request_fingerprint_sha256": request_fingerprint,
        }
        (publish_directory / "COMPLETED.json").write_text(
            json.dumps(completion, indent=2, sort_keys=True) + "\n", encoding="utf-8",
        )
        os.replace(publish_directory, final_directory)
        publish_directory = None
        published = inspect_pipeline_state(
            final_directory,
            expected_request_fingerprint_sha256=request_fingerprint,
        )
        if published["status"] != "complete":
            raise RuntimeError(f"Published result failed validation: {published}")
        manifest.update({
            "manifest_path": str(manifest_path),
            "publication_state": "complete",
            "reused": False,
        })
        return manifest
    finally:
        shutil.rmtree(work_directory, ignore_errors=True)
        if publish_directory is not None:
            shutil.rmtree(publish_directory, ignore_errors=True)


def main(argv: list[str] | None = None) -> int:
    import argparse

    supplied_argv = list(sys.argv[1:] if argv is None else argv)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--structure", required=True)
    parser.add_argument("--prediction-id", required=True)
    parser.add_argument("--output-directory", required=True)
    parser.add_argument("--model-index", type=int, default=0)
    parser.add_argument("--chain-id-source", choices=("auto", "author", "label"), default="auto")
    parser.add_argument("--layers")
    parser.add_argument("--energy-mode", choices=("sawaya_compat", "freesasa_interchain"), default="sawaya_compat")
    parser.add_argument("--threads", type=int, default=int(os.environ.get("SLURM_CPUS_PER_TASK", "1")))
    parser.add_argument("--unsupported-residue-policy", choices=("error", "skip"), default="error")
    args = parser.parse_args(supplied_argv)
    if args.threads < 1:
        parser.error("--threads must be positive")
    manifest = run_structural_pipeline(
        args.structure, args.output_directory,
        prediction_id=args.prediction_id,
        model_index=args.model_index,
        chain_id_source=args.chain_id_source,
        explicit_layer_map=args.layers,
        energy_mode=args.energy_mode,
        threads=args.threads,
        unsupported_residue_policy=args.unsupported_residue_policy,
        command=["amyloid-structural-pipeline", *supplied_argv],
    )
    print(manifest["manifest_path"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
