"""Typed records for interface burial and packing calculations."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal


SCHEMA_VERSION = "amyloid-interface-dryness-1.1"


@dataclass(slots=True)
class PackingConfig:
    probe_radius: float = 1.4
    freesasa_algorithm: Literal["shrake_rupley", "lee_richards"] = "lee_richards"
    sphere_points: int = 1000
    lee_richards_slices: int = 20
    threads: int = 1
    burial_tolerance: float = 0.1
    deeply_buried_sasa: float = 10.0
    ion_pair_sasa: float = 50.0
    clash_overlap: float = 0.4
    lateral_candidate_distance: float = 8.0
    bsa_per_residue_scale: float = 50.0
    generate_virtual_caps: bool = True
    packing_support_policy: Literal["sasa_only", "sasa_and_zipper"] = "sasa_only"


@dataclass(frozen=True, slots=True)
class InterfaceDefinition:
    partner_a: str
    partner_b: str
    interface_type: Literal["axial", "lateral", "other"] = "other"
    observed_or_virtual: Literal["observed", "virtual"] = "observed"
    family_id: str = "other"
    mapped_residue_count: int | None = None
    terminal_cap: bool = False
    registration_orientation: Literal["same", "reversed"] | None = None
    registration_offset: int | None = None
    registration_support: float | None = None
    registration_ambiguous: bool = False

    @property
    def id(self) -> str:
        return f"{self.partner_a}--{self.partner_b}"


@dataclass(frozen=True, slots=True)
class AtomBurial:
    interface_id: str
    partner_id: str
    atom_key: str
    chain_id: str
    residue_number: int
    insertion_code: str
    residue_name: str
    atom_name: str
    element: str
    chemical_class: str
    backbone_or_sidechain: str
    sasa_isolated: float
    sasa_complex: float
    delta_sasa: float
    is_interface: bool


@dataclass(slots=True)
class InterfaceSASA:
    interface_id: str
    partner_a: str
    partner_b: str
    sasa_a: float
    sasa_b: float
    sasa_ab: float
    delta_sasa_total: float
    bsa_half: float
    fraction_sasa_buried: float
    bsa_per_interface_residue: float | None
    bsa_per_aligned_residue: float | None
    interface_residue_count: int
    mapped_residue_count: int | None
    atom_burial: list[AtomBurial]


@dataclass(frozen=True, slots=True)
class PolarAtomResult:
    interface_id: str
    atom_key: str
    chain_id: str
    residue_number: int
    insertion_code: str
    residue_name: str
    atom_name: str
    delta_sasa: float
    sasa_complex: float
    deeply_buried: bool
    backbone_hbond: bool
    sidechain_hbond: bool
    ion_pair: bool
    solvent_exposed_despite_burial: bool
    satisfied: bool


@dataclass(slots=True)
class PolarSatisfaction:
    interface_polar_atom_count: int
    deeply_buried_polar_atom_count: int
    deeply_buried_satisfied_polar_count: int
    deeply_buried_unsatisfied_polar_count: int
    buried_polar_atom_count: int
    buried_satisfied_polar_count: int
    buried_unsatisfied_polar_count: int
    buried_unsatisfied_polar_per_residue: float
    polar_satisfaction_fraction: float | None
    deep_polar_satisfaction_fraction: float | None
    interaction_backend: str
    atoms: list[PolarAtomResult]


@dataclass(frozen=True, slots=True)
class Clash:
    atom_a: str
    atom_b: str
    distance: float
    allowed_distance: float
    overlap: float


@dataclass(slots=True)
class ClashResult:
    severe_clash_count: int
    severe_clashes_per_interface_residue: float
    maximum_overlap: float
    definition: str
    clashes: list[Clash]


@dataclass(frozen=True, slots=True)
class OptionalFeature:
    available: bool
    value: float | None
    method: str
    reason: str | None = None


@dataclass(slots=True)
class InterfacePackingResult:
    definition: InterfaceDefinition
    sasa: InterfaceSASA
    polar: PolarSatisfaction
    clashes: ClashResult
    shape_complementarity: OptionalFeature
    gap_penalty: OptionalFeature
    residue_burial: list[dict[str, Any]]
    features: dict[str, float | None]
    d_sasa_score: float
    d_zipper_score: float | None
    dry_packing_score: float | None
    warnings: list[str] = field(default_factory=list)


@dataclass(slots=True)
class PackingResult:
    metadata: dict[str, Any]
    interfaces: list[InterfacePackingResult]
    repetition: list[dict[str, Any]]
    warnings: list[str] = field(default_factory=list)
