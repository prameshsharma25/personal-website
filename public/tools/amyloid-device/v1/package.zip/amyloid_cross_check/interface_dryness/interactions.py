"""Shared energetic interaction profile and independent clash calculation."""

from __future__ import annotations

import math
from collections import defaultdict

from .model import (
    Clash,
    ClashResult,
    PackingConfig,
    PolarAtomResult,
    PolarSatisfaction,
)


VDW_RADII = {
    "H": 1.20,
    "C": 1.70,
    "N": 1.55,
    "O": 1.52,
    "F": 1.47,
    "P": 1.80,
    "S": 1.80,
    "CL": 1.75,
    "BR": 1.85,
    "I": 1.98,
}
POSITIVE = {"ARG": {"NE", "NH1", "NH2"}, "LYS": {"NZ"}, "HIS": {"ND1", "NE2"}}
NEGATIVE = {"ASP": {"OD1", "OD2"}, "GLU": {"OE1", "OE2"}}
BACKBONE = frozenset({"N", "CA", "C", "O", "OXT"})


def _distance(a, b) -> float:
    return math.dist(a.coord, b.coord)


def _as_energy_atoms(atoms):
    from amyloid_cross_check.energetics.model import Atom

    converted = []
    for fallback_serial, atom in enumerate(atoms, 1):
        try:
            serial = int(atom.source_serial)
        except (TypeError, ValueError):
            serial = fallback_serial
        converted.append(
            Atom(
                serial,
                atom.name,
                atom.key.residue_name,
                atom.key.chain_id,
                atom.key.residue_number,
                atom.key.insertion_code,
                *atom.coord,
                atom.element,
                atom.record_type,
            )
        )
    return converted


def _shared_interactions(atoms, sasa_by_key, config: PackingConfig):
    """Use the implemented Sawaya interaction engine without reparsing."""
    from amyloid_cross_check.energetics.chemistry import detect_energy_interactions
    from amyloid_cross_check.energetics.model import EnergyConfig, SASAStateSet

    energy_atoms = _as_energy_atoms(atoms)
    assembly_sasa = [sasa_by_key[atom.key] for atom in atoms]
    states = SASAStateSet(assembly_sasa[:], assembly_sasa[:], assembly_sasa[:])
    interactions = detect_energy_interactions(energy_atoms, states, EnergyConfig())
    return (
        interactions.hbond_counts,
        [bool(ids) for ids in interactions.ion_pair_ids],
        "energetics:sawaya_7.2u",
    )


def _angle_at_acceptor(acceptor, donor, by_residue) -> float | None:
    carbon = by_residue.get(
        (
            acceptor.key.chain_id,
            acceptor.key.residue_number,
            acceptor.key.insertion_code,
        ),
        {},
    ).get("C")
    if carbon is None:
        return None
    v1 = tuple(c - o for c, o in zip(carbon.coord, acceptor.coord))
    v2 = tuple(n - o for n, o in zip(donor.coord, acceptor.coord))
    norm1, norm2 = math.sqrt(sum(v * v for v in v1)), math.sqrt(sum(v * v for v in v2))
    if not norm1 or not norm2:
        return None
    cosine = max(-1.0, min(1.0, sum(a * b for a, b in zip(v1, v2)) / (norm1 * norm2)))
    return math.degrees(math.acos(cosine))


def _fallback_interactions(atoms, sasa_by_key, config: PackingConfig):
    counts, ion = [0] * len(atoms), [False] * len(atoms)
    by_residue = defaultdict(dict)
    for atom in atoms:
        by_residue[
            (atom.key.chain_id, atom.key.residue_number, atom.key.insertion_code)
        ][atom.name] = atom
    donor_oxygen = {"OG", "OG1", "OH"}
    for i, acceptor in enumerate(atoms):
        if acceptor.element.upper() != "O":
            continue
        for j, donor in enumerate(atoms):
            if i == j or (
                acceptor.key.chain_id,
                acceptor.key.residue_number,
                acceptor.key.insertion_code,
            ) == (
                donor.key.chain_id,
                donor.key.residue_number,
                donor.key.insertion_code,
            ):
                continue
            if donor.element.upper() != "N" and donor.name not in donor_oxygen:
                continue
            distance = _distance(acceptor, donor)
            if not 2.3 <= distance < 3.3:
                continue
            if acceptor.name == "O" and donor.name == "N":
                angle = _angle_at_acceptor(acceptor, donor, by_residue)
                if angle is None or angle < 110.0:
                    continue
            counts[i] += 1
            counts[j] += 1
    for i, atom_a in enumerate(atoms):
        positive_a = atom_a.name in POSITIVE.get(atom_a.key.residue_name, set())
        negative_a = atom_a.name in NEGATIVE.get(atom_a.key.residue_name, set())
        if (
            not (positive_a or negative_a)
            or sasa_by_key[atom_a.key] >= config.ion_pair_sasa
        ):
            continue
        for j in range(i + 1, len(atoms)):
            atom_b = atoms[j]
            complementary = (
                positive_a
                and atom_b.name in NEGATIVE.get(atom_b.key.residue_name, set())
            ) or (
                negative_a
                and atom_b.name in POSITIVE.get(atom_b.key.residue_name, set())
            )
            if (
                complementary
                and sasa_by_key[atom_b.key] < config.ion_pair_sasa
                and _distance(atom_a, atom_b) <= 4.5
            ):
                ion[i] = ion[j] = True
    return counts, ion, "internal_sawaya_profile_fallback"


def find_polar_satisfaction(
    partner_a,
    partner_b,
    burial,
    interactions=None,
    config: PackingConfig | None = None,
) -> PolarSatisfaction:
    config = config or PackingConfig()
    atoms = list(partner_a.atoms) + list(partner_b.atoms)
    sasa_by_text = {row.atom_key: row.sasa_complex for row in burial.atom_burial}
    sasa_by_key = {atom.key: sasa_by_text[atom.key.text()] for atom in atoms}
    if interactions is not None:
        counts, ion_pairs, backend = interactions
    else:
        try:
            counts, ion_pairs, backend = _shared_interactions(
                atoms, sasa_by_key, config
            )
        except ImportError:
            counts, ion_pairs, backend = _fallback_interactions(
                atoms, sasa_by_key, config
            )
    atom_index = {atom.key.text(): index for index, atom in enumerate(atoms)}
    polar_rows = []
    for row in burial.atom_burial:
        if not row.is_interface or row.element.upper() not in {"N", "O"}:
            continue
        index = atom_index[row.atom_key]
        hbonded = counts[index] > 0
        deeply_buried = row.sasa_complex <= config.deeply_buried_sasa
        ion_pair = ion_pairs[index]
        polar_rows.append(
            PolarAtomResult(
                row.interface_id,
                row.atom_key,
                row.chain_id,
                row.residue_number,
                row.insertion_code,
                row.residue_name,
                row.atom_name,
                row.delta_sasa,
                row.sasa_complex,
                deeply_buried,
                hbonded and row.backbone_or_sidechain == "backbone",
                hbonded and row.backbone_or_sidechain == "sidechain",
                ion_pair,
                not deeply_buried,
                hbonded or ion_pair,
            )
        )
    deeply_buried = [item for item in polar_rows if item.deeply_buried]
    satisfied = sum(item.satisfied for item in deeply_buried)
    unsatisfied = sum(not item.satisfied for item in deeply_buried)
    residue_count = max(1, burial.interface_residue_count)
    return PolarSatisfaction(
        interface_polar_atom_count=len(polar_rows),
        deeply_buried_polar_atom_count=len(deeply_buried),
        deeply_buried_satisfied_polar_count=satisfied,
        deeply_buried_unsatisfied_polar_count=unsatisfied,
        # Preserve the historical all-interface-polar fields while exposing
        # unambiguous deep-burial counts and denominator separately.
        buried_polar_atom_count=len(polar_rows),
        buried_satisfied_polar_count=sum(item.satisfied for item in polar_rows),
        buried_unsatisfied_polar_count=unsatisfied,
        buried_unsatisfied_polar_per_residue=unsatisfied / residue_count,
        polar_satisfaction_fraction=(
            sum(item.satisfied for item in polar_rows) / len(polar_rows)
            if polar_rows else None
        ),
        deep_polar_satisfaction_fraction=(
            satisfied / len(deeply_buried) if deeply_buried else None
        ),
        interaction_backend=backend,
        atoms=polar_rows,
    )


def count_interface_clashes(
    partner_a,
    partner_b,
    config: PackingConfig | None = None,
    *,
    interface_residue_count: int | None = None,
) -> ClashResult:
    config = config or PackingConfig()
    clashes = []
    for atom_a in partner_a.atoms:
        radius_a = VDW_RADII.get(atom_a.element.upper(), 1.70)
        for atom_b in partner_b.atoms:
            radius_b = VDW_RADII.get(atom_b.element.upper(), 1.70)
            distance = _distance(atom_a, atom_b)
            allowed = radius_a + radius_b
            overlap = allowed - distance
            if overlap >= config.clash_overlap:
                clashes.append(
                    Clash(
                        atom_a.key.text(),
                        atom_b.key.text(),
                        distance,
                        allowed,
                        overlap,
                    )
                )
    denominator = max(1, interface_residue_count or 0)
    return ClashResult(
        len(clashes),
        len(clashes) / denominator,
        max((item.overlap for item in clashes), default=0.0),
        f"interpartner_vdw_overlap>={config.clash_overlap:g}A; element-specific Bondi-style radii",
        clashes,
    )
