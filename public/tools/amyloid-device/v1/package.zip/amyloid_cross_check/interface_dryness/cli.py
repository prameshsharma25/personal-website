"""Command-line interface for pair-specific interface packing analysis."""

from __future__ import annotations

import argparse
import os
import sys

import freesasa

from .model import InterfaceDefinition, PackingConfig
from .output import write_outputs
from .pipeline import score_packing


def _interface(value: str) -> InterfaceDefinition:
    fields = [field.strip() for field in value.split(",")]
    if len(fields) not in {3, 4} or fields[2] not in {"axial", "lateral", "other"}:
        raise argparse.ArgumentTypeError(
            "interface must be CHAIN_A,CHAIN_B,axial|lateral|other[,FAMILY]"
        )
    if not fields[0] or not fields[1] or fields[0] == fields[1]:
        raise argparse.ArgumentTypeError(
            "interface partners must be two distinct non-empty chain IDs"
        )
    family = fields[3] if len(fields) == 4 and fields[3] else f"{fields[2]}:explicit"
    return InterfaceDefinition(fields[0], fields[1], fields[2], "observed", family)


def _default_threads() -> int:
    try:
        return max(1, int(os.environ.get("SLURM_CPUS_PER_TASK", "1")))
    except ValueError:
        return 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--structure", required=True, help="normalized input PDB, CIF, or mmCIF"
    )
    parser.add_argument("--layers", help="common/geometry layer JSON")
    parser.add_argument(
        "--interface",
        action="append",
        type=_interface,
        default=[],
        help="explicit CHAIN_A,CHAIN_B,TYPE[,FAMILY]; repeat for multiple interfaces",
    )
    parser.add_argument(
        "--output", required=True, help="output prefix or .packing.json path"
    )
    parser.add_argument("--model-index", type=int, default=0)
    parser.add_argument(
        "--chain-id-source", choices=("auto", "author", "label"), default="auto"
    )
    parser.add_argument(
        "--algorithm", choices=("shrake_rupley", "lee_richards"), default="lee_richards"
    )
    parser.add_argument("--probe-radius", type=float, default=1.4)
    parser.add_argument("--sphere-points", type=int, default=1000)
    parser.add_argument("--slices", type=int, default=20)
    parser.add_argument("--threads", type=int, default=_default_threads())
    parser.add_argument("--burial-tolerance", type=float, default=0.1)
    parser.add_argument("--deeply-buried-sasa", type=float, default=10.0)
    parser.add_argument("--clash-overlap", type=float, default=0.4)
    parser.add_argument("--no-virtual-caps", action="store_true")
    parser.add_argument("--verbose-freesasa", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.threads < 1 or args.sphere_points < 1 or args.slices < 1:
        parser.error("--threads, --sphere-points, and --slices must be positive")
    if args.probe_radius <= 0 or args.burial_tolerance < 0 or args.clash_overlap < 0:
        parser.error("probe radius must be positive and tolerances must be nonnegative")
    try:
        from amyloid_cross_check.common import (
            load_assembly,
            read_explicit_layer_assignments,
        )
    except ImportError as error:
        parser.error(
            "the common package is required; install ../common in the same environment "
            f"({error})"
        )
    assembly = load_assembly(
        args.structure, args.model_index, chain_id_source=args.chain_id_source
    )
    layers = (
        read_explicit_layer_assignments(args.layers, set(assembly.chains))
        if args.layers
        else None
    )
    config = PackingConfig(
        probe_radius=args.probe_radius,
        freesasa_algorithm=args.algorithm,
        sphere_points=args.sphere_points,
        lee_richards_slices=args.slices,
        threads=args.threads,
        burial_tolerance=args.burial_tolerance,
        deeply_buried_sasa=args.deeply_buried_sasa,
        clash_overlap=args.clash_overlap,
        generate_virtual_caps=not args.no_virtual_caps,
    )
    previous_verbosity = freesasa.getVerbosity()
    if not args.verbose_freesasa:
        freesasa.setVerbosity(freesasa.nowarnings)
    try:
        result = score_packing(
            assembly,
            args.interface or None,
            config,
            layers=layers,
            command=[
                "amyloid-interface-dryness",
                *(argv if argv is not None else sys.argv[1:]),
            ],
        )
        paths = write_outputs(result, args.output)
    finally:
        freesasa.setVerbosity(previous_verbosity)
    for path in paths:
        print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
