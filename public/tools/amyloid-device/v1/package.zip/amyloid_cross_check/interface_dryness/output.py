"""Versioned JSON and tidy CSV output for packing results."""

from __future__ import annotations

import csv
import json
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np

from .model import PackingResult


def _serialized(value: Any) -> Any:
    if is_dataclass(value):
        return _serialized(asdict(value))
    if isinstance(value, float):
        return round(value, 6) if np.isfinite(value) else None
    if isinstance(value, np.generic):
        return _serialized(value.item())
    if isinstance(value, dict):
        return {str(key): _serialized(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_serialized(item) for item in value]
    return value


def _write_csv(path: Path, rows: Iterable[dict[str, Any]], fields: list[str]) -> None:
    materialized = [_serialized(row) for row in rows]
    if materialized:
        fieldnames = []
        for row in materialized:
            for key in row:
                if key not in fieldnames:
                    fieldnames.append(key)
    else:
        fieldnames = fields
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(materialized)


def write_outputs(result: PackingResult, output: str | Path) -> list[Path]:
    target = Path(output)
    if target.suffix.lower() == ".json":
        prefix = target.with_suffix("")
        if prefix.name.endswith(".packing"):
            prefix = prefix.with_name(prefix.name[:-8])
        json_path = target
    else:
        prefix = target
        json_path = Path(str(prefix) + ".packing.json")
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(
        json.dumps(_serialized(result), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    interface_rows, atom_rows, residue_rows, polar_rows = [], [], [], []
    for item in result.interfaces:
        definition, sasa, polar, clashes = (
            item.definition,
            item.sasa,
            item.polar,
            item.clashes,
        )
        interface_rows.append(
            {
                "interface_id": definition.id,
                "partner_a": definition.partner_a,
                "partner_b": definition.partner_b,
                "interface_type": definition.interface_type,
                "observed_or_virtual": definition.observed_or_virtual,
                "family_id": definition.family_id,
                "terminal_cap": definition.terminal_cap,
                "calculation_convention": "delta_sasa_total=SASA_A+SASA_B-SASA_AB; bsa_half=delta_sasa_total/2",
                "interaction_backend": polar.interaction_backend,
                "coverage_warnings": "; ".join(
                    warning.removeprefix("coverage: ")
                    for warning in item.warnings
                    if warning.startswith("coverage: ")
                ),
                "warnings": "; ".join(item.warnings),
                "sasa_a_A2": sasa.sasa_a,
                "sasa_b_A2": sasa.sasa_b,
                "sasa_ab_A2": sasa.sasa_ab,
                "delta_sasa_total_A2": sasa.delta_sasa_total,
                "bsa_half_A2": sasa.bsa_half,
                "fraction_sasa_buried": sasa.fraction_sasa_buried,
                "interface_residue_count": sasa.interface_residue_count,
                "mapped_residue_count": sasa.mapped_residue_count,
                "bsa_half_per_total_interface_residue_A2": sasa.bsa_per_interface_residue,
                "bsa_per_interface_residue_A2": sasa.bsa_per_interface_residue,
                "bsa_per_aligned_residue_A2": sasa.bsa_per_aligned_residue,
                "buried_polar_atom_count": polar.buried_polar_atom_count,
                "interface_polar_atom_count": polar.interface_polar_atom_count,
                "deeply_buried_polar_atom_count": polar.deeply_buried_polar_atom_count,
                "deeply_buried_satisfied_polar_count": polar.deeply_buried_satisfied_polar_count,
                "deeply_buried_unsatisfied_polar_count": polar.deeply_buried_unsatisfied_polar_count,
                "buried_satisfied_polar_count": polar.buried_satisfied_polar_count,
                "buried_unsatisfied_polar_count": polar.buried_unsatisfied_polar_count,
                "buried_unsatisfied_polar_per_residue": polar.buried_unsatisfied_polar_per_residue,
                "polar_satisfaction_fraction": polar.polar_satisfaction_fraction,
                "deep_polar_satisfaction_fraction": polar.deep_polar_satisfaction_fraction,
                "severe_clash_count": clashes.severe_clash_count,
                "severe_clashes_per_interface_residue": clashes.severe_clashes_per_interface_residue,
                "shape_complementarity": item.shape_complementarity.value,
                "shape_complementarity_available": item.shape_complementarity.available,
                "gap_penalty": item.gap_penalty.value,
                "gap_penalty_available": item.gap_penalty.available,
                **item.features,
                "D_sasa": item.d_sasa_score,
                "D_zipper": item.d_zipper_score,
                "D_packing": item.dry_packing_score,
            }
        )
        atom_rows.extend(asdict(row) for row in sasa.atom_burial)
        residue_rows.extend(item.residue_burial)
        polar_rows.extend(asdict(row) for row in polar.atoms)
    paths = [json_path]
    tables = (
        (
            ".interface_sasa.csv",
            interface_rows,
            ["interface_id", "partner_a", "partner_b"],
        ),
        (".atom_burial.csv", atom_rows, ["interface_id", "atom_key", "delta_sasa"]),
        (
            ".residue_burial.csv",
            residue_rows,
            ["interface_id", "chain_id", "residue_number"],
        ),
        (
            ".polar_satisfaction.csv",
            polar_rows,
            ["interface_id", "atom_key", "satisfied"],
        ),
    )
    for suffix, rows, fields in tables:
        path = Path(str(prefix) + suffix)
        _write_csv(path, rows, fields)
        paths.append(path)
    return paths
