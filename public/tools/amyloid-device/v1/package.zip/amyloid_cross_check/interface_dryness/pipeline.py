"""End-to-end packing pipeline built on common records and geometry layers."""

from __future__ import annotations

import hashlib
import math
import platform
from collections import defaultdict
from dataclasses import asdict
from pathlib import Path
from statistics import median
from typing import Iterable, Sequence

import numpy as np

from .interactions import count_interface_clashes, find_polar_satisfaction
from .model import (
    InterfaceDefinition,
    InterfacePackingResult,
    OptionalFeature,
    PackingConfig,
    PackingResult,
    SCHEMA_VERSION,
)
from .sasa import calculate_interface_sasa, freesasa_metadata


def _sha256(path: str | Path | None) -> str | None:
    if path is None:
        return None
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _minimum_distance(chain_a, chain_b) -> float:
    if not chain_a.atoms or not chain_b.atoms:
        return float("inf")
    coordinates_b = np.asarray([atom.coord for atom in chain_b.atoms], dtype=float)
    return min(
        float(np.min(np.linalg.norm(coordinates_b - np.asarray(atom.coord), axis=1)))
        for atom in chain_a.atoms
    )


def _mapped_count(chain_a, chain_b) -> int | None:
    try:
        from amyloid_cross_check.common import map_equivalent_residues

        return len(map_equivalent_residues(chain_a, chain_b).pairs)
    except (ImportError, ValueError):
        return min(len(chain_a.residues), len(chain_b.residues)) or None


def interfaces_from_layers(
    assembly, layers, config: PackingConfig | None = None
) -> list[InterfaceDefinition]:
    """Build axial neighbors and contacting same-rung lateral neighbors."""
    config = config or PackingConfig()
    definitions: list[InterfaceDefinition] = []
    by_protofilament = defaultdict(list)
    for layer in layers:
        if (
            layer.chain_id in assembly.chains
            and layer.observed_or_virtual == "observed"
        ):
            by_protofilament[layer.protofilament_id].append(layer)
    for protofilament, assignments in sorted(by_protofilament.items()):
        ordered = sorted(
            assignments, key=lambda item: (item.layer_index, item.chain_id)
        )
        for first, second in zip(ordered, ordered[1:]):
            if abs(second.layer_index - first.layer_index) != 1:
                continue
            chain_a, chain_b = (
                assembly.chains[first.chain_id],
                assembly.chains[second.chain_id],
            )
            definitions.append(
                InterfaceDefinition(
                    first.chain_id,
                    second.chain_id,
                    "axial",
                    "observed",
                    f"axial:{protofilament}",
                    _mapped_count(chain_a, chain_b),
                    False,
                )
            )
    protofilaments = sorted(by_protofilament)
    for position, pf_a in enumerate(protofilaments):
        layers_a = {item.layer_index: item for item in by_protofilament[pf_a]}
        for pf_b in protofilaments[position + 1 :]:
            layers_b = {item.layer_index: item for item in by_protofilament[pf_b]}
            candidates = []
            for orientation in (1, -1):
                offsets = {
                    index_a - orientation * index_b
                    for index_a in layers_a for index_b in layers_b
                }
                for offset in offsets:
                    matched = [
                        (index_a, index_b)
                        for index_b in layers_b
                        if (index_a := orientation * index_b + offset) in layers_a
                    ]
                    distances = [
                        _minimum_distance(
                            assembly.chains[layers_a[index_a].chain_id],
                            assembly.chains[layers_b[index_b].chain_id],
                        )
                        for index_a, index_b in matched
                    ]
                    contact_count = sum(
                        distance <= config.lateral_candidate_distance
                        for distance in distances
                    )
                    support = sum(
                        max(0.0, config.lateral_candidate_distance - distance)
                        for distance in distances
                    )
                    candidates.append((contact_count, support, len(matched), orientation, offset, matched))
            if not candidates:
                continue
            best_key = max((item[0], item[1], item[2]) for item in candidates)
            best = [item for item in candidates if (item[0], item[1], item[2]) == best_key]
            # Prefer the smallest offset only as a deterministic presentation
            # choice; retain the ambiguity flag whenever evidence ties.
            chosen = min(best, key=lambda item: (abs(item[4]), -item[3], item[4]))
            contact_count, support, _overlap, orientation, offset, matched = chosen
            if contact_count == 0:
                continue
            ambiguous = len(best) > 1
            for index_a, index_b in sorted(matched):
                item_a, item_b = layers_a[index_a], layers_b[index_b]
                chain_a, chain_b = (
                    assembly.chains[item_a.chain_id],
                    assembly.chains[item_b.chain_id],
                )
                if (
                    _minimum_distance(chain_a, chain_b)
                    <= config.lateral_candidate_distance
                ):
                    definitions.append(
                        InterfaceDefinition(
                            item_a.chain_id,
                            item_b.chain_id,
                            "lateral",
                            "observed",
                            f"lateral:{pf_a}:{pf_b}",
                            _mapped_count(chain_a, chain_b),
                            False,
                            "same" if orientation == 1 else "reversed",
                            offset,
                            support,
                            ambiguous,
                        )
                    )
    return definitions


def _transformed_chain(chain, transform, chain_id: str):
    from amyloid_cross_check.common.model import (
        AtomKey,
        AtomRecord,
        ChainRecord,
        ResidueID,
        ResidueRecord,
    )

    residues = []
    for residue in chain.residues:
        coordinates = np.asarray(
            [atom.coord for atom in residue.atoms.values()], dtype=float
        )
        transformed = transform.apply(coordinates)
        atoms = {}
        for (name, atom), coordinate in zip(residue.atoms.items(), transformed):
            key = AtomKey(
                atom.key.model_id,
                chain_id,
                atom.key.residue_number,
                atom.key.insertion_code,
                atom.key.residue_name,
                atom.key.atom_name,
                atom.key.alternate_location,
            )
            atoms[name] = AtomRecord(
                key,
                tuple(float(value) for value in coordinate),
                atom.element,
                atom.occupancy,
                atom.b_factor,
                atom.record_type,
                f"virtual:{atom.source_serial}",
            )
        residue_id = ResidueID(
            residue.id.model_id,
            chain_id,
            residue.id.residue_number,
            residue.id.insertion_code,
            residue.id.residue_name,
        )
        residues.append(
            ResidueRecord(
                residue_id,
                residue.original_name,
                residue.normalized_name,
                residue.one_letter,
                atoms,
                residue.sequence_index,
                residue.record_type,
            )
        )
    return ChainRecord(chain_id, residues)


def generate_virtual_cap_interfaces(
    assembly, layers
) -> tuple[dict[str, object], list[InterfaceDefinition], list[str]]:
    """Extend both ends of each observed protofilament by its terminal transform."""
    try:
        from amyloid_cross_check.common import (
            fit_pair_transform,
            map_equivalent_residues,
        )
    except ImportError:
        return {}, [], ["Virtual caps require the amyloid-cross-check-common package"]
    by_protofilament = defaultdict(list)
    for item in layers:
        if item.chain_id in assembly.chains and item.observed_or_virtual == "observed":
            by_protofilament[item.protofilament_id].append(item)
    virtual, definitions, warnings = {}, [], []
    for protofilament, assignments in sorted(by_protofilament.items()):
        ordered = sorted(
            assignments, key=lambda item: (item.layer_index, item.chain_id)
        )
        if len(ordered) < 2:
            warnings.append(
                f"Cannot generate virtual caps for {protofilament}: fewer than two observed layers"
            )
            continue
        first, second = (assembly.chains[item.chain_id] for item in ordered[:2])
        penultimate, last = (assembly.chains[item.chain_id] for item in ordered[-2:])
        try:
            start_transform = fit_pair_transform(
                first, second, map_equivalent_residues(first, second)
            ).inverse()
            end_transform = fit_pair_transform(
                penultimate, last, map_equivalent_residues(penultimate, last)
            )
        except ValueError as error:
            warnings.append(
                f"Cannot generate virtual caps for {protofilament}: {error}"
            )
            continue
        before_id = f"virtual:{protofilament}:before"
        after_id = f"virtual:{protofilament}:after"
        virtual[before_id] = _transformed_chain(first, start_transform, before_id)
        virtual[after_id] = _transformed_chain(last, end_transform, after_id)
        definitions.extend(
            (
                InterfaceDefinition(
                    before_id,
                    first.id,
                    "axial",
                    "virtual",
                    f"axial:{protofilament}",
                    _mapped_count(virtual[before_id], first),
                    True,
                ),
                InterfaceDefinition(
                    last.id,
                    after_id,
                    "axial",
                    "virtual",
                    f"axial:{protofilament}",
                    _mapped_count(last, virtual[after_id]),
                    True,
                ),
            )
        )
    return virtual, definitions, warnings


def calculate_shape_complementarity(
    partner_a, partner_b, config=None
) -> OptionalFeature:
    del partner_a, partner_b, config
    return OptionalFeature(
        False,
        None,
        "unavailable",
        "No validated Lawrence-Colman Sc backend is configured; no surrogate value was emitted",
    )


def calculate_gap_penalty(partner_a, partner_b, config=None) -> OptionalFeature:
    del partner_a, partner_b, config
    return OptionalFeature(
        False,
        None,
        "unavailable",
        "No validated cavity/solvent-channel backend is configured; no surrogate value was emitted",
    )


def _residue_burial(sasa) -> list[dict]:
    groups = defaultdict(list)
    for atom in sasa.atom_burial:
        groups[
            (atom.chain_id, atom.residue_number, atom.insertion_code, atom.residue_name)
        ].append(atom)
    rows = []
    for (chain, number, insertion, name), atoms in sorted(groups.items()):
        delta = sum(atom.delta_sasa for atom in atoms)
        rows.append(
            {
                "interface_id": sasa.interface_id,
                "chain_id": chain,
                "residue_number": number,
                "insertion_code": insertion,
                "residue_name": name,
                "delta_sasa_total": delta,
                "delta_sasa_backbone": sum(
                    atom.delta_sasa
                    for atom in atoms
                    if atom.backbone_or_sidechain == "backbone"
                ),
                "delta_sasa_sidechain": sum(
                    atom.delta_sasa
                    for atom in atoms
                    if atom.backbone_or_sidechain == "sidechain"
                ),
                "delta_sasa_nonpolar": sum(
                    atom.delta_sasa
                    for atom in atoms
                    if atom.chemical_class == "nonpolar_carbon"
                ),
                "delta_sasa_polar": sum(
                    atom.delta_sasa
                    for atom in atoms
                    if atom.chemical_class in {"polar", "charged"}
                ),
                "delta_sasa_charged": sum(
                    atom.delta_sasa
                    for atom in atoms
                    if atom.chemical_class == "charged"
                ),
                "is_interface_residue": any(atom.is_interface for atom in atoms),
            }
        )
    return rows


def score_interface(
    partner_a,
    partner_b,
    definition: InterfaceDefinition,
    config: PackingConfig | None = None,
) -> InterfacePackingResult:
    config = config or PackingConfig()
    sasa = calculate_interface_sasa(
        partner_a,
        partner_b,
        config=config,
        interface_id=definition.id,
        mapped_residue_count=definition.mapped_residue_count,
    )
    polar = find_polar_satisfaction(partner_a, partner_b, sasa, config=config)
    clashes = count_interface_clashes(
        partner_a,
        partner_b,
        config,
        interface_residue_count=sasa.interface_residue_count,
    )
    shape = calculate_shape_complementarity(partner_a, partner_b, config)
    gap = calculate_gap_penalty(partner_a, partner_b, config)
    b_norm = min(
        1.0,
        max(
            0.0, (sasa.bsa_per_interface_residue or 0.0) / config.bsa_per_residue_scale
        ),
    )
    u_polar = (
        polar.deeply_buried_unsatisfied_polar_count
        / polar.deeply_buried_polar_atom_count
        if polar.deeply_buried_polar_atom_count
        else 0.0
    )
    c_clash = min(1.0, clashes.severe_clashes_per_interface_residue)
    partner_interface_residues = defaultdict(set)
    for atom in sasa.atom_burial:
        if atom.is_interface:
            partner_interface_residues[atom.partner_id].add(
                (atom.chain_id, atom.residue_number, atom.insertion_code)
            )
    partner_counts = [len(values) for values in partner_interface_residues.values()]
    features = {
        "B_norm": b_norm,
        "Sc": shape.value,
        "G_gap": gap.value,
        "U_polar": u_polar,
        "C_clash": c_clash,
        "R_pack": None,
        # Preserve the uncapped observables used to derive exploratory scores.
        "deeply_buried_unsatisfied_polar_fraction": u_polar,
        "severe_clashes_per_interface_residue_uncapped": (
            clashes.severe_clashes_per_interface_residue
        ),
        "interface_repeat_consistency": None,
        "delta_sasa_total_per_interface_residue_A2": (
            sasa.delta_sasa_total / sasa.interface_residue_count
            if sasa.interface_residue_count else None
        ),
        "bsa_half_per_mean_partner_interface_residue_A2": (
            sasa.bsa_half / (sum(partner_counts) / len(partner_counts))
            if partner_counts and sum(partner_counts) else None
        ),
        "delta_sasa_backbone_A2": sum(
            atom.delta_sasa
            for atom in sasa.atom_burial
            if atom.backbone_or_sidechain == "backbone"
        ),
        "delta_sasa_sidechain_A2": sum(
            atom.delta_sasa
            for atom in sasa.atom_burial
            if atom.backbone_or_sidechain == "sidechain"
        ),
        "delta_sasa_nonpolar_A2": sum(
            atom.delta_sasa
            for atom in sasa.atom_burial
            if atom.chemical_class == "nonpolar_carbon"
        ),
        "delta_sasa_polar_A2": sum(
            atom.delta_sasa
            for atom in sasa.atom_burial
            if atom.chemical_class in {"polar", "charged"}
        ),
        "delta_sasa_charged_A2": sum(
            atom.delta_sasa
            for atom in sasa.atom_burial
            if atom.chemical_class == "charged"
        ),
        "nonpolar_buried_fraction": (
            sum(
                max(0.0, atom.delta_sasa)
                for atom in sasa.atom_burial
                if atom.chemical_class == "nonpolar_carbon"
            )
            / sasa.delta_sasa_total
            if sasa.delta_sasa_total > 0
            else 0.0
        ),
    }
    nonpolar_fraction = float(features["nonpolar_buried_fraction"] or 0.0)
    d_sasa = (
        math.sqrt(b_norm * max(0.0, nonpolar_fraction))
        * (1.0 - u_polar)
        * (1.0 - c_clash)
    )
    d_zipper = None
    if (
        shape.available
        and gap.available
        and shape.value is not None
        and gap.value is not None
    ):
        d_zipper = math.sqrt(max(0.0, shape.value)) * (1.0 - gap.value)
    dry_score = (
        d_sasa
        if config.packing_support_policy == "sasa_only"
        else d_sasa * d_zipper if d_zipper is not None else None
    )
    features["D_sasa"] = d_sasa
    features["D_zipper"] = d_zipper
    warnings = [feature.reason for feature in (shape, gap) if feature.reason]
    if definition.mapped_residue_count is None:
        warnings.append("coverage: aligned-residue normalization is unavailable")
    if sasa.interface_residue_count == 0:
        warnings.append("coverage: no atoms exceeded the interface burial tolerance")
    if sasa.delta_sasa_total < -1e-5:
        warnings.append("Negative total burial exceeds numerical tolerance")
    return InterfacePackingResult(
        definition,
        sasa,
        polar,
        clashes,
        shape,
        gap,
        _residue_burial(sasa),
        features,
        d_sasa,
        d_zipper,
        dry_score,
        warnings,
    )


def _relative_mad(values: Iterable[float]) -> float | None:
    values = list(values)
    if len(values) < 2:
        return None
    center = median(values)
    scale = max(abs(center), 1e-12)
    return median(abs(value - center) for value in values) / scale


def _repetition(
    results: Sequence[InterfacePackingResult], config: PackingConfig
) -> list[dict]:
    families = defaultdict(list)
    for result in results:
        families[result.definition.family_id].append(result)
    output = []
    for family, members in sorted(families.items()):
        observed = [
            item
            for item in members
            if item.definition.observed_or_virtual == "observed"
        ]
        dispersions = {
            "bsa_relative_mad": _relative_mad(item.sasa.bsa_half for item in observed),
            "nonpolar_fraction_relative_mad": _relative_mad(
                float(item.features["nonpolar_buried_fraction"] or 0.0)
                for item in observed
            ),
            "polar_satisfaction_relative_mad": _relative_mad(
                item.polar.polar_satisfaction_fraction
                for item in observed
                if item.polar.polar_satisfaction_fraction is not None
            ),
            "clash_rate_relative_mad": _relative_mad(
                item.clashes.severe_clashes_per_interface_residue for item in observed
            ),
        }
        available = [value for value in dispersions.values() if value is not None]
        consistency = (
            1.0 / (1.0 + sum(available) / len(available)) if available else None
        )
        for item in members:
            item.features["R_pack"] = consistency
            item.features["interface_repeat_consistency"] = consistency
            if consistency is not None:
                item.d_sasa_score *= consistency
                item.features["D_sasa"] = item.d_sasa_score
                item.dry_packing_score = (
                    item.d_sasa_score
                    if config.packing_support_policy == "sasa_only"
                    else (
                        item.d_sasa_score * item.d_zipper_score
                        if item.d_zipper_score is not None else None
                    )
                )
        observed_bsa = [item.sasa.bsa_half for item in observed]
        reference = median(observed_bsa) if observed_bsa else None
        caps = []
        for item in members:
            if item.definition.terminal_cap:
                ratio = (
                    item.sasa.bsa_half / reference
                    if reference and reference > 0
                    else None
                )
                item.features["cap_bsa_ratio"] = ratio
                caps.append(
                    {
                        "interface_id": item.definition.id,
                        "bsa_ratio_to_internal_median": ratio,
                    }
                )
        output.append(
            {
                "family_id": family,
                "observed_interface_count": len(observed),
                "virtual_interface_count": len(members) - len(observed),
                **dispersions,
                "R_pack": consistency,
                "terminal_caps": caps,
            }
        )
    return output


def score_packing(
    assembly,
    interfaces: Sequence[InterfaceDefinition] | None = None,
    config: PackingConfig | None = None,
    *,
    layers=None,
    command: Sequence[str] | None = None,
    prediction_id: str | None = None,
) -> PackingResult:
    config = config or PackingConfig()
    warnings = list(getattr(assembly, "warnings", []))
    if layers is None and interfaces is None:
        try:
            from amyloid_cross_check.common import analyze_assembly

            common_result = analyze_assembly(assembly)
            layers = common_result.layers
            warnings.append(
                "Interface definitions were inferred by the common layer pipeline"
            )
        except ImportError as error:
            raise ValueError(
                "Provide interfaces or layers when the common pipeline is unavailable"
            ) from error
    definitions = (
        list(interfaces)
        if interfaces is not None
        else interfaces_from_layers(assembly, layers or (), config)
    )
    partners = dict(assembly.chains)
    if config.generate_virtual_caps and layers:
        virtual, cap_definitions, cap_warnings = generate_virtual_cap_interfaces(
            assembly, layers
        )
        partners.update(virtual)
        definitions.extend(cap_definitions)
        warnings.extend(cap_warnings)
    unique = {}
    for definition in definitions:
        pair_key = (
            frozenset((definition.partner_a, definition.partner_b)),
            definition.interface_type,
            definition.observed_or_virtual,
        )
        unique.setdefault(pair_key, definition)
    definitions = sorted(
        unique.values(),
        key=lambda item: (
            item.interface_type,
            item.family_id,
            item.partner_a,
            item.partner_b,
        ),
    )
    if not definitions:
        if not layers:
            no_interface_reason = "absent_layers"
        elif len(getattr(assembly, "chains", {})) < 2:
            no_interface_reason = "single_chain_or_unsupported_topology"
        else:
            no_interface_reason = "absent_qualifying_contacts"
        warnings.append(f"no_selected_interfaces:{no_interface_reason}")
    else:
        no_interface_reason = None
    missing = sorted(
        {
            chain
            for item in definitions
            for chain in (item.partner_a, item.partner_b)
            if chain not in partners
        }
    )
    if missing:
        raise ValueError(
            "Interface definitions contain unknown partners: " + ", ".join(missing)
        )
    results = [
        score_interface(
            partners[item.partner_a], partners[item.partner_b], item, config
        )
        for item in definitions
    ]
    repetition = _repetition(results, config)
    try:
        from amyloid_cross_check.common import (
            atom_identity_sha256, layer_assignment_sha256,
            normalized_assembly_sha256,
        )
        normalized_hash = normalized_assembly_sha256(assembly)
        atom_hash = atom_identity_sha256(assembly)
        layer_hash = layer_assignment_sha256(layers or ())
    except ImportError:  # pragma: no cover - common is a declared dependency
        normalized_hash = atom_hash = layer_hash = None
    parameter_hash = hashlib.sha256(
        repr(sorted(asdict(config).items())).encode("utf-8")
    ).hexdigest()
    metadata = {
        "schema_version": SCHEMA_VERSION,
        "prediction_id": prediction_id,
        "command": list(command) if command is not None else None,
        "input": {
            "path": assembly.source,
            "sha256": _sha256(assembly.source),
            "source_file_sha256": _sha256(assembly.source),
            "normalized_assembly_sha256": normalized_hash,
            "atom_identity_sha256": atom_hash,
            "layer_assignment_sha256": layer_hash,
            "model_index": assembly.model_index,
            "chain_id_source": getattr(assembly.parse_report, "chain_id_source", None),
        },
        "parameters": asdict(config),
        "parameter_hash": parameter_hash,
        "surface": freesasa_metadata(config),
        "software": {"python": platform.python_version(), "numpy": np.__version__},
        "definitions": {
            "bsa": "delta_sasa_total=SASA_A+SASA_B-SASA_AB; bsa_half=delta_sasa_total/2",
            "interface_atom": f"delta_sasa_atom>{config.burial_tolerance:g} A^2",
            "buried_unsatisfied_polar": f"interface N/O with complex SASA<={config.deeply_buried_sasa:g} A^2 and no hydrogen bond or ion pair",
            "dryness_scope": "dry_interface_potential; predicted coordinates do not establish observed water exclusion",
            "score_status": "exploratory; D_sasa uses validated SASA/polar/clash calculations; D_zipper remains unavailable without validated Sc and gap backends",
            "normalization_status": "exploratory; B_norm uses a configurable provisional saturation scale and must be calibrated on development data",
            "packing_support_policy": config.packing_support_policy,
        },
        "interface_selection": {
            "status": "selected" if definitions else "no_selected_interfaces",
            "reason": no_interface_reason,
            "selected_interface_count": len(definitions),
        },
    }
    return PackingResult(metadata, results, repetition, warnings)
