"""Pair-specific FreeSASA calculations over common structure records."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version as package_version
from typing import Iterable, Sequence

import freesasa

from amyloid_cross_check.common import pdb_atom_name

from .model import AtomBurial, InterfaceSASA, PackingConfig


BACKBONE = frozenset({"N", "CA", "C", "O", "OXT"})
POSITIVE = {"ARG": {"NE", "NH1", "NH2"}, "LYS": {"NZ"}, "HIS": {"ND1", "NE2"}}
NEGATIVE = {"ASP": {"OD1", "OD2"}, "GLU": {"OE1", "OE2"}}


def _effective_threads(config: PackingConfig) -> int:
    """Return the portable, validated FreeSASA thread count.

    FreeSASA thread support is a compile-time option. The pinned Biowulf
    Python build rejects more than one thread for both Lee--Richards and
    Shrake--Rupley, so keep either native backend single-threaded and obtain
    dataset-level parallelism from Slurm/Swarm instead.
    """
    if config.threads < 1:
        raise ValueError("FreeSASA thread count must be positive")
    return 1


def _parameters(config: PackingConfig):
    algorithm = (
        freesasa.ShrakeRupley
        if config.freesasa_algorithm == "shrake_rupley"
        else freesasa.LeeRichards
    )
    options = {
        "algorithm": algorithm,
        "probe-radius": config.probe_radius,
        "n-threads": _effective_threads(config),
    }
    if config.freesasa_algorithm == "shrake_rupley":
        options["n-points"] = config.sphere_points
    else:
        options["n-slices"] = config.lee_richards_slices
    return freesasa.Parameters(options)


def freesasa_metadata(config: PackingConfig) -> dict:
    try:
        installed = package_version("freesasa")
    except PackageNotFoundError:  # pragma: no cover - wheel metadata normally exists
        installed = str(getattr(freesasa, "__version__", "unknown"))
    return {
        "engine": "FreeSASA",
        "version": installed,
        "algorithm": config.freesasa_algorithm,
        "probe_radius_A": config.probe_radius,
        "points_per_atom": config.sphere_points
        if config.freesasa_algorithm == "shrake_rupley"
        else None,
        "slices": config.lee_richards_slices
        if config.freesasa_algorithm == "lee_richards"
        else None,
        "classifier": "FreeSASA default classifier/radii",
        "atom_name_policy": "pdb_element_aware_4_column",
        "threads": _effective_threads(config),
        "requested_threads": config.threads,
        "thread_policy": "forced_single_thread_for_build_portability",
    }


def _structure(atom_groups: Sequence[Sequence], labels: Sequence[str]):
    structure = freesasa.Structure()
    flattened = []
    for atoms, label in zip(atom_groups, labels):
        for atom in atoms:
            structure.addAtom(
                pdb_atom_name(atom.name, atom.element),
                atom.key.residue_name,
                f"{atom.key.residue_number}{atom.key.insertion_code}",
                label,
                *atom.coord,
            )
            flattened.append(atom)
    return structure, flattened


def calculate_atom_sasa(atoms: Iterable, config: PackingConfig | None = None) -> dict:
    """Return full-precision atom SASA keyed by the shared immutable AtomKey."""
    config = config or PackingConfig()
    materialized = list(atoms.atoms if hasattr(atoms, "atoms") else atoms)
    structure, ordered = _structure([materialized], ["A"])
    result = freesasa.calc(structure, _parameters(config))
    return {
        atom.key: float(result.atomArea(index)) for index, atom in enumerate(ordered)
    }


def _chemical_class(atom) -> str:
    residue, name, element = atom.key.residue_name, atom.name, atom.element.upper()
    if name in POSITIVE.get(residue, set()) or name in NEGATIVE.get(residue, set()):
        return "charged"
    if element == "C":
        return "nonpolar_carbon"
    if element in {"N", "O"}:
        return "polar"
    if element == "S":
        return "sulfur"
    if element == "P":
        return "phosphorus"
    return f"element_{element.lower() or 'unknown'}"


def calculate_interface_sasa(
    partner_a,
    partner_b,
    complex_ab=None,
    config: PackingConfig | None = None,
    *,
    interface_id: str | None = None,
    mapped_residue_count: int | None = None,
) -> InterfaceSASA:
    """Calculate atom and total burial for one explicitly selected partner pair.

    ``complex_ab`` is accepted for API compatibility. Coordinates are taken from
    the two partners so the isolated and complex atom order is guaranteed to match.
    """
    del complex_ab
    config = config or PackingConfig()
    atoms_a, atoms_b = list(partner_a.atoms), list(partner_b.atoms)
    if not atoms_a or not atoms_b:
        raise ValueError("Both interface partners must contain at least one atom")
    isolated_a = calculate_atom_sasa(atoms_a, config)
    isolated_b = calculate_atom_sasa(atoms_b, config)
    pair_structure, ordered = _structure([atoms_a, atoms_b], ["A", "B"])
    pair_result = freesasa.calc(pair_structure, _parameters(config))
    pair_areas = {
        atom.key: float(pair_result.atomArea(index))
        for index, atom in enumerate(ordered)
    }
    identifier = interface_id or f"{partner_a.id}--{partner_b.id}"
    rows: list[AtomBurial] = []
    interface_residues = set()
    for partner_id, atoms, isolated in (
        (partner_a.id, atoms_a, isolated_a),
        (partner_b.id, atoms_b, isolated_b),
    ):
        for atom in atoms:
            delta = isolated[atom.key] - pair_areas[atom.key]
            is_interface = delta > config.burial_tolerance
            if is_interface:
                interface_residues.add(
                    (
                        atom.key.chain_id,
                        atom.key.residue_number,
                        atom.key.insertion_code,
                    )
                )
            rows.append(
                AtomBurial(
                    identifier,
                    partner_id,
                    atom.key.text(),
                    atom.key.chain_id,
                    atom.key.residue_number,
                    atom.key.insertion_code,
                    atom.key.residue_name,
                    atom.name,
                    atom.element,
                    _chemical_class(atom),
                    "backbone" if atom.name in BACKBONE else "sidechain",
                    isolated[atom.key],
                    pair_areas[atom.key],
                    delta,
                    is_interface,
                )
            )
    sasa_a = sum(isolated_a.values())
    sasa_b = sum(isolated_b.values())
    sasa_ab = sum(pair_areas.values())
    delta_total = sasa_a + sasa_b - sasa_ab
    bsa_half = delta_total / 2.0
    denominator = sasa_a + sasa_b
    residue_count = len(interface_residues)
    return InterfaceSASA(
        identifier,
        partner_a.id,
        partner_b.id,
        sasa_a,
        sasa_b,
        sasa_ab,
        delta_total,
        bsa_half,
        delta_total / denominator if denominator else 0.0,
        bsa_half / residue_count if residue_count else None,
        bsa_half / mapped_residue_count if mapped_residue_count else None,
        residue_count,
        mapped_residue_count,
        rows,
    )


def classify_buried_atoms(
    interface_sasa: InterfaceSASA, chemistry=None
) -> list[AtomBurial]:
    """Return the atom-level burial table (chemistry is already annotated)."""
    del chemistry
    return list(interface_sasa.atom_burial)
