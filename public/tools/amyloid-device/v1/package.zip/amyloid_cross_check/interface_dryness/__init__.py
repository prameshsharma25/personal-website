"""SASA, burial, polar satisfaction, and packing API."""

from .interactions import count_interface_clashes, find_polar_satisfaction
from .model import (
    AtomBurial,
    ClashResult,
    InterfaceDefinition,
    InterfacePackingResult,
    InterfaceSASA,
    PackingConfig,
    PackingResult,
    PolarSatisfaction,
    SCHEMA_VERSION,
)
from .output import write_outputs
from .pipeline import (
    calculate_gap_penalty,
    calculate_shape_complementarity,
    generate_virtual_cap_interfaces,
    interfaces_from_layers,
    score_interface,
    score_packing,
)
from .sasa import calculate_atom_sasa, calculate_interface_sasa, classify_buried_atoms

__all__ = [
    "AtomBurial",
    "ClashResult",
    "InterfaceDefinition",
    "InterfacePackingResult",
    "InterfaceSASA",
    "PackingConfig",
    "PackingResult",
    "PolarSatisfaction",
    "SCHEMA_VERSION",
    "calculate_atom_sasa",
    "calculate_gap_penalty",
    "calculate_interface_sasa",
    "calculate_shape_complementarity",
    "classify_buried_atoms",
    "count_interface_clashes",
    "find_polar_satisfaction",
    "generate_virtual_cap_interfaces",
    "interfaces_from_layers",
    "score_interface",
    "score_packing",
    "write_outputs",
]
