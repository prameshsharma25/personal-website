"""Compatibility module for the documented CLI path."""

from .cli import main
from .pipeline import score_interface, score_packing

__all__ = ["main", "score_interface", "score_packing"]

if __name__ == "__main__":
    raise SystemExit(main())
