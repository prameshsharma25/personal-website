#!/usr/bin/env python3
"""Reference-free geometry scorer for repeated cross-beta assemblies.

The module deliberately keeps the measured features separate from its exploratory
score.  It accepts PDB and mmCIF files, maps equivalent chains by sequence, infers
axial paths without using file/chain order, measures repeated interfaces and
backbone hydrogen-bond ladders, and tests both ends by virtual extension.

Only NumPy and Biopython are required.  PyDSSP is used when available and falls
back to an explicitly versioned hydrogen-bond-based beta assignment otherwise.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import inspect
from io import StringIO
import json
import math
import platform
import sys
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, field, is_dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
from Bio import __version__ as biopython_version
from Bio.PDB import MMCIFParser, PDBParser
from Bio.PDB.MMCIF2Dict import MMCIF2Dict
from Bio.PDB.Polypeptide import is_aa


SCHEMA_VERSION = "amyloid-geometry-1.2"
HBOND_DEFINITION = "backbone_hbond_peptide_plane_v2"
CONTACT_DEFINITION = "residue_contact_cb_or_ca_v1"
BACKBONE_ATOMS = ("N", "CA", "C", "O")
ONE_LETTER = {
    "ALA": "A", "ARG": "R", "ASN": "N", "ASP": "D", "CYS": "C",
    "GLN": "Q", "GLU": "E", "GLY": "G", "HIS": "H", "ILE": "I",
    "LEU": "L", "LYS": "K", "MET": "M", "PHE": "F", "PRO": "P",
    "SER": "S", "THR": "T", "TRP": "W", "TYR": "Y", "VAL": "V",
    "MSE": "M", "SEC": "U", "PYL": "O",
}


class PyDSSPCompatibilityError(RuntimeError):
    """Raised when the installed PyDSSP API cannot preserve chain boundaries."""


class IncompleteBackboneError(ValueError):
    """Raised when PyDSSP input lacks required N/CA/C/O coordinates."""


@dataclass(frozen=True, order=True)
class ResidueID:
    model_id: int
    chain_id: str
    residue_number: int
    insertion_code: str = ""
    residue_name: str = "UNK"

    def text(self) -> str:
        insertion = self.insertion_code.strip()
        return f"{self.chain_id}:{self.residue_number}{insertion}:{self.residue_name}"


@dataclass
class AtomRecord:
    name: str
    element: str
    coord: np.ndarray
    occupancy: float
    alternate_location: str


@dataclass
class ResidueRecord:
    id: ResidueID
    one_letter: str
    atoms: dict[str, AtomRecord]
    sequence_index: int = 0

    def atom(self, name: str) -> np.ndarray | None:
        record = self.atoms.get(name)
        return None if record is None else record.coord

    def contact_coord(self) -> np.ndarray | None:
        return self.atom("CB") if "CB" in self.atoms else self.atom("CA")


@dataclass
class ChainRecord:
    id: str
    residues: list[ResidueRecord]

    @property
    def sequence(self) -> str:
        return "".join(residue.one_letter for residue in self.residues)

    @property
    def centroid(self) -> np.ndarray:
        coords = [atom.coord for residue in self.residues for atom in residue.atoms.values()]
        return np.mean(coords, axis=0) if coords else np.zeros(3)


@dataclass
class Assembly:
    chains: dict[str, ChainRecord]
    source: str | None = None
    model_index: int = 0
    warnings: list[str] = field(default_factory=list)
    identity: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ResidueMapping:
    chain_a: str
    chain_b: str
    pairs: tuple[tuple[int, int], ...]
    identity: float
    coverage_a: float
    coverage_b: float


@dataclass
class PairwiseTransform:
    chain_a: str
    chain_b: str
    rotation: np.ndarray
    translation: np.ndarray
    centroid_displacement: np.ndarray
    rmsd: float
    fitted_atom_count: int
    fitted_residue_count: int
    sequence_identity: float
    sequence_coverage: float
    orientation: str
    residue_mapping: ResidueMapping

    def apply(self, coordinates: np.ndarray) -> np.ndarray:
        return np.asarray(coordinates) @ self.rotation + self.translation

    def inverse(self) -> "PairwiseTransform":
        rotation = self.rotation.T
        translation = -self.translation @ rotation
        mapping = ResidueMapping(
            self.chain_b, self.chain_a,
            tuple((b, a) for a, b in self.residue_mapping.pairs),
            self.residue_mapping.identity,
            self.residue_mapping.coverage_b,
            self.residue_mapping.coverage_a,
        )
        return PairwiseTransform(
            self.chain_b, self.chain_a, rotation, translation,
            -self.centroid_displacement, self.rmsd, self.fitted_atom_count,
            self.fitted_residue_count, self.sequence_identity,
            self.sequence_coverage, self.orientation, mapping,
        )


@dataclass
class PairRecord:
    chain_a: str
    chain_b: str
    transform: PairwiseTransform
    minimum_heavy_atom_distance: float
    heavy_atom_contact_count: int
    backbone_contact_count: int
    residue_contacts: set[tuple[int, int]]
    estimated_bsa: float
    retained: bool
    retention_reason: str
    pdb_amyloid_fragment_length: int = 0
    pdb_amyloid_fragment_fraction: float = 0.0
    pdb_amyloid_mean_ca_distance: float | None = None
    pdb_amyloid_ca_distance_std: float | None = None
    pdb_amyloid_mean_triplet_angle: float | None = None
    pdb_amyloid_candidate: bool = False
    residue_contact_ids: set[tuple[str, str]] = field(default_factory=set)


@dataclass
class AxisRecord:
    origin: np.ndarray
    direction: np.ndarray
    adjacent_vectors: list[np.ndarray]
    angular_mad_degrees: float
    method: str = "translation_vector_fallback"
    degenerate_interface_count: int = 0
    individual_directions: list[np.ndarray] = field(default_factory=list)
    individual_origins: list[np.ndarray] = field(default_factory=list)


@dataclass
class Protofilament:
    id: str
    chain_ids: list[str]
    pair_records: list[PairRecord]
    assembly: Assembly
    axis: AxisRecord | None = None
    alternative_support: float | None = None
    config: Any = None


@dataclass
class HydrogenBond:
    donor: ResidueID
    acceptor: ResidueID
    donor_index: int
    acceptor_index: int
    no_distance: float
    ho_distance: float
    nho_angle: float
    coh_angle: float
    axial_separation: float | None = None
    repeated_ladder: bool = False
    persistent_interfaces: int = 1


@dataclass
class HydrogenBondGraph:
    bonds: list[HydrogenBond]
    definition: str


@dataclass
class SecondaryStructureResult:
    assembly_states: dict[str, list[str]]
    isolated_states: dict[str, list[str]]
    backend: str
    assembly_beta_fraction: float
    isolated_beta_fraction: float
    assembly_induced_beta_fraction: float
    longest_contiguous_assembly_beta_segment: int
    fallback_reason: str | None = None


@dataclass
class CrossBetaFeatures:
    assembly_beta_fraction: float
    isolated_beta_fraction: float
    assembly_induced_beta_fraction: float
    longest_contiguous_assembly_beta_segment: int
    interchain_backbone_hbond_count: int
    interchain_hbond_fraction: float
    longest_hbond_ladder: int
    median_ladder_length: float
    ladder_coverage: float
    ladder_repeat_consistency: float
    hbond_count_consistency: float
    strand_axis_angles_degrees: list[float]
    propagation_axis_angles_degrees: list[float]
    whole_assembly_beta_fraction: float
    whole_assembly_isolated_beta_fraction: float
    whole_assembly_induced_beta_fraction: float
    whole_assembly_longest_beta_segment: int
    c_beta_score: float


@dataclass
class RepeatFeatures:
    axial_rises: list[float]
    twists_degrees: list[float]
    lateral_displacements: list[float]
    fitted_backbone_rmsds: list[float]
    rise_median: float | None
    rise_mad: float | None
    rise_range: list[float] | None
    twist_median: float | None
    twist_mad: float | None
    contact_jaccards: list[float]
    contact_precision_to_consensus: list[float]
    contact_recall_to_consensus: list[float]
    register_shifts: list[float | None]
    register_shift_consistency: float
    hbond_edge_similarities: list[float]
    screw_axis_angles_degrees: list[float]
    transform_composition_rmsd: float | None
    rise_consistency: float
    twist_consistency: float
    lateral_consistency: float
    axis_consistency: float
    contact_consistency: float
    hbond_consistency: float
    bsa_values: list[float]
    bsa_coefficient_of_variation: float | None
    r_repeat_score: float | None


@dataclass
class VirtualInterface:
    end: str
    step: int
    contact_map: set[tuple[int, int]]
    hbond_edges: set[tuple[int, int]]
    clash_count: int
    nonlocal_clash_count: int
    nonlocal_contact_count: int
    estimated_bsa: float
    coordinates: dict[tuple[int, str], np.ndarray]


@dataclass
class VirtualExtension:
    interfaces: list[VirtualInterface]
    median_rotation: np.ndarray
    median_translation: np.ndarray
    two_step_transform_drift: float | None


@dataclass
class ExtensionFeatures:
    extension_contact_similarity: float
    extension_hbond_similarity: float
    extension_clash_count: int
    extension_nonlocal_clash_count: int
    extension_nonlocal_contact_count: int
    extension_bsa_ratio: float | None
    extension_energy_ratio: None
    two_step_transform_drift: float | None
    e_extend_score: float


@dataclass
class GeometryConfig:
    minimum_sequence_identity: float = 0.85
    minimum_sequence_coverage: float = 0.70
    minimum_mapped_residues: int = 3
    contact_distance: float = 8.0
    heavy_atom_contact_distance: float = 4.5
    backbone_contact_distance: float = 5.5
    maximum_neighbor_distance: float = 12.0
    maximum_pair_rmsd: float = 3.0
    transform_direction_tolerance_degrees: float = 25.0
    transform_length_relative_tolerance: float = 0.45
    transform_rotation_tolerance_degrees: float = 15.0
    minimum_screw_rotation_degrees: float = 1.0
    hbond_no_distance: float = 3.5
    hbond_ho_distance: float = 2.7
    hbond_nho_angle: float = 120.0
    hbond_coh_angle: float = 90.0
    severe_clash_distance: float = 2.0
    model_index: int = 0
    extension_steps: int = 1
    use_pydssp: bool = True


@dataclass
class GeometryResult:
    schema_version: str
    prediction_id: str | None
    input: dict[str, Any]
    config: dict[str, Any]
    assessability: str
    chain_groups: list[list[str]]
    pair_records: list[PairRecord]
    protofilaments: list[dict[str, Any]]
    hydrogen_bonds: HydrogenBondGraph
    secondary_structure: SecondaryStructureResult
    finite_topology: dict[str, Any]
    quality: dict[str, Any]
    geometry_score: float | None
    geometry_aggregation: dict[str, Any]
    topology: dict[str, Any]
    warnings: list[str]
    software: dict[str, str]


def _unit(vector: np.ndarray) -> np.ndarray:
    norm = float(np.linalg.norm(vector))
    return np.asarray(vector, dtype=float) / norm if norm > 1e-12 else np.zeros(3)


def _angle(a: np.ndarray, b: np.ndarray, *, unsigned: bool = False) -> float:
    ua, ub = _unit(a), _unit(b)
    cosine = float(np.clip(np.dot(ua, ub), -1.0, 1.0))
    if unsigned:
        cosine = abs(cosine)
    return math.degrees(math.acos(cosine)) if np.any(ua) and np.any(ub) else float("nan")


def _mad(values: Sequence[float]) -> float | None:
    if not values:
        return None
    array = np.asarray(values, dtype=float)
    median = np.median(array)
    return float(np.median(np.abs(array - median)))


def _jaccard(a: set[Any], b: set[Any]) -> float:
    if not a and not b:
        return 1.0
    return len(a & b) / len(a | b) if a or b else 0.0


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        parsed = float(value)
        return parsed if math.isfinite(parsed) else default
    except (TypeError, ValueError):
        return default


def _hbond_definition(config: GeometryConfig) -> str:
    return (
        f"{HBOND_DEFINITION}:NO<={config.hbond_no_distance:g};"
        f"HO<={config.hbond_ho_distance:g};NHO>={config.hbond_nho_angle:g};"
        f"COH>={config.hbond_coh_angle:g}"
    )


def _contact_definition(config: GeometryConfig) -> str:
    return f"{CONTACT_DEFINITION}:distance<={config.contact_distance:g}"


def _format_cif_token(value: Any) -> str:
    text = str(value)
    if not text:
        return "."
    if any(character.isspace() for character in text) or text[0] in "#_$;[]'\"":
        return "'" + text.replace("'", "''") + "'"
    return text


def _mmcif_with_default_occupancy(path: Path) -> str:
    """Rebuild the atom-site loop when prediction mmCIF omits occupancy."""
    mmcif = MMCIF2Dict(str(path))
    atom_keys = [key for key in mmcif if key.startswith("_atom_site.")]
    if not atom_keys:
        raise ValueError(f"No _atom_site loop found in {path}")
    row_count = len(mmcif[atom_keys[0]])
    if any(len(mmcif[key]) != row_count for key in atom_keys):
        raise ValueError(f"Inconsistent _atom_site columns in {path}")
    output_keys = list(atom_keys)
    insert_at = output_keys.index("_atom_site.B_iso_or_equiv") if "_atom_site.B_iso_or_equiv" in output_keys else len(output_keys)
    output_keys.insert(insert_at, "_atom_site.occupancy")
    lines = [f"data_{path.stem}_occupancy", "#", "loop_", *output_keys]
    for row_index in range(row_count):
        lines.append(" ".join(
            "1.00" if key == "_atom_site.occupancy" else _format_cif_token(mmcif[key][row_index])
            for key in output_keys
        ))
    lines.append("#")
    return "\n".join(lines) + "\n"


def load_assembly(path: str | Path, model_index: int = 0) -> Assembly:
    """Parse one PDB/mmCIF model using stable residue IDs and occupancy altlocs."""
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)
    lower = path.name.lower()
    # label_asym_id is unique in mmCIF biological assemblies and supports
    # multi-character IDs; author IDs may be reused by symmetry-expanded copies.
    if lower.endswith((".cif", ".mmcif")):
        try:
            parser = MMCIFParser(QUIET=True, auth_chains=False)
        except TypeError:  # Biopython releases before label/auth chain selection.
            parser = MMCIFParser(QUIET=True)
    else:
        parser = PDBParser(QUIET=True)
    try:
        structure = parser.get_structure(path.stem, str(path))
    except KeyError as error:
        if "_atom_site.occupancy" not in str(error) or not lower.endswith((".cif", ".mmcif")):
            raise
        structure = parser.get_structure(path.stem, StringIO(_mmcif_with_default_occupancy(path)))
    models = list(structure.get_models())
    if not models:
        raise ValueError(f"No structural model found in {path}")
    if not 0 <= model_index < len(models):
        raise ValueError(f"model_index {model_index} is outside 0..{len(models) - 1}")
    model = models[model_index]
    chains: dict[str, ChainRecord] = {}
    warnings: list[str] = []
    for chain in model:
        chain_id = str(chain.id).strip() or "_"
        residues: list[ResidueRecord] = []
        for residue in chain:
            hetero, number, insertion = residue.id
            # Preserve unknown ATOM polymer residues as X.  Only non-polymer
            # HETATM records (including water) are outside geometry scope.
            if str(hetero).strip() and not is_aa(residue, standard=False):
                continue
            resname = str(residue.resname).strip().upper()
            atoms: dict[str, AtomRecord] = {}
            for atom_container in residue:
                atom = atom_container
                if atom.is_disordered() and hasattr(atom, "disordered_get_list"):
                    choices = list(atom.disordered_get_list())
                    atom = max(
                        choices,
                        key=lambda candidate: (
                            _safe_float(candidate.get_occupancy(), 0.0),
                            str(candidate.get_altloc()).strip() in {"", "A"},
                        ),
                    )
                name = str(atom.get_name()).strip().upper()
                element = str(getattr(atom, "element", "") or name[:1]).strip().upper()
                if element == "H" or name.startswith("H"):
                    continue
                coordinate = np.asarray(atom.get_coord(), dtype=float)
                if coordinate.shape != (3,) or not np.all(np.isfinite(coordinate)):
                    warnings.append(f"invalid coordinate omitted: {chain_id}:{number}:{name}")
                    continue
                atoms[name] = AtomRecord(
                    name, element, coordinate,
                    _safe_float(atom.get_occupancy(), 1.0),
                    str(atom.get_altloc()).strip(),
                )
            if not atoms:
                continue
            residue_id = ResidueID(model_index, chain_id, int(number), str(insertion).strip(), resname)
            residues.append(ResidueRecord(residue_id, ONE_LETTER.get(resname, "X"), atoms, len(residues)))
        if residues:
            chains[chain_id] = ChainRecord(chain_id, residues)
    if not chains:
        raise ValueError(f"No protein chains found in {path}")
    return Assembly(chains, str(path.resolve()), model_index, warnings)


def _nw_pairs(sequence_a: str, sequence_b: str) -> list[tuple[int | None, int | None]]:
    n, m, gap = len(sequence_a), len(sequence_b), -2
    score = np.zeros((n + 1, m + 1), dtype=int)
    trace = np.zeros((n + 1, m + 1), dtype=np.int8)
    score[:, 0] = np.arange(n + 1) * gap
    score[0, :] = np.arange(m + 1) * gap
    trace[1:, 0], trace[0, 1:] = 1, 2
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            choices = (
                score[i - 1, j - 1] + (2 if sequence_a[i - 1] == sequence_b[j - 1] else -1),
                score[i - 1, j] + gap,
                score[i, j - 1] + gap,
            )
            trace[i, j] = int(np.argmax(choices))
            score[i, j] = choices[trace[i, j]]
    result: list[tuple[int | None, int | None]] = []
    i, j = n, m
    while i or j:
        direction = int(trace[i, j])
        if direction == 0:
            i -= 1; j -= 1; result.append((i, j))
        elif direction == 1:
            i -= 1; result.append((i, None))
        else:
            j -= 1; result.append((None, j))
    return list(reversed(result))


def map_equivalent_residues(chain_a: ChainRecord, chain_b: ChainRecord) -> ResidueMapping:
    aligned = [(a, b) for a, b in _nw_pairs(chain_a.sequence, chain_b.sequence) if a is not None and b is not None]
    matches = sum(chain_a.sequence[a] == chain_b.sequence[b] for a, b in aligned)
    count = len(aligned)
    return ResidueMapping(
        chain_a.id, chain_b.id, tuple(aligned), matches / count if count else 0.0,
        count / len(chain_a.residues) if chain_a.residues else 0.0,
        count / len(chain_b.residues) if chain_b.residues else 0.0,
    )


def group_equivalent_chains(assembly: Assembly, config: GeometryConfig) -> list[list[str]]:
    ids = sorted(assembly.chains)
    adjacency: dict[str, set[str]] = {chain_id: set() for chain_id in ids}
    for position, chain_a_id in enumerate(ids):
        for chain_b_id in ids[position + 1:]:
            mapping = map_equivalent_residues(assembly.chains[chain_a_id], assembly.chains[chain_b_id])
            if (
                mapping.identity >= config.minimum_sequence_identity
                and min(mapping.coverage_a, mapping.coverage_b) >= config.minimum_sequence_coverage
                and len(mapping.pairs) >= config.minimum_mapped_residues
            ):
                adjacency[chain_a_id].add(chain_b_id)
                adjacency[chain_b_id].add(chain_a_id)
    groups: list[list[str]] = []
    unseen = set(ids)
    while unseen:
        start = min(unseen)
        component, queue = [], [start]
        unseen.remove(start)
        while queue:
            node = queue.pop()
            component.append(node)
            for neighbor in sorted(adjacency[node] & unseen):
                unseen.remove(neighbor); queue.append(neighbor)
        groups.append(sorted(component))
    return groups


def _kabsch(mobile: np.ndarray, target: np.ndarray) -> tuple[np.ndarray, np.ndarray, float]:
    mobile = np.asarray(mobile, dtype=float)
    target = np.asarray(target, dtype=float)
    if mobile.shape != target.shape or mobile.ndim != 2 or mobile.shape[1] != 3:
        raise ValueError("Kabsch inputs must have identical N x 3 shapes")
    if len(mobile) < 3:
        raise ValueError("At least three coordinate pairs are required")
    mobile_center, target_center = mobile.mean(axis=0), target.mean(axis=0)
    covariance = (mobile - mobile_center).T @ (target - target_center)
    left, _singular, right = np.linalg.svd(covariance)
    correction = np.eye(3)
    correction[-1, -1] = np.sign(np.linalg.det(left @ right))
    rotation = left @ correction @ right
    translation = target_center - mobile_center @ rotation
    fitted = mobile @ rotation + translation
    rmsd = float(np.sqrt(np.mean(np.sum((fitted - target) ** 2, axis=1))))
    return rotation, translation, rmsd


def fit_pair_transform(
    chain_a: ChainRecord,
    chain_b: ChainRecord,
    residue_map: ResidueMapping,
) -> PairwiseTransform:
    """Fit the proper rigid transform A -> B using explicitly mapped backbone atoms."""
    coordinates_a: list[np.ndarray] = []
    coordinates_b: list[np.ndarray] = []
    fitted_residues = 0
    for index_a, index_b in residue_map.pairs:
        residue_a, residue_b = chain_a.residues[index_a], chain_b.residues[index_b]
        used = False
        for atom_name in BACKBONE_ATOMS:
            if atom_name in residue_a.atoms and atom_name in residue_b.atoms:
                coordinates_a.append(residue_a.atoms[atom_name].coord)
                coordinates_b.append(residue_b.atoms[atom_name].coord)
                used = True
        fitted_residues += used
    if len(coordinates_a) < 3:
        raise ValueError(f"Insufficient mapped backbone atoms for {chain_a.id}/{chain_b.id}")
    array_a, array_b = np.asarray(coordinates_a), np.asarray(coordinates_b)
    rotation, translation, rmsd = _kabsch(array_a, array_b)
    mapped_ca = [
        (chain_a.residues[a].atom("CA"), chain_b.residues[b].atom("CA"))
        for a, b in residue_map.pairs
        if chain_a.residues[a].atom("CA") is not None and chain_b.residues[b].atom("CA") is not None
    ]
    if mapped_ca:
        centroid_a = np.mean([item[0] for item in mapped_ca], axis=0)
        centroid_b = np.mean([item[1] for item in mapped_ca], axis=0)
    else:
        centroid_a, centroid_b = chain_a.centroid, chain_b.centroid
    direction_a = _chain_direction(chain_a, [a for a, _ in residue_map.pairs])
    direction_b = _chain_direction(chain_b, [b for _, b in residue_map.pairs])
    orientation = "parallel" if np.dot(direction_a, direction_b) >= 0 else "antiparallel"
    return PairwiseTransform(
        chain_a.id, chain_b.id, rotation, translation, centroid_b - centroid_a,
        rmsd, len(array_a), fitted_residues, residue_map.identity,
        min(residue_map.coverage_a, residue_map.coverage_b), orientation, residue_map,
    )


def _chain_direction(chain: ChainRecord, indexes: Sequence[int] | None = None) -> np.ndarray:
    indexes = list(indexes) if indexes is not None else list(range(len(chain.residues)))
    coords = [chain.residues[index].atom("CA") for index in indexes]
    coords = [coord for coord in coords if coord is not None]
    if len(coords) < 2:
        return np.zeros(3)
    span = max(1, min(3, len(coords) // 3))
    return _unit(np.mean(coords[-span:], axis=0) - np.mean(coords[:span], axis=0))


def _pair_geometry(
    chain_a: ChainRecord,
    chain_b: ChainRecord,
    contact_distance: float,
    heavy_distance: float,
    backbone_distance: float,
) -> tuple[float, int, int, set[tuple[int, int]]]:
    atoms_a = [(i, name, atom.coord) for i, residue in enumerate(chain_a.residues) for name, atom in residue.atoms.items()]
    atoms_b = [(i, name, atom.coord) for i, residue in enumerate(chain_b.residues) for name, atom in residue.atoms.items()]
    minimum = float("inf")
    heavy_contacts = backbone_contacts = 0
    if atoms_a and atoms_b:
        coords_b = np.asarray([item[2] for item in atoms_b])
        for _index_a, name_a, coord_a in atoms_a:
            distances = np.linalg.norm(coords_b - coord_a, axis=1)
            minimum = min(minimum, float(np.min(distances)))
            close = np.flatnonzero(distances <= heavy_distance)
            heavy_contacts += len(close)
            if name_a in BACKBONE_ATOMS:
                backbone_contacts += sum(
                    atoms_b[index][1] in BACKBONE_ATOMS
                    for index in np.flatnonzero(distances <= backbone_distance)
                )
    residue_contacts: set[tuple[int, int]] = set()
    contact_b = [(j, residue.contact_coord()) for j, residue in enumerate(chain_b.residues)]
    contact_b = [(j, coord) for j, coord in contact_b if coord is not None]
    if contact_b:
        indexes_b = [item[0] for item in contact_b]
        coordinates_b = np.asarray([item[1] for item in contact_b])
        for i, residue in enumerate(chain_a.residues):
            coordinate = residue.contact_coord()
            if coordinate is None:
                continue
            for local_index in np.flatnonzero(np.linalg.norm(coordinates_b - coordinate, axis=1) <= contact_distance):
                residue_contacts.add((i, indexes_b[int(local_index)]))
    return minimum, heavy_contacts, backbone_contacts, residue_contacts


def _estimated_bsa(pair_contacts: int, heavy_contacts: int) -> float:
    """Documented preliminary contact-area proxy, in approximate square Angstroms."""
    return float(12.0 * pair_contacts + 0.35 * min(heavy_contacts, 4000))


def _pdb_amyloid_features(chain_a: ChainRecord, chain_b: ChainRecord) -> dict[str, Any]:
    """Calculate the transparent continuous-fragment features of PDB_Amyloid."""
    ca_a = [(index, residue.atom("CA")) for index, residue in enumerate(chain_a.residues)]
    ca_b = [residue.atom("CA") for residue in chain_b.residues]
    ca_a = [(index, coord) for index, coord in ca_a if coord is not None]
    ca_b = [coord for coord in ca_b if coord is not None]
    if not ca_a or not ca_b:
        return {
            "length": 0, "fraction": 0.0, "mean_distance": None,
            "distance_std": None, "mean_angle": None, "candidate": False,
        }
    array_b = np.asarray(ca_b)
    distances = [(index, float(np.min(np.linalg.norm(array_b - coord, axis=1)))) for index, coord in ca_a]
    runs: list[list[tuple[int, float]]] = []
    current: list[tuple[int, float]] = []
    previous_index = None
    for index, distance in distances:
        valid = 2.0 <= distance <= 15.0
        if valid and (previous_index is None or index == previous_index + 1):
            current.append((index, distance))
        elif valid:
            if current:
                runs.append(current)
            current = [(index, distance)]
        else:
            if current:
                runs.append(current)
            current = []
        previous_index = index
    if current:
        runs.append(current)
    best = max(runs, key=len, default=[])
    if not best:
        return {
            "length": 0, "fraction": 0.0, "mean_distance": None,
            "distance_std": None, "mean_angle": None, "candidate": False,
        }
    best_distances = [distance for _, distance in best]
    best_indexes = [index for index, _ in best]
    angles = []
    for chain in (chain_a, chain_b):
        for index in best_indexes[1:-1]:
            if index >= len(chain.residues) - 1:
                continue
            previous = chain.residues[index - 1].atom("CA")
            center = chain.residues[index].atom("CA")
            following = chain.residues[index + 1].atom("CA")
            if previous is not None and center is not None and following is not None:
                angles.append(_angle(previous - center, following - center))
    length = len(best)
    fraction = length / max(1, min(len(chain_a.residues), len(chain_b.residues)))
    mean_distance = float(np.mean(best_distances))
    distance_std = float(np.std(best_distances))
    mean_angle = float(np.mean(angles)) if angles else None
    candidate = bool(
        fraction >= 1.0 / 7.0
        and distance_std <= 1.5
        and mean_angle is not None
        and 110.0 <= mean_angle <= 180.0
    )
    return {
        "length": length, "fraction": fraction, "mean_distance": mean_distance,
        "distance_std": distance_std, "mean_angle": mean_angle, "candidate": candidate,
    }


def candidate_repeat_pairs(
    assembly: Assembly,
    chain_groups: Sequence[Sequence[str]] | None = None,
    config: GeometryConfig | None = None,
) -> list[PairRecord]:
    config = config or GeometryConfig()
    chain_groups = chain_groups or group_equivalent_chains(assembly, config)
    records: list[PairRecord] = []
    for group in chain_groups:
        for position, chain_a_id in enumerate(sorted(group)):
            for chain_b_id in sorted(group)[position + 1:]:
                chain_a, chain_b = assembly.chains[chain_a_id], assembly.chains[chain_b_id]
                mapping = map_equivalent_residues(chain_a, chain_b)
                if len(mapping.pairs) < config.minimum_mapped_residues:
                    continue
                pair_eligible = bool(
                    mapping.identity >= config.minimum_sequence_identity
                    and min(mapping.coverage_a, mapping.coverage_b) >= config.minimum_sequence_coverage
                )
                transform = fit_pair_transform(chain_a, chain_b, mapping)
                minimum, heavy, backbone, contacts = _pair_geometry(
                    chain_a, chain_b, config.contact_distance,
                    config.heavy_atom_contact_distance, config.backbone_contact_distance,
                )
                retained = bool(
                    pair_eligible
                    and
                    minimum <= config.maximum_neighbor_distance
                    and contacts
                    and transform.rmsd <= config.maximum_pair_rmsd
                )
                reason = "contacting_equivalent_pair" if retained else (
                    "below_sequence_identity_threshold" if mapping.identity < config.minimum_sequence_identity else
                    "below_sequence_coverage_threshold" if min(mapping.coverage_a, mapping.coverage_b) < config.minimum_sequence_coverage else
                    "no_interface_contacts" if not contacts else
                    "backbone_fit_rmsd" if transform.rmsd > config.maximum_pair_rmsd else
                    "chains_too_distant"
                )
                pdb_amyloid = _pdb_amyloid_features(chain_a, chain_b)
                record = PairRecord(
                    chain_a_id, chain_b_id, transform, minimum, heavy, backbone,
                    contacts, _estimated_bsa(len(contacts), heavy), retained, reason,
                    pdb_amyloid["length"], pdb_amyloid["fraction"],
                    pdb_amyloid["mean_distance"], pdb_amyloid["distance_std"],
                    pdb_amyloid["mean_angle"], pdb_amyloid["candidate"],
                    {
                        (chain_a.residues[index_a].id.text(), chain_b.residues[index_b].id.text())
                        for index_a, index_b in contacts
                    },
                )
                # Keep the public record/table compact while allowing the README's
                # three-argument infer_protofilaments API to recover its assembly.
                record._assembly = assembly
                records.append(record)
    return records


def build_chain_contact_graph(pair_records: Sequence[PairRecord]) -> dict[str, dict[str, PairRecord]]:
    graph: dict[str, dict[str, PairRecord]] = defaultdict(dict)
    for pair in pair_records:
        if pair.retained:
            graph[pair.chain_a][pair.chain_b] = pair
            graph[pair.chain_b][pair.chain_a] = pair
    return dict(graph)


def _direction_families(records: Sequence[PairRecord], config: GeometryConfig) -> list[list[PairRecord]]:
    if not records:
        return []
    families: dict[frozenset[tuple[str, str]], list[PairRecord]] = {}
    for seed in records:
        family = []
        for record in records:
            variants = (record.transform, record.transform.inverse())
            best_rotation, best_translation = min(
                (
                    _rotation_difference_degrees(seed.transform.rotation, variant.rotation),
                    float(np.linalg.norm(seed.transform.translation - variant.translation))
                    / max(float(np.linalg.norm(seed.transform.translation)), 1.0),
                )
                for variant in variants
            )
            if (
                best_rotation <= config.transform_rotation_tolerance_degrees
                and best_translation <= config.transform_length_relative_tolerance
            ):
                family.append(record)
        key = frozenset(tuple(sorted((pair.chain_a, pair.chain_b))) for pair in family)
        families[key] = family
    return sorted(
        families.values(),
        key=lambda family: (
            len({chain for pair in family for chain in (pair.chain_a, pair.chain_b)}),
            len(family),
            sum(len(pair.residue_contacts) for pair in family),
        ),
        reverse=True,
    )


def _rotation_difference_degrees(rotation_a: np.ndarray, rotation_b: np.ndarray) -> float:
    relative = rotation_a.T @ rotation_b
    return math.degrees(math.acos(float(np.clip((np.trace(relative) - 1.0) / 2.0, -1.0, 1.0))))


def _component_edges(records: Sequence[PairRecord]) -> list[list[PairRecord]]:
    adjacency: dict[str, set[str]] = defaultdict(set)
    edge_by_key = {}
    for record in records:
        adjacency[record.chain_a].add(record.chain_b)
        adjacency[record.chain_b].add(record.chain_a)
        edge_by_key[frozenset((record.chain_a, record.chain_b))] = record
    components: list[list[PairRecord]] = []
    unseen = set(adjacency)
    while unseen:
        start = min(unseen); unseen.remove(start)
        nodes, queue = {start}, [start]
        while queue:
            node = queue.pop()
            for neighbor in adjacency[node] & unseen:
                unseen.remove(neighbor); nodes.add(neighbor); queue.append(neighbor)
        components.append([record for record in records if record.chain_a in nodes and record.chain_b in nodes])
    return components


def _path_from_edges(records: Sequence[PairRecord]) -> list[str]:
    """Return a deterministic maximum-support path; cycles lose their weakest edge."""
    edges = sorted(records, key=lambda pair: (-len(pair.residue_contacts), pair.minimum_heavy_atom_distance, pair.chain_a, pair.chain_b))
    parent: dict[str, str] = {}
    degree: Counter[str] = Counter()

    def root(node: str) -> str:
        parent.setdefault(node, node)
        while parent[node] != node:
            parent[node] = parent[parent[node]]; node = parent[node]
        return node

    selected: list[PairRecord] = []
    for edge in edges:
        a, b = edge.chain_a, edge.chain_b
        ra, rb = root(a), root(b)
        if ra != rb and degree[a] < 2 and degree[b] < 2:
            parent[ra] = rb; degree[a] += 1; degree[b] += 1; selected.append(edge)
    if not selected:
        return sorted({chain for edge in records for chain in (edge.chain_a, edge.chain_b)})[:1]
    adjacency: dict[str, list[str]] = defaultdict(list)
    for edge in selected:
        adjacency[edge.chain_a].append(edge.chain_b); adjacency[edge.chain_b].append(edge.chain_a)
    endpoints = sorted(node for node, neighbors in adjacency.items() if len(neighbors) == 1)
    current = endpoints[0] if endpoints else min(adjacency)
    path, previous = [], None
    while current is not None:
        path.append(current)
        following = [node for node in sorted(adjacency[current]) if node != previous]
        previous, current = current, (following[0] if following else None)
    return path


def infer_protofilaments(
    pair_records: Sequence[PairRecord],
    contact_graph: Mapping[str, Mapping[str, PairRecord]] | None = None,
    config: GeometryConfig | None = None,
    assembly: Assembly | None = None,
) -> list[Protofilament]:
    config = config or GeometryConfig()
    retained = [record for record in pair_records if record.retained]
    if not retained:
        return []
    families = _direction_families(retained, config)
    if not families:
        return []
    if assembly is None and pair_records:
        assembly = getattr(pair_records[0], "_assembly", None)
    if assembly is None:
        raise ValueError("assembly is required to infer protofilaments")
    def support(family: Sequence[PairRecord]) -> float:
        return float(sum(len(pair.residue_contacts) for pair in family))

    best_support = max(support(families[0]), 1.0)
    selected_families = [families[0]]
    selected_families.extend(
        family for family in families[1:]
        if support(family) / best_support >= 0.80
        and len({chain for pair in family for chain in (pair.chain_a, pair.chain_b)})
        >= len({chain for pair in families[0] for chain in (pair.chain_a, pair.chain_b)}) - 1
    )
    result: list[Protofilament] = []
    for family_index, family in enumerate(selected_families):
        for component in _component_edges(family):
            path = _path_from_edges(component)
            if len(path) < 2:
                continue
            lookup = {frozenset((record.chain_a, record.chain_b)): record for record in component}
            path_pairs = [lookup[frozenset((a, b))] for a, b in zip(path, path[1:])]
            protofilament = Protofilament(
                f"PF{len(result) + 1}", path, path_pairs, assembly,
                alternative_support=(support(family) / best_support if family_index else None),
                config=config,
            )
            protofilament.axis = infer_fibril_axis(protofilament)
            result.append(protofilament)
    return result


def protofilaments_from_layer_assignments(
    pair_records: Sequence[PairRecord],
    layer_assignments: Sequence[Any],
    assembly: Assembly,
    config: GeometryConfig,
) -> tuple[list[Protofilament], dict[str, Any]]:
    """Construct geometry paths from canonical common layer constraints."""
    by_protofilament: dict[str, list[Any]] = defaultdict(list)
    for item in layer_assignments:
        if getattr(item, "observed_or_virtual", "observed") == "observed":
            by_protofilament[str(item.protofilament_id)].append(item)
    lookup = {
        frozenset((record.chain_a, record.chain_b)): record
        for record in pair_records
    }
    result: list[Protofilament] = []
    disagreements: list[dict[str, Any]] = []
    requested_paths: list[list[str]] = []
    for protofilament_id, assignments in sorted(by_protofilament.items()):
        ordered = sorted(assignments, key=lambda item: (item.layer_index, item.chain_id))
        path = [item.chain_id for item in ordered]
        requested_paths.append(path)
        if any(chain not in assembly.chains for chain in path):
            disagreements.append({"protofilament": protofilament_id, "reason": "unknown_chain", "path": path})
            continue
        if len(path) < 2:
            continue
        pairs: list[PairRecord] = []
        valid = True
        for first, second in zip(ordered, ordered[1:]):
            if abs(second.layer_index - first.layer_index) != 1:
                disagreements.append({
                    "protofilament": protofilament_id,
                    "reason": "nonconsecutive_layers",
                    "chains": [first.chain_id, second.chain_id],
                })
                valid = False
                break
            pair = lookup.get(frozenset((first.chain_id, second.chain_id)))
            if pair is None:
                disagreements.append({
                    "protofilament": protofilament_id,
                    "reason": "unsupported_heterogeneous_or_nonequivalent_pair",
                    "chains": [first.chain_id, second.chain_id],
                })
                valid = False
                break
            if not pair.retained:
                disagreements.append({
                    "protofilament": protofilament_id,
                    "reason": f"pair_not_retained:{pair.retention_reason}",
                    "chains": [first.chain_id, second.chain_id],
                })
                valid = False
                break
            pairs.append(pair)
        if valid:
            protofilament = Protofilament(
                protofilament_id, path, pairs, assembly, config=config
            )
            protofilament.axis = infer_fibril_axis(protofilament)
            result.append(protofilament)
    status = "matched" if not disagreements else "disagreement"
    return result, {
        "source": "canonical_layer_assignments",
        "status": status,
        "requested_paths": requested_paths,
        "scored_paths": [item.chain_ids for item in result],
        "disagreements": disagreements,
    }


def _screw_decompose(
    rotation: np.ndarray,
    translation: np.ndarray,
    fallback_direction: np.ndarray,
    minimum_rotation_degrees: float = 1.0,
) -> dict[str, Any]:
    """Decompose row-vector transform ``x' = x R + t`` into screw parameters."""
    rotation = np.asarray(rotation, dtype=float)
    translation = np.asarray(translation, dtype=float)
    cosine = float(np.clip((np.trace(rotation) - 1.0) / 2.0, -1.0, 1.0))
    angle = math.acos(cosine)
    if angle < math.radians(minimum_rotation_degrees):
        axis = _unit(fallback_direction if np.linalg.norm(fallback_direction) else translation)
        return {
            "axis": axis,
            "origin": None,
            "rise": float(np.dot(translation, axis)),
            "twist_degrees": 0.0,
            "method": "translation_vector_fallback",
            "degenerate": True,
        }

    column_rotation = rotation.T
    if abs(math.sin(angle)) > 1e-7:
        axis = _unit(np.array([
            column_rotation[2, 1] - column_rotation[1, 2],
            column_rotation[0, 2] - column_rotation[2, 0],
            column_rotation[1, 0] - column_rotation[0, 1],
        ]))
    else:
        eigenvalues, eigenvectors = np.linalg.eig(column_rotation)
        axis = _unit(np.real(eigenvectors[:, int(np.argmin(np.abs(eigenvalues - 1.0)))]))
    if not np.any(axis):
        axis = _unit(fallback_direction)
    rise = float(np.dot(translation, axis))
    # A point on the screw axis satisfies (I-R)p=t-h*a.  The final row fixes
    # the otherwise free position along the axis to the closest point to origin.
    matrix = np.vstack((np.eye(3) - column_rotation, axis))
    right_hand = np.concatenate((translation - rise * axis, [0.0]))
    origin, *_ = np.linalg.lstsq(matrix, right_hand, rcond=None)
    twist = math.degrees(angle)
    if np.dot(axis, fallback_direction) < 0:
        axis = -axis
        rise = -rise
        twist = -twist
    return {
        "axis": axis,
        "origin": origin,
        "rise": rise,
        "twist_degrees": twist,
        "method": "screw_axis",
        "degenerate": False,
    }


def infer_fibril_axis(protofilament: Protofilament) -> AxisRecord:
    vectors: list[np.ndarray] = []
    decompositions: list[dict[str, Any]] = []
    for source, target, pair in zip(
        protofilament.chain_ids,
        protofilament.chain_ids[1:],
        protofilament.pair_records,
    ):
        vector = protofilament.assembly.chains[target].centroid - protofilament.assembly.chains[source].centroid
        vectors.append(vector)
        transform = _directed_transform(pair, source, target)
        threshold = (
            protofilament.config.minimum_screw_rotation_degrees
            if protofilament.config is not None else 1.0
        )
        decompositions.append(_screw_decompose(
            transform.rotation, transform.translation, vector, threshold
        ))
    if not vectors:
        raise ValueError("A protofilament needs at least two chains")
    reference = _unit(vectors[0])
    directions = []
    for decomposition in decompositions:
        direction = decomposition["axis"]
        if np.dot(direction, reference) < 0:
            direction = -direction
        directions.append(direction)
    direction = _unit(np.median(np.asarray(directions), axis=0))
    if np.dot(direction, reference) < 0:
        direction = -direction
    angles = [_angle(item, direction) for item in directions]
    origins = [item["origin"] for item in decompositions if item["origin"] is not None]
    centroids = [protofilament.assembly.chains[chain_id].centroid for chain_id in protofilament.chain_ids]
    origin = np.median(np.asarray(origins), axis=0) if origins else np.median(np.asarray(centroids), axis=0)
    methods = {item["method"] for item in decompositions}
    method = "screw_axis" if methods == {"screw_axis"} else (
        "translation_vector_fallback" if methods == {"translation_vector_fallback"} else "mixed_screw_and_translation"
    )
    return AxisRecord(
        origin, direction, vectors, _mad(angles) or 0.0, method,
        sum(bool(item["degenerate"]) for item in decompositions), directions,
        [np.asarray(item) for item in origins],
    )


def _virtual_h(residues: Sequence[ResidueRecord], index: int) -> np.ndarray | None:
    if index <= 0 or residues[index].id.residue_name == "PRO":
        return None
    nitrogen = residues[index].atom("N")
    previous_carbon = residues[index - 1].atom("C")
    previous_oxygen = residues[index - 1].atom("O")
    if nitrogen is None or previous_carbon is None or previous_oxygen is None:
        return None
    # DSSP/PyDSSP-style peptide-plane reconstruction: the amide H direction is
    # approximated by the preceding carbonyl C<-O direction, translated to N.
    return nitrogen + _unit(previous_carbon - previous_oxygen) * 1.01


def build_backbone_hbond_graph(
    assembly: Assembly,
    config: GeometryConfig | None = None,
    axis: AxisRecord | None = None,
) -> HydrogenBondGraph:
    config = config or GeometryConfig()
    bonds: list[HydrogenBond] = []
    for donor_chain_id, donor_chain in assembly.chains.items():
        for donor_index, donor in enumerate(donor_chain.residues):
            nitrogen = donor.atom("N")
            hydrogen = _virtual_h(donor_chain.residues, donor_index)
            if nitrogen is None or hydrogen is None:
                continue
            for acceptor_chain_id, acceptor_chain in assembly.chains.items():
                if donor_chain_id == acceptor_chain_id:
                    continue
                for acceptor_index, acceptor in enumerate(acceptor_chain.residues):
                    oxygen, carbon = acceptor.atom("O"), acceptor.atom("C")
                    if oxygen is None or carbon is None:
                        continue
                    no_distance = float(np.linalg.norm(nitrogen - oxygen))
                    if no_distance > config.hbond_no_distance:
                        continue
                    ho_distance = float(np.linalg.norm(hydrogen - oxygen))
                    nho_angle = _angle(nitrogen - hydrogen, oxygen - hydrogen)
                    coh_angle = _angle(carbon - oxygen, hydrogen - oxygen)
                    if (
                        ho_distance <= config.hbond_ho_distance
                        and nho_angle >= config.hbond_nho_angle
                        and coh_angle >= config.hbond_coh_angle
                    ):
                        separation = None
                        if axis is not None:
                            separation = abs(float(np.dot(nitrogen - oxygen, axis.direction)))
                        bonds.append(HydrogenBond(
                            donor.id, acceptor.id, donor_index, acceptor_index,
                            no_distance, ho_distance, nho_angle, coh_angle, separation,
                        ))
    _annotate_ladders(bonds)
    pattern_interfaces: dict[tuple[int, int], set[frozenset[str]]] = defaultdict(set)
    for bond in bonds:
        pattern = (bond.donor_index, bond.acceptor_index)
        pattern_interfaces[pattern].add(frozenset((bond.donor.chain_id, bond.acceptor.chain_id)))
    for bond in bonds:
        bond.persistent_interfaces = len(pattern_interfaces[(bond.donor_index, bond.acceptor_index)])
    return HydrogenBondGraph(bonds, _hbond_definition(config))


def _annotate_ladders(bonds: list[HydrogenBond]) -> list[list[HydrogenBond]]:
    grouped: dict[frozenset[str], list[HydrogenBond]] = defaultdict(list)
    for bond in bonds:
        grouped[frozenset((bond.donor.chain_id, bond.acceptor.chain_id))].append(bond)
    ladders: list[list[HydrogenBond]] = []
    for group in grouped.values():
        first_chain = min(
            chain_id
            for bond in group
            for chain_id in (bond.donor.chain_id, bond.acceptor.chain_id)
        )
        edge_bonds: dict[tuple[int, int], list[HydrogenBond]] = defaultdict(list)
        for bond in group:
            edge = (
                (bond.donor_index, bond.acceptor_index)
                if bond.donor.chain_id == first_chain
                else (bond.acceptor_index, bond.donor_index)
            )
            edge_bonds[edge].append(bond)

        def monotonic_runs(sign: int) -> list[list[tuple[int, int]]]:
            edges = set(edge_bonds)
            starts = sorted(edge for edge in edges if (edge[0] - 1, edge[1] - sign) not in edges)
            runs = []
            used: set[tuple[int, int]] = set()
            for start in starts:
                run, current = [], start
                while current in edges and current not in used:
                    run.append(current); used.add(current)
                    current = (current[0] + 1, current[1] + sign)
                if run:
                    runs.append(run)
            runs.extend([[edge] for edge in sorted(edges - used)])
            return runs

        parallel = monotonic_runs(1)
        antiparallel = monotonic_runs(-1)
        score_parallel = sum(len(run) ** 2 for run in parallel)
        score_antiparallel = sum(len(run) ** 2 for run in antiparallel)
        selected = parallel if score_parallel >= score_antiparallel else antiparallel
        for run in selected:
            # Ladder length is the number of ordered rung positions, not the
            # number of reciprocal donor/acceptor records at those positions.
            ladder = [edge_bonds[edge][0] for edge in run]
            if len(run) >= 2:
                for edge in run:
                    for bond in edge_bonds[edge]:
                        bond.repeated_ladder = True
            ladders.append(ladder)
    return ladders


def _pydssp_states(assembly: Assembly, per_chain: bool) -> dict[str, list[str]]:
    import pydssp  # type: ignore

    parameters = inspect.signature(pydssp.assign).parameters
    if "donor_mask" not in parameters:
        try:
            version = importlib.metadata.version("pydssp")
        except importlib.metadata.PackageNotFoundError:
            version = getattr(pydssp, "__version__", "unknown")
        raise PyDSSPCompatibilityError(
            f"PyDSSP {version} assign() lacks donor_mask; multichain boundaries cannot be represented safely"
        )

    def assign(chains: Sequence[ChainRecord]) -> list[str]:
        coordinates, donor_mask = [], []
        for chain in chains:
            for index, residue in enumerate(chain.residues):
                if not all(name in residue.atoms for name in BACKBONE_ATOMS):
                    raise IncompleteBackboneError(
                        f"PyDSSP requires complete N/CA/C/O residues; incomplete residue {residue.id.text()}"
                    )
                coordinates.append([residue.atoms[name].coord for name in BACKBONE_ATOMS])
                donor_mask.append(index > 0 and residue.id.residue_name != "PRO")
        original_length = len(coordinates)
        if original_length < 3:
            return ["C"] * original_length
        while len(coordinates) < 6:
            base = 10000.0 + 20.0 * len(coordinates)
            coordinates.append([[base, 0, 0], [base, 1.45, 0], [base, 2.9, 0], [base + 1.2, 3.4, 0]])
            donor_mask.append(False)
        try:
            states = pydssp.assign(
                np.asarray(coordinates), donor_mask=np.asarray(donor_mask), out_type="c3"
            )
        except TypeError as error:
            raise PyDSSPCompatibilityError(
                f"installed PyDSSP rejected the donor_mask-compatible call: {error}"
            ) from error
        return [str(state) for state in states[:original_length]]

    result: dict[str, list[str]] = {}
    if per_chain:
        for chain in assembly.chains.values():
            result[chain.id] = assign([chain])
    else:
        flat = assign(list(assembly.chains.values()))
        offset = 0
        for chain in assembly.chains.values():
            result[chain.id] = flat[offset:offset + len(chain.residues)]
            offset += len(chain.residues)
    return result


def _fallback_states(
    assembly: Assembly,
    graph: HydrogenBondGraph,
    isolated: bool,
    config: GeometryConfig,
) -> dict[str, list[str]]:
    states = {chain_id: ["C"] * len(chain.residues) for chain_id, chain in assembly.chains.items()}
    if isolated:
        # Use the same documented geometry within each isolated chain.  Sequence
        # neighbors are excluded because they describe the peptide bond itself,
        # not secondary-structure hydrogen bonding.
        for chain_id, chain in assembly.chains.items():
            for donor_index, donor in enumerate(chain.residues):
                nitrogen = donor.atom("N")
                hydrogen = _virtual_h(chain.residues, donor_index)
                if nitrogen is None or hydrogen is None:
                    continue
                for acceptor_index, acceptor in enumerate(chain.residues):
                    if abs(donor_index - acceptor_index) < 3:
                        continue
                    oxygen, carbon = acceptor.atom("O"), acceptor.atom("C")
                    if oxygen is None or carbon is None:
                        continue
                    if (
                        np.linalg.norm(nitrogen - oxygen) <= config.hbond_no_distance
                        and np.linalg.norm(hydrogen - oxygen) <= config.hbond_ho_distance
                        and _angle(nitrogen - hydrogen, oxygen - hydrogen) >= config.hbond_nho_angle
                        and _angle(carbon - oxygen, hydrogen - oxygen) >= config.hbond_coh_angle
                    ):
                        states[chain_id][donor_index] = "E"
                        states[chain_id][acceptor_index] = "E"
    else:
        for bond in graph.bonds:
            states[bond.donor.chain_id][bond.donor_index] = "E"
            states[bond.acceptor.chain_id][bond.acceptor_index] = "E"
    return states


def assign_assembly_secondary_structure(
    assembly: Assembly,
    config: GeometryConfig | None = None,
    hbond_graph: HydrogenBondGraph | None = None,
) -> SecondaryStructureResult:
    config = config or GeometryConfig()
    backend = "hbond_geometry_fallback"
    graph = hbond_graph or build_backbone_hbond_graph(assembly, config)
    fallback_reason = None
    try:
        if not config.use_pydssp:
            raise PyDSSPCompatibilityError("PyDSSP disabled by configuration")
        assembly_states = _pydssp_states(assembly, per_chain=False)
        isolated_states = _pydssp_states(assembly, per_chain=True)
        # Intermolecular strands come from the assembly call; helices come from
        # isolated chains so a chain boundary cannot mimic peptide continuity.
        assembly_states = {
            chain_id: [
                "E" if assembly_state == "E" else "H" if isolated_state == "H" else "C"
                for assembly_state, isolated_state in zip(assembly_states[chain_id], isolated_states[chain_id])
            ]
            for chain_id in assembly_states
        }
        backend = "pydssp_c3"
    except (ImportError, ModuleNotFoundError, PyDSSPCompatibilityError, IncompleteBackboneError) as error:
        fallback_reason = f"{type(error).__name__}: {error}"
        assembly_states = _fallback_states(assembly, graph, isolated=False, config=config)
        isolated_states = _fallback_states(assembly, graph, isolated=True, config=config)
    all_assembly = [state for states in assembly_states.values() for state in states]
    all_isolated = [state for states in isolated_states.values() for state in states]
    assembly_fraction = all_assembly.count("E") / len(all_assembly) if all_assembly else 0.0
    isolated_fraction = all_isolated.count("E") / len(all_isolated) if all_isolated else 0.0
    longest = 0
    for states in assembly_states.values():
        current = 0
        for state in states:
            current = current + 1 if state == "E" else 0
            longest = max(longest, current)
    return SecondaryStructureResult(
        assembly_states, isolated_states, backend, assembly_fraction, isolated_fraction,
        sum(
            assembly_state == "E" and isolated_state != "E"
            for chain_id in assembly_states
            for assembly_state, isolated_state in zip(assembly_states[chain_id], isolated_states[chain_id])
        ) / max(1, len(all_assembly)),
        longest, fallback_reason,
    )


def _path_hbonds(protofilament: Protofilament, graph: HydrogenBondGraph) -> list[HydrogenBond]:
    adjacent = {frozenset(pair) for pair in zip(protofilament.chain_ids, protofilament.chain_ids[1:])}
    return [bond for bond in graph.bonds if frozenset((bond.donor.chain_id, bond.acceptor.chain_id)) in adjacent]


def score_cross_beta(
    protofilament: Protofilament,
    ss_result: SecondaryStructureResult,
    hbond_graph: HydrogenBondGraph,
) -> CrossBetaFeatures:
    if protofilament.axis is None:
        protofilament.axis = infer_fibril_axis(protofilament)
    axis = protofilament.axis.direction
    bonds = _path_hbonds(protofilament, hbond_graph)
    ladders = _annotate_ladders(bonds)
    ladder_lengths = [len(ladder) for ladder in ladders if len(ladder) >= 2]
    participating = {(bond.donor.chain_id, bond.donor_index) for bond in bonds}
    participating |= {(bond.acceptor.chain_id, bond.acceptor_index) for bond in bonds}
    total_residues = sum(len(protofilament.assembly.chains[chain].residues) for chain in protofilament.chain_ids)
    assembly_states = [
        state for chain_id in protofilament.chain_ids
        for state in ss_result.assembly_states.get(chain_id, [])
    ]
    isolated_states = [
        state for chain_id in protofilament.chain_ids
        for state in ss_result.isolated_states.get(chain_id, [])
    ]
    proto_assembly_fraction = assembly_states.count("E") / max(1, len(assembly_states))
    proto_isolated_fraction = isolated_states.count("E") / max(1, len(isolated_states))
    proto_induced_fraction = sum(
        assembly_state == "E" and isolated_state != "E"
        for chain_id in protofilament.chain_ids
        for assembly_state, isolated_state in zip(
            ss_result.assembly_states.get(chain_id, []),
            ss_result.isolated_states.get(chain_id, []),
        )
    ) / max(1, len(assembly_states))
    proto_longest = 0
    for chain_id in protofilament.chain_ids:
        current = 0
        for state in ss_result.assembly_states.get(chain_id, []):
            current = current + 1 if state == "E" else 0
            proto_longest = max(proto_longest, current)
    strand_angles: list[float] = []
    for chain_id in protofilament.chain_ids:
        chain = protofilament.assembly.chains[chain_id]
        states = ss_result.assembly_states.get(chain_id, [])
        start = 0
        while start < len(states):
            if states[start] != "E":
                start += 1; continue
            end = start + 1
            while end < len(states) and states[end] == "E":
                end += 1
            coords = [chain.residues[index].atom("CA") for index in range(start, end)]
            coords = [coord for coord in coords if coord is not None]
            if len(coords) >= 2:
                strand_angles.append(_angle(coords[-1] - coords[0], axis, unsigned=True))
            start = end
    propagation_angles = []
    for bond in bonds:
        donor = protofilament.assembly.chains[bond.donor.chain_id].residues[bond.donor_index].atom("N")
        acceptor = protofilament.assembly.chains[bond.acceptor.chain_id].residues[bond.acceptor_index].atom("O")
        if donor is not None and acceptor is not None:
            propagation_angles.append(_angle(donor - acceptor, axis, unsigned=True))
    interfaces = max(1, len(protofilament.chain_ids) - 1)
    bond_fraction = len(bonds) / max(1, total_residues)
    ladder_coverage = len(participating) / max(1, total_residues)
    counts_by_interface = Counter(frozenset((bond.donor.chain_id, bond.acceptor.chain_id)) for bond in bonds)
    count_consistency = 0.0
    if counts_by_interface:
        counts = np.asarray(list(counts_by_interface.values()), dtype=float)
        count_consistency = float(np.clip(1.0 - np.std(counts) / max(np.mean(counts), 1.0), 0.0, 1.0))
        count_consistency *= len(counts_by_interface) / interfaces
    index_maps = _canonical_index_maps(protofilament)
    hbond_maps = _interface_hbond_maps(protofilament, hbond_graph, index_maps)
    hbond_pattern_similarities = [_jaccard(first, second) for first, second in zip(hbond_maps, hbond_maps[1:])]
    repeat_consistency = float(np.mean(hbond_pattern_similarities)) if hbond_pattern_similarities else 0.0
    transverse = float(np.mean([angle >= 60 for angle in strand_angles])) if strand_angles else 0.0
    axial = float(np.mean([angle <= 30 for angle in propagation_angles])) if propagation_angles else 0.0
    beta_support = min(1.0, proto_assembly_fraction / 0.5)
    hbond_support = min(1.0, ladder_coverage / 0.35)
    c_beta = float(np.clip(0.25 * beta_support + 0.30 * hbond_support + 0.25 * transverse + 0.20 * axial, 0, 1))
    return CrossBetaFeatures(
        proto_assembly_fraction, proto_isolated_fraction, proto_induced_fraction,
        proto_longest, len(bonds), bond_fraction,
        max(ladder_lengths, default=0), float(np.median(ladder_lengths)) if ladder_lengths else 0.0,
        ladder_coverage, repeat_consistency, count_consistency,
        strand_angles, propagation_angles,
        ss_result.assembly_beta_fraction, ss_result.isolated_beta_fraction,
        ss_result.assembly_induced_beta_fraction,
        ss_result.longest_contiguous_assembly_beta_segment,
        c_beta,
    )


def _directed_transform(pair: PairRecord, source: str, target: str) -> PairwiseTransform:
    if pair.chain_a == source and pair.chain_b == target:
        return pair.transform
    if pair.chain_b == source and pair.chain_a == target:
        return pair.transform.inverse()
    raise ValueError(f"Pair {pair.chain_a}/{pair.chain_b} does not connect {source}/{target}")


def _rotation_angle(rotation: np.ndarray, axis: np.ndarray) -> float:
    decomposition = _screw_decompose(rotation, np.zeros(3), axis)
    screw_axis = decomposition["axis"]
    angle = abs(float(decomposition["twist_degrees"]))
    return angle if np.dot(screw_axis, axis) >= 0 else -angle


def _canonical_index_maps(protofilament: Protofilament) -> dict[str, dict[int, int]]:
    """Map each chain's sequence indexes onto the first chain's aligned indexes."""
    reference = protofilament.assembly.chains[protofilament.chain_ids[0]]
    result = {reference.id: {index: index for index in range(len(reference.residues))}}
    for chain_id in protofilament.chain_ids[1:]:
        mapping = map_equivalent_residues(reference, protofilament.assembly.chains[chain_id])
        result[chain_id] = {chain_index: reference_index for reference_index, chain_index in mapping.pairs}
    return result


def _canonical_contact_map(
    pair: PairRecord,
    source: str,
    index_maps: Mapping[str, Mapping[int, int]] | None = None,
) -> set[tuple[int, int]]:
    contacts = pair.residue_contacts if pair.chain_a == source else {(b, a) for a, b in pair.residue_contacts}
    target = pair.chain_b if pair.chain_a == source else pair.chain_a
    if index_maps is None:
        return set(contacts)
    source_map, target_map = index_maps[source], index_maps[target]
    return {
        (source_map[index_a], target_map[index_b])
        for index_a, index_b in contacts
        if index_a in source_map and index_b in target_map
    }


def _consensus_map(maps: Sequence[set[tuple[int, int]]]) -> set[tuple[int, int]]:
    threshold = math.ceil(len(maps) / 2)
    counts = Counter(item for contact_map in maps for item in contact_map)
    return {item for item, count in counts.items() if count >= threshold}


def _register_shift(contact_map: set[tuple[int, int]]) -> float | None:
    return float(np.median([b - a for a, b in contact_map])) if contact_map else None


def _interface_hbond_maps(
    protofilament: Protofilament,
    graph: HydrogenBondGraph | None,
    index_maps: Mapping[str, Mapping[int, int]] | None = None,
) -> list[set[tuple[int, int]]]:
    result = []
    for source, target in zip(protofilament.chain_ids, protofilament.chain_ids[1:]):
        edges = set()
        if graph is not None:
            for bond in graph.bonds:
                if bond.donor.chain_id == source and bond.acceptor.chain_id == target:
                    raw_edge = (bond.donor_index, bond.acceptor_index)
                elif bond.donor.chain_id == target and bond.acceptor.chain_id == source:
                    raw_edge = (bond.acceptor_index, bond.donor_index)
                else:
                    continue
                if index_maps is None:
                    edges.add(raw_edge)
                elif raw_edge[0] in index_maps[source] and raw_edge[1] in index_maps[target]:
                    edges.add((index_maps[source][raw_edge[0]], index_maps[target][raw_edge[1]]))
        result.append(edges)
    return result


def _annotate_hbond_persistence_across_protofilaments(
    protofilaments: Sequence[Protofilament],
    graph: HydrogenBondGraph,
) -> None:
    """Annotate bonds by mapped edge correspondence across axial interfaces."""
    for bond in graph.bonds:
        bond.persistent_interfaces = 1
    for protofilament in protofilaments:
        index_maps = _canonical_index_maps(protofilament)
        edge_interfaces: dict[tuple[int, int], set[int]] = defaultdict(set)
        bond_edges: list[tuple[HydrogenBond, tuple[int, int], int]] = []
        for interface_index, (source, target) in enumerate(
            zip(protofilament.chain_ids, protofilament.chain_ids[1:])
        ):
            for bond in graph.bonds:
                if bond.donor.chain_id == source and bond.acceptor.chain_id == target:
                    raw_edge = (bond.donor_index, bond.acceptor_index)
                elif bond.donor.chain_id == target and bond.acceptor.chain_id == source:
                    raw_edge = (bond.acceptor_index, bond.donor_index)
                else:
                    continue
                if raw_edge[0] not in index_maps[source] or raw_edge[1] not in index_maps[target]:
                    continue
                edge = (index_maps[source][raw_edge[0]], index_maps[target][raw_edge[1]])
                edge_interfaces[edge].add(interface_index)
                bond_edges.append((bond, edge, interface_index))
        for bond, edge, _interface_index in bond_edges:
            bond.persistent_interfaces = max(
                bond.persistent_interfaces, len(edge_interfaces[edge])
            )


def score_repeat_consistency(
    protofilament: Protofilament,
    config: GeometryConfig | None = None,
    hbond_graph: HydrogenBondGraph | None = None,
) -> RepeatFeatures:
    config = config or GeometryConfig()
    if protofilament.axis is None:
        protofilament.axis = infer_fibril_axis(protofilament)
    axis = protofilament.axis.direction
    rises: list[float] = []
    twists: list[float] = []
    laterals: list[float] = []
    lateral_vectors: list[np.ndarray] = []
    axis_angles: list[float] = []
    rmsds: list[float] = []
    maps: list[set[tuple[int, int]]] = []
    index_maps = _canonical_index_maps(protofilament)
    for source, target, pair in zip(protofilament.chain_ids, protofilament.chain_ids[1:], protofilament.pair_records):
        transform = _directed_transform(pair, source, target)
        vector = protofilament.assembly.chains[target].centroid - protofilament.assembly.chains[source].centroid
        decomposition = _screw_decompose(
            transform.rotation, transform.translation, vector,
            config.minimum_screw_rotation_degrees,
        )
        screw_axis = decomposition["axis"]
        rise = float(decomposition["rise"])
        twist = float(decomposition["twist_degrees"])
        if np.dot(screw_axis, axis) < 0:
            screw_axis = -screw_axis; rise = -rise; twist = -twist
        rises.append(abs(rise))
        twists.append(twist)
        lateral_vector = vector - np.dot(vector, axis) * axis
        lateral_vectors.append(lateral_vector)
        laterals.append(float(np.linalg.norm(lateral_vector)))
        axis_angles.append(_angle(screw_axis, axis))
        rmsds.append(transform.rmsd)
        maps.append(_canonical_contact_map(pair, source, index_maps))
    consensus = _consensus_map(maps) if maps else set()
    jaccards = [_jaccard(a, b) for a, b in zip(maps, maps[1:])]
    precisions = [len(contact_map & consensus) / len(contact_map) if contact_map else float(not consensus) for contact_map in maps]
    recalls = [len(contact_map & consensus) / len(consensus) if consensus else 1.0 for contact_map in maps]
    shifts = [_register_shift(contact_map) for contact_map in maps]
    finite_shifts = [shift for shift in shifts if shift is not None]
    shift_consistency = float(np.clip(1.0 - (_mad(finite_shifts) or 0.0) / 2.0, 0.0, 1.0)) if finite_shifts else 0.0
    hbond_maps = _interface_hbond_maps(protofilament, hbond_graph, index_maps)
    hbond_similarities = [_jaccard(a, b) for a, b in zip(hbond_maps, hbond_maps[1:])]
    bsa = [pair.estimated_bsa for pair in protofilament.pair_records]
    bsa_cv = float(np.std(bsa) / np.mean(bsa)) if bsa and np.mean(bsa) else None
    rise_consistency = float(np.clip(1.0 - ((_mad(rises) or 0.0) / max(abs(float(np.median(rises))), 1.0)), 0, 1)) if rises else 0.0
    twist_consistency = float(np.clip(1.0 - ((_mad(twists) or 0.0) / max(abs(float(np.median(twists))), 5.0)), 0, 1)) if twists else 0.0
    if lateral_vectors:
        median_lateral = np.median(np.asarray(lateral_vectors), axis=0)
        lateral_dispersion = float(np.median([np.linalg.norm(item - median_lateral) for item in lateral_vectors]))
        lateral_consistency = float(np.clip(1.0 - lateral_dispersion / max(float(np.median(rises)), 1.0), 0, 1))
    else:
        lateral_consistency = 0.0
    axis_consistency = float(np.clip(1.0 - (float(np.median(axis_angles)) / max(config.transform_direction_tolerance_degrees, 1.0)), 0, 1)) if axis_angles else 0.0
    contact_consistency = float(np.mean(jaccards)) if jaccards else (1.0 if maps else 0.0)
    hbond_consistency = float(np.mean(hbond_similarities)) if hbond_similarities else 0.0
    rmsd_support = float(np.mean([max(0.0, 1.0 - value / config.maximum_pair_rmsd) for value in rmsds])) if rmsds else 0.0
    median_rotation, median_translation = _median_proto_transform(protofilament)
    composition_drift = _two_step_transform_drift(protofilament, median_rotation, median_translation)
    composition_consistency = math.exp(-composition_drift / 3.0) if composition_drift is not None else 0.0
    # A consistency score requires at least two independently observed axial
    # interfaces (three observed layers).  Keep the one-interface measurements
    # above as descriptors, but never turn their necessarily zero dispersion
    # into repeat evidence.
    repeat_score = None
    if len(protofilament.pair_records) >= 2:
        repeat_score = float(np.clip(
            0.15 * rise_consistency + 0.12 * twist_consistency
            + 0.10 * lateral_consistency + 0.10 * axis_consistency
            + 0.10 * composition_consistency + 0.20 * contact_consistency
            + 0.10 * hbond_consistency + 0.06 * shift_consistency
            + 0.07 * rmsd_support,
            0, 1,
        ))
    return RepeatFeatures(
        rises, twists, laterals, rmsds,
        float(np.median(rises)) if rises else None, _mad(rises),
        [float(min(rises)), float(max(rises))] if rises else None,
        float(np.median(twists)) if twists else None, _mad(twists),
        jaccards, precisions, recalls, shifts, shift_consistency,
        hbond_similarities, axis_angles, composition_drift,
        rise_consistency, twist_consistency, lateral_consistency,
        axis_consistency, contact_consistency, hbond_consistency,
        bsa, bsa_cv, repeat_score,
    )


def _average_rotations(rotations: Sequence[np.ndarray]) -> np.ndarray:
    median = np.median(np.asarray(rotations), axis=0)
    left, _singular, right = np.linalg.svd(median)
    correction = np.eye(3); correction[-1, -1] = np.sign(np.linalg.det(left @ right))
    return left @ correction @ right


def _median_proto_transform(protofilament: Protofilament) -> tuple[np.ndarray, np.ndarray]:
    transforms = [
        _directed_transform(pair, source, target)
        for source, target, pair in zip(
            protofilament.chain_ids,
            protofilament.chain_ids[1:],
            protofilament.pair_records,
        )
    ]
    if not transforms:
        raise ValueError("A protofilament has no adjacent transforms")
    return (
        _average_rotations([transform.rotation for transform in transforms]),
        np.median(np.asarray([transform.translation for transform in transforms]), axis=0),
    )


def _two_step_transform_drift(
    protofilament: Protofilament,
    rotation: np.ndarray,
    translation: np.ndarray,
) -> float | None:
    if len(protofilament.chain_ids) < 3:
        return None
    errors = []
    for first_id, third_id in zip(protofilament.chain_ids, protofilament.chain_ids[2:]):
        first_chain, third_chain = protofilament.assembly.chains[first_id], protofilament.assembly.chains[third_id]
        mapping = map_equivalent_residues(first_chain, third_chain)
        for index_a, index_b in mapping.pairs:
            coord_a, coord_b = first_chain.residues[index_a].atom("CA"), third_chain.residues[index_b].atom("CA")
            if coord_a is not None and coord_b is not None:
                predicted = (coord_a @ rotation + translation) @ rotation + translation
                errors.append(float(np.linalg.norm(predicted - coord_b)))
    return float(np.sqrt(np.mean(np.square(errors)))) if errors else None


def _chain_from_coordinates(
    template: ChainRecord,
    coordinates: Mapping[tuple[int, str], np.ndarray],
    chain_id: str,
) -> ChainRecord:
    residues: list[ResidueRecord] = []
    for index, template_residue in enumerate(template.residues):
        atoms = {
            name: AtomRecord(
                name, template_atom.element, np.asarray(coordinates[(index, name)]),
                template_atom.occupancy, template_atom.alternate_location,
            )
            for name, template_atom in template_residue.atoms.items()
            if (index, name) in coordinates
        }
        residue_id = ResidueID(
            template_residue.id.model_id, chain_id, template_residue.id.residue_number,
            template_residue.id.insertion_code, template_residue.id.residue_name,
        )
        residues.append(ResidueRecord(residue_id, template_residue.one_letter, atoms, index))
    return ChainRecord(chain_id, residues)


def _virtual_contact_map(real: ChainRecord, virtual: dict[tuple[int, str], np.ndarray], cutoff: float) -> set[tuple[int, int]]:
    contacts: set[tuple[int, int]] = set()
    virtual_contact = [(index, virtual.get((index, "CB"), virtual.get((index, "CA")))) for index in range(len(real.residues))]
    virtual_contact = [(index, coord) for index, coord in virtual_contact if coord is not None]
    for real_index, residue in enumerate(real.residues):
        real_coord = residue.contact_coord()
        if real_coord is None:
            continue
        for virtual_index, coordinate in virtual_contact:
            if np.linalg.norm(real_coord - coordinate) <= cutoff:
                contacts.add((real_index, virtual_index))
    return contacts


def _virtual_clashes(real: ChainRecord, virtual: dict[tuple[int, str], np.ndarray], cutoff: float) -> int:
    real_coords = np.asarray([atom.coord for residue in real.residues for atom in residue.atoms.values()])
    virtual_coords = np.asarray(list(virtual.values()))
    if not len(real_coords) or not len(virtual_coords):
        return 0
    return sum(int(np.count_nonzero(np.linalg.norm(virtual_coords - coordinate, axis=1) < cutoff)) for coordinate in real_coords)


def _virtual_heavy_contacts(
    real: ChainRecord,
    virtual: Mapping[tuple[int, str], np.ndarray],
    cutoff: float,
) -> int:
    real_coords = np.asarray([atom.coord for residue in real.residues for atom in residue.atoms.values()])
    virtual_coords = np.asarray(list(virtual.values()))
    if not len(real_coords) or not len(virtual_coords):
        return 0
    return sum(int(np.count_nonzero(np.linalg.norm(virtual_coords - coordinate, axis=1) <= cutoff)) for coordinate in real_coords)


def _coordinate_pair_count(
    first: Mapping[tuple[int, str], np.ndarray],
    second: Mapping[tuple[int, str], np.ndarray],
    cutoff: float,
) -> int:
    first_coordinates = np.asarray(list(first.values()))
    second_coordinates = np.asarray(list(second.values()))
    if not len(first_coordinates) or not len(second_coordinates):
        return 0
    return sum(
        int(np.count_nonzero(np.linalg.norm(second_coordinates - coordinate, axis=1) < cutoff))
        for coordinate in first_coordinates
    )


def _virtual_hbond_edges(
    real: ChainRecord,
    virtual: dict[tuple[int, str], np.ndarray],
    config: GeometryConfig,
) -> set[tuple[int, int]]:
    edges: set[tuple[int, int]] = set()
    for donor_index in range(1, len(real.residues)):
        nitrogen = real.residues[donor_index].atom("N")
        hydrogen = _virtual_h(real.residues, donor_index)
        if nitrogen is None or hydrogen is None:
            continue
        for acceptor_index in range(len(real.residues)):
            oxygen, carbon = virtual.get((acceptor_index, "O")), virtual.get((acceptor_index, "C"))
            if oxygen is None or carbon is None:
                continue
            if (
                np.linalg.norm(nitrogen - oxygen) <= config.hbond_no_distance
                and np.linalg.norm(hydrogen - oxygen) <= config.hbond_ho_distance
                and _angle(nitrogen - hydrogen, oxygen - hydrogen) >= config.hbond_nho_angle
                and _angle(carbon - oxygen, hydrogen - oxygen) >= config.hbond_coh_angle
            ):
                edges.add((donor_index, acceptor_index))
    # Also evaluate virtual donors against real acceptors.
    for donor_index in range(1, len(real.residues)):
        if real.residues[donor_index].id.residue_name == "PRO":
            continue
        nitrogen = virtual.get((donor_index, "N"))
        previous_carbon = virtual.get((donor_index - 1, "C"))
        previous_oxygen = virtual.get((donor_index - 1, "O"))
        if nitrogen is None or previous_carbon is None or previous_oxygen is None:
            continue
        hydrogen = nitrogen + _unit(previous_carbon - previous_oxygen) * 1.01
        for acceptor_index, residue in enumerate(real.residues):
            oxygen, carbon = residue.atom("O"), residue.atom("C")
            if oxygen is None or carbon is None:
                continue
            if (
                np.linalg.norm(nitrogen - oxygen) <= config.hbond_no_distance
                and np.linalg.norm(hydrogen - oxygen) <= config.hbond_ho_distance
                and _angle(nitrogen - hydrogen, oxygen - hydrogen) >= config.hbond_nho_angle
                and _angle(carbon - oxygen, hydrogen - oxygen) >= config.hbond_coh_angle
            ):
                edges.add((acceptor_index, donor_index))
    return edges


def extend_protofilament(
    protofilament: Protofilament,
    steps: int = 1,
    config: GeometryConfig | None = None,
) -> VirtualExtension:
    config = config or GeometryConfig()
    if steps < 1:
        raise ValueError("steps must be at least one")
    rotation, translation = _median_proto_transform(protofilament)
    inverse_rotation = rotation.T
    inverse_translation = -translation @ inverse_rotation
    interfaces: list[VirtualInterface] = []
    first = protofilament.assembly.chains[protofilament.chain_ids[0]]
    last = protofilament.assembly.chains[protofilament.chain_ids[-1]]
    observed_coordinates = {
        chain_id: {
            (index, name): atom.coord
            for index, residue in enumerate(chain.residues)
            for name, atom in residue.atoms.items()
        }
        for chain_id, chain in protofilament.assembly.chains.items()
    }
    left_history: list[dict[tuple[int, str], np.ndarray]] = []
    right_history: list[dict[tuple[int, str], np.ndarray]] = []
    left_parent_coordinates = {(index, name): atom.coord.copy() for index, residue in enumerate(first.residues) for name, atom in residue.atoms.items()}
    right_parent_coordinates = {(index, name): atom.coord.copy() for index, residue in enumerate(last.residues) for name, atom in residue.atoms.items()}
    for step in range(1, steps + 1):
        left_coordinates = {key: coord @ inverse_rotation + inverse_translation for key, coord in left_parent_coordinates.items()}
        right_coordinates = {key: coord @ rotation + translation for key, coord in right_parent_coordinates.items()}
        left_new = _chain_from_coordinates(first, left_coordinates, f"virtual_left_{step}")
        left_parent = _chain_from_coordinates(first, left_parent_coordinates, f"left_parent_{step}")
        right_parent = _chain_from_coordinates(last, right_parent_coordinates, f"right_parent_{step}")
        # Contact maps are consistently oriented from the earlier layer to the
        # later layer along the inferred path.
        left_contacts = _virtual_contact_map(left_new, left_parent_coordinates, config.contact_distance)
        right_contacts = _virtual_contact_map(right_parent, right_coordinates, config.contact_distance)
        for end, real, partner_coordinates, stored_coordinates, contacts in (
            ("N_terminal", left_new, left_parent_coordinates, left_coordinates, left_contacts),
            ("C_terminal", right_parent, right_coordinates, right_coordinates, right_contacts),
        ):
            hbonds = _virtual_hbond_edges(real, partner_coordinates, config)
            clashes = _virtual_clashes(real, partner_coordinates, config.severe_clash_distance)
            heavy_contacts = _virtual_heavy_contacts(real, partner_coordinates, config.heavy_atom_contact_distance)
            parent_observed_id = (
                protofilament.chain_ids[0] if end == "N_terminal" and step == 1 else
                protofilament.chain_ids[-1] if end == "C_terminal" and step == 1 else None
            )
            nonlocal_targets = [
                coordinates for chain_id, coordinates in observed_coordinates.items()
                if chain_id != parent_observed_id
            ]
            same_history = left_history if end == "N_terminal" else right_history
            opposite_history = right_history if end == "N_terminal" else left_history
            # The most recent same-side virtual layer is the intended parent.
            nonlocal_targets.extend(same_history[:-1] if same_history else [])
            nonlocal_targets.extend(opposite_history)
            # Also check the simultaneously generated opposite end.
            opposite_current = right_coordinates if end == "N_terminal" else left_coordinates
            nonlocal_targets.append(opposite_current)
            nonlocal_clashes = sum(
                _coordinate_pair_count(stored_coordinates, target, config.severe_clash_distance)
                for target in nonlocal_targets
            )
            nonlocal_contacts = sum(
                _coordinate_pair_count(stored_coordinates, target, config.heavy_atom_contact_distance)
                for target in nonlocal_targets
            )
            interfaces.append(VirtualInterface(
                end, step, contacts, hbonds, clashes,
                nonlocal_clashes, nonlocal_contacts,
                _estimated_bsa(len(contacts), heavy_contacts), stored_coordinates,
            ))
        left_history.append(left_coordinates)
        right_history.append(right_coordinates)
        left_parent_coordinates = left_coordinates
        right_parent_coordinates = right_coordinates
    drift = _two_step_transform_drift(protofilament, rotation, translation)
    return VirtualExtension(interfaces, rotation, translation, drift)


def score_extension(
    protofilament: Protofilament,
    extension: VirtualExtension,
    config: GeometryConfig | None = None,
    hbond_graph: HydrogenBondGraph | None = None,
) -> ExtensionFeatures:
    config = config or GeometryConfig()
    index_maps = _canonical_index_maps(protofilament)
    observed_maps = [
        _canonical_contact_map(pair, source, index_maps)
        for source, pair in zip(protofilament.chain_ids, protofilament.pair_records)
    ]
    contact_consensus = _consensus_map(observed_maps) if observed_maps else set()
    observed_hbonds = _interface_hbond_maps(protofilament, hbond_graph, index_maps)
    hbond_consensus = _consensus_map(observed_hbonds) if observed_hbonds else set()
    first_step = [interface for interface in extension.interfaces if interface.step == 1]
    def canonical_virtual_edges(interface: VirtualInterface, edges: set[tuple[int, int]]) -> set[tuple[int, int]]:
        chain_id = protofilament.chain_ids[0] if interface.end == "N_terminal" else protofilament.chain_ids[-1]
        mapping = index_maps[chain_id]
        return {
            (mapping[first], mapping[second])
            for first, second in edges
            if first in mapping and second in mapping
        }
    contact_similarity = (
        float(np.mean([
            _jaccard(canonical_virtual_edges(interface, interface.contact_map), contact_consensus)
            for interface in first_step
        ]))
        if first_step and contact_consensus else 0.0
    )
    hbond_similarity = (
        float(np.mean([
            _jaccard(canonical_virtual_edges(interface, interface.hbond_edges), hbond_consensus)
            for interface in first_step
        ]))
        if first_step and hbond_consensus else 0.0
    )
    clashes = sum(interface.clash_count for interface in first_step)
    nonlocal_clashes = sum(interface.nonlocal_clash_count for interface in extension.interfaces)
    nonlocal_contacts = sum(interface.nonlocal_contact_count for interface in extension.interfaces)
    observed_bsa = np.median([pair.estimated_bsa for pair in protofilament.pair_records]) if protofilament.pair_records else 0.0
    extension_bsa = np.median([interface.estimated_bsa for interface in first_step]) if first_step else 0.0
    bsa_ratio = float(extension_bsa / observed_bsa) if observed_bsa else None
    clash_score = math.exp(-clashes / 5.0)
    bsa_score = min(1.0, bsa_ratio) if bsa_ratio is not None else 0.0
    nonlocal_gate = math.exp(-nonlocal_clashes / 2.0)
    drift_gate = math.exp(-extension.two_step_transform_drift / 3.0) if extension.two_step_transform_drift is not None else 0.75
    score = float(np.clip(
        (0.45 * contact_similarity + 0.20 * hbond_similarity + 0.25 * clash_score + 0.10 * bsa_score)
        * nonlocal_gate * drift_gate,
        0, 1,
    ))
    return ExtensionFeatures(
        contact_similarity, hbond_similarity, clashes,
        nonlocal_clashes, nonlocal_contacts,
        bsa_ratio, None, extension.two_step_transform_drift, score,
    )


def _intrachain_contact_count(assembly: Assembly, cutoff: float) -> int:
    count = 0
    for chain in assembly.chains.values():
        contact_coords = [(index, residue.contact_coord()) for index, residue in enumerate(chain.residues)]
        contact_coords = [(index, coord) for index, coord in contact_coords if coord is not None]
        for position, (index_a, coord_a) in enumerate(contact_coords):
            for index_b, coord_b in contact_coords[position + 1:]:
                if abs(index_a - index_b) > 2 and np.linalg.norm(coord_a - coord_b) <= cutoff:
                    count += 1
    return count


def _finite_topology(
    protofilaments: Sequence[Protofilament],
    all_pairs: Sequence[PairRecord],
    assembly: Assembly,
    config: GeometryConfig,
) -> dict[str, Any]:
    retained = [pair for pair in all_pairs if pair.retained]
    adjacency: dict[str, set[str]] = defaultdict(set)
    for pair in retained:
        adjacency[pair.chain_a].add(pair.chain_b); adjacency[pair.chain_b].add(pair.chain_a)
    endpoints = sorted(chain for chain, neighbors in adjacency.items() if len(neighbors) == 1)
    edges = len(retained); nodes = len(adjacency)
    components = 0
    unseen = set(adjacency)
    while unseen:
        components += 1
        queue = [unseen.pop()]
        while queue:
            node = queue.pop()
            for neighbor in adjacency[node] & unseen:
                unseen.remove(neighbor); queue.append(neighbor)
    lattice_cycle_rank = max(0, edges - nodes + components)
    terminal_contacts = []
    axial_cycle_composition_rmsd: dict[str, float] = {}
    open_axial_paths = []

    def same_transform_family(first: PairRecord, second: PairRecord) -> bool:
        differences = [
            (
                _rotation_difference_degrees(first.transform.rotation, variant.rotation),
                float(np.linalg.norm(first.transform.translation - variant.translation))
                / max(float(np.linalg.norm(first.transform.translation)), 1.0),
            )
            for variant in (second.transform, second.transform.inverse())
        ]
        rotation_difference, translation_difference = min(differences)
        return bool(
            rotation_difference <= config.transform_rotation_tolerance_degrees
            and translation_difference <= config.transform_length_relative_tolerance
        )

    for protofilament in protofilaments:
        if len(protofilament.chain_ids) >= 3:
            terminal_key = frozenset((protofilament.chain_ids[0], protofilament.chain_ids[-1]))
            closing_pair = next(
                (pair for pair in retained if frozenset((pair.chain_a, pair.chain_b)) == terminal_key),
                None,
            )
            if closing_pair is None or not same_transform_family(protofilament.pair_records[0], closing_pair):
                open_axial_paths.append(protofilament.id)
                continue
            rotation = np.eye(3)
            translation = np.zeros(3)
            directed = [
                _directed_transform(pair, source, target)
                for source, target, pair in zip(
                    protofilament.chain_ids,
                    protofilament.chain_ids[1:],
                    protofilament.pair_records,
                )
            ]
            directed.append(_directed_transform(
                closing_pair, protofilament.chain_ids[-1], protofilament.chain_ids[0]
            ))
            for transform in directed:
                translation = translation @ transform.rotation + transform.translation
                rotation = rotation @ transform.rotation
            first_chain = assembly.chains[protofilament.chain_ids[0]]
            ca_coordinates = np.asarray([
                residue.atom("CA") for residue in first_chain.residues if residue.atom("CA") is not None
            ])
            closure_rmsd = (
                float(np.sqrt(np.mean(np.sum((ca_coordinates @ rotation + translation - ca_coordinates) ** 2, axis=1))))
                if len(ca_coordinates) else float("inf")
            )
            axial_cycle_composition_rmsd[protofilament.id] = closure_rmsd
            if closure_rmsd <= config.maximum_pair_rmsd:
                terminal_contacts.append(protofilament.id)
            else:
                open_axial_paths.append(protofilament.id)
    axial_closed = bool(terminal_contacts)
    compact_cycle = bool(nodes >= 3 and lattice_cycle_rank > 0 and not open_axial_paths and not axial_closed)
    closes_ring = axial_closed or compact_cycle
    intrachain_contacts = _intrachain_contact_count(assembly, config.contact_distance)
    interchain_contacts = sum(len(pair.residue_contacts) for pair in retained)
    intrachain_fraction = intrachain_contacts / max(1, intrachain_contacts + interchain_contacts)
    degrees = np.asarray([len(adjacency.get(chain_id, ())) for chain_id in assembly.chains], dtype=float)
    central_concentration = 0.0
    if degrees.size > 1 and degrees.sum() > 0:
        uniform_share = 1.0 / len(degrees)
        central_concentration = float(np.clip((degrees.max() / degrees.sum() - uniform_share) / (1.0 - uniform_share), 0, 1))
    ca_coords = np.asarray([
        residue.atom("CA") for chain in assembly.chains.values() for residue in chain.residues
        if residue.atom("CA") is not None
    ])
    anisotropy = None
    if len(ca_coords) >= 3:
        eigenvalues = np.linalg.eigvalsh(np.cov((ca_coords - ca_coords.mean(axis=0)).T))
        anisotropy = float(eigenvalues[-1] / eigenvalues.sum()) if eigenvalues.sum() > 0 else None
    composition_drifts = []
    for protofilament in protofilaments:
        if len(protofilament.chain_ids) >= 3:
            composition_drifts.append(extend_protofilament(protofilament, 1, config).two_step_transform_drift)
    return {
        "chain_graph_closes_ring": closes_ring,
        "closed_axial_topology": axial_closed,
        "compact_finite_cycle": compact_cycle,
        "lattice_cycle_rank": lattice_cycle_rank,
        "lattice_has_cycles": lattice_cycle_rank > 0,
        "open_axial_protofilaments": open_axial_paths,
        "axial_cycle_composition_rmsd_A": axial_cycle_composition_rmsd,
        "graph_endpoint_count": len(endpoints),
        "graph_endpoints": endpoints,
        "terminal_chains_contact": bool(terminal_contacts),
        "terminal_contact_protofilaments": terminal_contacts,
        "intrachain_residue_contact_count": intrachain_contacts,
        "repeated_interchain_residue_contact_count": interchain_contacts,
        "intrachain_contact_fraction": intrachain_fraction,
        "central_contact_concentration": central_concentration,
        "global_ca_anisotropy": anisotropy,
        "pairwise_transform_composition_rmsd_A": (
            float(np.mean([value for value in composition_drifts if value is not None]))
            if any(value is not None for value in composition_drifts) else None
        ),
        "n_closed_score": float(closes_ring or bool(terminal_contacts)),
    }


def _quality_features(assembly: Assembly, config: GeometryConfig) -> dict[str, Any]:
    missing_backbone = []
    total_residues = 0
    for chain in assembly.chains.values():
        for residue in chain.residues:
            total_residues += 1
            missing = [name for name in BACKBONE_ATOMS if name not in residue.atoms]
            if missing:
                missing_backbone.append({"residue": residue.id.text(), "missing_atoms": missing})
    chains = list(assembly.chains.values())
    severe_clashes = 0
    minimum_distance = float("inf")
    for position, chain_a in enumerate(chains):
        coordinates_a = [atom.coord for residue in chain_a.residues for atom in residue.atoms.values()]
        for chain_b in chains[position + 1:]:
            coordinates_b = np.asarray([atom.coord for residue in chain_b.residues for atom in residue.atoms.values()])
            if not coordinates_a or not len(coordinates_b):
                continue
            for coordinate in coordinates_a:
                distances = np.linalg.norm(coordinates_b - coordinate, axis=1)
                minimum_distance = min(minimum_distance, float(np.min(distances)))
                severe_clashes += int(np.count_nonzero(distances < config.severe_clash_distance))
    complete_fraction = 1.0 - len(missing_backbone) / max(1, total_residues)
    q_score = float(complete_fraction * math.exp(-severe_clashes / 10.0))
    return {
        "hbond_definition": _hbond_definition(config),
        "contact_definition": _contact_definition(config),
        "definitions": {
            "hydrogen_bond": {
                "id": HBOND_DEFINITION,
                "virtual_hydrogen_convention": "N + unit(C_previous - O_previous) * 1.01A",
                "maximum_NO_distance_A": config.hbond_no_distance,
                "maximum_HO_distance_A": config.hbond_ho_distance,
                "minimum_NHO_angle_degrees": config.hbond_nho_angle,
                "minimum_COH_angle_degrees": config.hbond_coh_angle,
            },
            "residue_contact": {
                "id": CONTACT_DEFINITION,
                "atom": "CB, or CA for residues without CB",
                "maximum_distance_A": config.contact_distance,
            },
            "heavy_atom_contact_distance_A": config.heavy_atom_contact_distance,
            "backbone_contact_distance_A": config.backbone_contact_distance,
            "severe_clash_distance_A": config.severe_clash_distance,
            "minimum_screw_rotation_degrees": config.minimum_screw_rotation_degrees,
        },
        "missing_backbone_residue_count": len(missing_backbone),
        "missing_backbone_residues": missing_backbone,
        "minimum_interchain_heavy_atom_distance_A": minimum_distance if math.isfinite(minimum_distance) else None,
        "observed_severe_interchain_clash_count": severe_clashes,
        "Q_geom": q_score,
    }


def _assessability(groups: Sequence[Sequence[str]], protofilaments: Sequence[Protofilament]) -> str:
    maximum = max((len(protofilament.chain_ids) for protofilament in protofilaments), default=0)
    if maximum >= 5:
        return "direct_five_or_more_layers"
    if maximum >= 3:
        return "direct_three_or_four_layers"
    if maximum == 2:
        return "two_layer_extrapolation_only"
    if max((len(group) for group in groups), default=0) <= 1:
        return "single_chain_not_assessable"
    return "ambiguous_layer_assignment"


def score_geometry(
    assembly: Assembly | str | Path,
    config: GeometryConfig | None = None,
    layer_assignments: Sequence[Any] | None = None,
) -> GeometryResult:
    config = config or GeometryConfig()
    if not isinstance(assembly, Assembly):
        assembly = load_assembly(assembly, config.model_index)
    groups = group_equivalent_chains(assembly, config)
    pairs = candidate_repeat_pairs(assembly, groups, config)
    graph = build_chain_contact_graph(pairs)
    if layer_assignments is not None:
        protofilaments, topology = protofilaments_from_layer_assignments(
            pairs, layer_assignments, assembly, config
        )
    else:
        protofilaments = infer_protofilaments(pairs, graph, config, assembly) if pairs else []
        topology = {
            "source": "geometry_inference",
            "status": "matched",
            "requested_paths": None,
            "scored_paths": [item.chain_ids for item in protofilaments],
            "disagreements": [],
        }
    primary_axis = protofilaments[0].axis if protofilaments else None
    hbonds = build_backbone_hbond_graph(assembly, config, primary_axis)
    _annotate_hbond_persistence_across_protofilaments(protofilaments, hbonds)
    secondary = assign_assembly_secondary_structure(assembly, config, hbonds)
    proto_results: list[dict[str, Any]] = []
    scores: list[float] = []
    for protofilament in protofilaments:
        cross_beta = score_cross_beta(protofilament, secondary, hbonds)
        repeat = score_repeat_consistency(protofilament, config, hbonds)
        extension = extend_protofilament(protofilament, config.extension_steps, config)
        extension_features = score_extension(protofilament, extension, config, hbonds)
        observed_interfaces = len(protofilament.pair_records)
        if repeat.r_repeat_score is None:
            # Direct two-layer evidence is represented by cross-beta geometry
            # only. Virtual extension remains a feasibility descriptor and is
            # explicitly not folded into the ordinary geometry score.
            geometry_score = cross_beta.c_beta_score
            extension_evidence = "extrapolative_only"
        else:
            geometry_score = (
                0.45 * cross_beta.c_beta_score
                + 0.30 * repeat.r_repeat_score
                + 0.25 * extension_features.e_extend_score
            )
            extension_evidence = "observed_repeat_supported"
        scores.append(geometry_score)
        proto_results.append({
            "id": protofilament.id,
            "chain_ids": protofilament.chain_ids,
            "alternative_support_relative_to_primary": protofilament.alternative_support,
            "axis": protofilament.axis,
            "cross_beta": cross_beta,
            "repeat": repeat,
            "extension": extension_features,
            "observed_axial_interface_count": observed_interfaces,
            "repeat_evidence": "observed" if repeat.r_repeat_score is not None else "unavailable_single_interface",
            "extension_evidence": extension_evidence,
            "virtual_interfaces": extension.interfaces,
            "G_geometry": geometry_score,
        })
    finite = _finite_topology(protofilaments, pairs, assembly, config)
    quality = _quality_features(assembly, config)
    warnings = list(assembly.warnings)
    if not protofilaments:
        warnings.append("No repeated contacting equivalent-chain path was inferred")
    if topology["status"] != "matched":
        warnings.append("Canonical layer topology could not be reconciled with geometry candidates")
    if secondary.backend == "hbond_geometry_fallback":
        warnings.append(
            "PyDSSP unavailable or inapplicable; beta states use the geometry fallback"
            + (f": {secondary.fallback_reason}" if secondary.fallback_reason else "")
        )
    try:
        pydssp_version = importlib.metadata.version("pydssp")
    except importlib.metadata.PackageNotFoundError:
        pydssp_version = "not-installed"
    ranked_scores = sorted(scores, reverse=True)
    if scores:
        weights = [len(item.chain_ids) for item in protofilaments]
        best_index = int(np.argmax(scores))
        selected_chains = set(protofilaments[best_index].chain_ids)
        aggregation = {
            "maximum_score": max(scores),
            "support_weighted_score": float(np.average(scores, weights=weights)),
            "selected_path_chain_fraction": len(selected_chains) / max(1, len(assembly.chains)),
            "best_minus_next_score": (
                ranked_scores[0] - ranked_scores[1] if len(ranked_scores) > 1 else None
            ),
            "ambiguous_best_interpretation": (
                len(ranked_scores) > 1 and abs(ranked_scores[0] - ranked_scores[1]) < 1e-12
            ),
            "finite_topology": bool(finite.get("chain_graph_closes_ring")),
        }
    else:
        aggregation = {
            "maximum_score": None,
            "support_weighted_score": None,
            "selected_path_chain_fraction": 0.0,
            "best_minus_next_score": None,
            "ambiguous_best_interpretation": False,
            "finite_topology": bool(finite.get("chain_graph_closes_ring")),
        }
    config_document = asdict(config)
    config_document["parameter_hash"] = hashlib.sha256(
        json.dumps(config_document, sort_keys=True).encode("utf-8")
    ).hexdigest()
    return GeometryResult(
        SCHEMA_VERSION,
        assembly.identity.get("prediction_id"),
        {
            "path": assembly.source,
            "sha256": _sha256(Path(assembly.source)) if assembly.source else None,
            "model_index": assembly.model_index,
            "chain_count": len(assembly.chains),
            "residue_count": sum(len(chain.residues) for chain in assembly.chains.values()),
            **assembly.identity,
        },
        config_document, _assessability(groups, protofilaments), groups, pairs,
        proto_results, hbonds, secondary, finite, quality, max(scores) if scores else None,
        aggregation, topology,
        warnings,
        {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "biopython": biopython_version,
            "pydssp": pydssp_version,
            "secondary_structure_backend": secondary.backend,
        },
    )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _jsonable(value: Any) -> Any:
    if is_dataclass(value):
        return {key: _jsonable(item) for key, item in asdict(value).items() if key != "coordinates"}
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, tuple):
        return [_jsonable(item) for item in value]
    if isinstance(value, (set, frozenset)):
        converted = [_jsonable(item) for item in value]
        return sorted(
            converted,
            key=lambda item: json.dumps(item, sort_keys=True, separators=(",", ":")),
        )
    if isinstance(value, list):
        return [_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items() if key != "coordinates"}
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def _write_csv(path: Path, rows: Sequence[dict[str, Any]], fieldnames: Sequence[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key) for key in fieldnames})


def write_outputs(result: GeometryResult, output: str | Path) -> None:
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(_jsonable(result), indent=2, sort_keys=True) + "\n")
    stem = output.with_suffix("")
    if stem.name.endswith(".geometry"):
        stem = stem.with_name(stem.name[:-9])
    pair_rows = []
    transform_rows = []
    for pair in result.pair_records:
        pair_rows.append({
            "chain_a": pair.chain_a, "chain_b": pair.chain_b,
            "retained": pair.retained, "retention_reason": pair.retention_reason,
            "minimum_heavy_atom_distance_A": pair.minimum_heavy_atom_distance,
            "heavy_atom_contact_count": pair.heavy_atom_contact_count,
            "backbone_contact_count": pair.backbone_contact_count,
            "residue_contact_count": len(pair.residue_contacts),
            "estimated_bsa_A2": pair.estimated_bsa,
            "pdb_amyloid_fragment_length": pair.pdb_amyloid_fragment_length,
            "pdb_amyloid_fragment_fraction": pair.pdb_amyloid_fragment_fraction,
            "pdb_amyloid_mean_ca_distance_A": pair.pdb_amyloid_mean_ca_distance,
            "pdb_amyloid_ca_distance_std_A": pair.pdb_amyloid_ca_distance_std,
            "pdb_amyloid_mean_triplet_angle_degrees": pair.pdb_amyloid_mean_triplet_angle,
            "pdb_amyloid_candidate": pair.pdb_amyloid_candidate,
        })
        transform_rows.append({
            "chain_a": pair.chain_a, "chain_b": pair.chain_b,
            "rmsd_A": pair.transform.rmsd,
            "fitted_atom_count": pair.transform.fitted_atom_count,
            "fitted_residue_count": pair.transform.fitted_residue_count,
            "sequence_identity": pair.transform.sequence_identity,
            "sequence_coverage": pair.transform.sequence_coverage,
            "orientation": pair.transform.orientation,
            "translation_magnitude_A": float(np.linalg.norm(pair.transform.centroid_displacement)),
            "rotation_angle_degrees": abs(_rotation_angle(pair.transform.rotation, _unit(pair.transform.centroid_displacement))),
            "rotation_matrix": json.dumps(pair.transform.rotation.tolist()),
            "translation_vector": json.dumps(pair.transform.translation.tolist()),
        })
    _write_csv(stem.with_suffix(".pairs.csv"), pair_rows, list(pair_rows[0]) if pair_rows else ["chain_a", "chain_b"])
    _write_csv(stem.with_suffix(".transforms.csv"), transform_rows, list(transform_rows[0]) if transform_rows else ["chain_a", "chain_b"])
    hbond_rows = [{
        "donor_chain": bond.donor.chain_id, "donor_residue": bond.donor.text(),
        "acceptor_chain": bond.acceptor.chain_id, "acceptor_residue": bond.acceptor.text(),
        "N_O_distance_A": bond.no_distance, "H_O_distance_A": bond.ho_distance,
        "N_H_O_angle_degrees": bond.nho_angle, "C_O_H_angle_degrees": bond.coh_angle,
        "axial_separation_A": bond.axial_separation,
        "repeated_ladder": bond.repeated_ladder,
        "persistent_interfaces": bond.persistent_interfaces,
        "definition": result.hydrogen_bonds.definition,
    } for bond in result.hydrogen_bonds.bonds]
    _write_csv(stem.with_suffix(".hydrogen_bonds.csv"), hbond_rows, list(hbond_rows[0]) if hbond_rows else ["donor_chain", "acceptor_chain", "definition"])
    extension_rows = []
    for protofilament in result.protofilaments:
        for interface in protofilament["virtual_interfaces"]:
            extension_rows.append({
                "protofilament": protofilament["id"], "end": interface.end, "step": interface.step,
                "contact_count": len(interface.contact_map), "hbond_count": len(interface.hbond_edges),
                "clash_count": interface.clash_count,
                "nonlocal_clash_count": interface.nonlocal_clash_count,
                "nonlocal_contact_count": interface.nonlocal_contact_count,
                "estimated_bsa_A2": interface.estimated_bsa,
            })
    _write_csv(stem.with_suffix(".extensions.csv"), extension_rows, list(extension_rows[0]) if extension_rows else ["protofilament", "end", "step"])


def _parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--structure", type=Path, required=True, help="Input PDB, CIF, or mmCIF")
    parser.add_argument("--output", type=Path, required=True, help="Versioned JSON output")
    parser.add_argument("--model-index", type=int, default=0)
    parser.add_argument(
        "--chain-id-source", choices=("auto", "author", "label"), default="auto"
    )
    parser.add_argument("--extension-steps", type=int, choices=(1, 2), default=1)
    parser.add_argument("--minimum-sequence-identity", type=float, default=0.85)
    parser.add_argument("--minimum-sequence-coverage", type=float, default=0.70)
    parser.add_argument("--no-pydssp", action="store_true", help="Use the geometry beta-state fallback")
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = _parse_args(argv)
    config = GeometryConfig(
        model_index=args.model_index,
        extension_steps=args.extension_steps,
        minimum_sequence_identity=args.minimum_sequence_identity,
        minimum_sequence_coverage=args.minimum_sequence_coverage,
        use_pydssp=not args.no_pydssp,
    )
    try:
        from amyloid_cross_check.common import load_assembly as load_common_assembly
        from amyloid_cross_check.common.adapters import to_geometry_assembly

        canonical = load_common_assembly(
            args.structure,
            model_index=args.model_index,
            chain_id_source=args.chain_id_source,
        )
        result = score_geometry(to_geometry_assembly(canonical), config)
        write_outputs(result, args.output)
    except (FileNotFoundError, ImportError, ValueError) as error:
        print(f"geometry: {error}", file=sys.stderr)
        return 2
    print(f"wrote {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
