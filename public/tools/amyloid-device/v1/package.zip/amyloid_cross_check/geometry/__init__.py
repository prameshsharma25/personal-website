"""Installed geometry API backed by the validated score_geometry module."""

from . import score_geometry

__all__ = ["score_geometry"]
